// **************************************************************
//						Copyright (C) 2003 - 2005 
//			Martin Eggenberger, Ljubomir Buturovic, SFSU
//
// **************************************************************
//
// Permission is hereby granted, free of charge, to any person obtaining 
// a copy of this software and associated documentation files (the "Software"), 
// to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense,
// and/or sell copies of the Software, and to permit persons to whom the 
// Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
// IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
// CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
// TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
// **************************************************************
//
// PhaseMachine is a program that allows the classification of 
// two species based on the individual genetic sequecne as 
// obtained by the phase program.
//			
// For further information, please read the documentation to the 
// phasemachine program or conact.
//
//	meggenbe@sfsu.edu
//	ljubomir@sfsu.edu
// 
// **************************************************************

#include "Options.h"


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Options::Options() :
	resultFile( "output.dat"),
	modelFile ( "model.dat"),
	testFile  ( "" ),
	probability( "0.6" ),
	verbose (false),
	defaultSettings( true ),	
	interactive( false ),
	resultAll ( false ),
	swapAllele( false ),
	hasGamma ( false ),
	snpData ( AllSNPs    ),
	dataFormat( Decimal  ),
	kernel  ( RBF ),
	svmType ( C_SVMType  ), 
	operation( OpValidate  ),
	experiments( 10 ),
	crossValidate( 10 ),
	scaleFactor  ( 1 ),
	termCriterion( 0.00001 ),
	gamma        ( 0.0 ),
//	nu			 ( 0.2 ),
	nu			 ( 0.5 ),//CHANGED BY ED to match libsvm python example defaults
	coefficiant	 ( 0.0 ),
	degree		 ( 3.0 ),
	cost		 ( 1.0 ),
	fraction     ( 0.5 )
{
}


Options::Options( const Options& rhs ) :
	fileListTrain( rhs.fileListTrain ),
	fileListTest( rhs.fileListTest ),
	classNamesTrain ( rhs.classNamesTrain ),
	classNamesTest  ( rhs.classNamesTest ),
	resultFile ( rhs.resultFile  ),
	modelFile  ( rhs.modelFile),
	testFile   ( rhs.testFile ),
	optionFile ( rhs.optionFile  ),
	probability( rhs.probability ),
	verbose    ( rhs.verbose),
	defaultSettings( rhs.defaultSettings ),
	interactive( rhs.interactive ),
	resultAll  ( rhs.resultAll  ),
	swapAllele ( rhs.swapAllele ),
	hasGamma   ( rhs.hasGamma  ),
	snpData    ( rhs.snpData   ),
	dataFormat ( rhs.dataFormat ),
	kernel	   ( rhs.kernel ),
	svmType	   ( rhs.svmType  ), 
	operation   ( rhs.operation  ),
	experiments( rhs.experiments ),
	crossValidate( rhs.crossValidate ),
	scaleFactor  ( rhs.scaleFactor ),
	termCriterion( rhs.termCriterion ),
	gamma        ( rhs.gamma ),
	nu			 ( rhs.nu ),
	coefficiant	 ( rhs.coefficiant ),
	degree		 ( rhs.degree ),
	cost		 ( rhs.cost ),
	fraction     ( rhs.fraction )
{
}

Options::~Options()
{
}

Options& Options::operator =(const Options& rhs )
{
	if (&rhs != this )
	{

		interactive		= rhs.interactive ;
		defaultSettings	= rhs.defaultSettings ;
		verbose			= rhs.verbose;
		kernel			= rhs.kernel ;
		snpData			= rhs.snpData;
		svmType         = rhs.svmType;
		dataFormat		= rhs.dataFormat;
		experiments		= rhs.experiments;
		crossValidate	= rhs.crossValidate;
		probability		= rhs.probability;
		resultFile		= rhs.resultFile;
		modelFile       = rhs.modelFile;
		testFile        = rhs.testFile;
		resultAll		= rhs.resultAll;
		swapAllele      = rhs.swapAllele;
		hasGamma        = rhs.hasGamma;
		fileListTrain	= rhs.fileListTrain;
		fileListTest	= rhs.fileListTest;
		classNamesTrain	= rhs.classNamesTrain;
		classNamesTest  = rhs.classNamesTest;
		termCriterion	= rhs.termCriterion ;
		scaleFactor		= rhs.scaleFactor;
		gamma			= rhs.gamma;
		nu				= rhs.nu;
		coefficiant		= rhs.coefficiant;
		degree			= rhs.degree;
		cost			= rhs.cost;
		operation       = rhs.operation;
		fraction		= rhs.fraction;
	}
	
	return *this;
}


void Options::SetParam( svm_parameter& param )
{

	//COMMENTED LINES REMOVED BY ED JOHNSON because
	// I'm using original version of LIBSVM,
	// not the version modified by others

	kernel			= (EKernelType) param.kernel_type;
	//dataFormat		= (EDataType  ) param.data_type;
	//swapAllele      = param.swap;
	nu				= param.nu;
	coefficiant		= param.coef0;
	degree			= param.degree;
	gamma           = param.gamma;
	cost            = param.C;
	termCriterion   = param.eps;	

	//REMOVED BY ED JOHNSON because
	// I'm using original version of LIBSVM,
	// not the modified version

	//if ( param.classNames )
	//{
	//	for (int i = 0; i < param.classNumber; i++)
	//	{
	//		classNamesTrain.push_back( param.classNames[i] );
	//		delete [] param.classNames[i];

	//	}
	//	param.classNames = NULL;
	//}

}

void Options::GetParam( svm_parameter& param )
{
	//COMMENTED LINES REMOVED BY ED JOHNSON because
	// I'm using original version of LIBSVM,
	// not the version modified by others

	param.svm_type		= GetSVMType();
	param.kernel_type	= GetKernel();
//	param.data_type     = GetDataType();
	param.degree		= GetDegree();
	param.gamma			= (GetGamma() == 0.0) ? 1 / GetDimensions() : GetGamma();
	param.coef0			= GetCoefficiant();
	param.nu			= GetNu();
	param.cache_size	= 40;
	param.C				= GetCost();
	param.eps			= GetTermCriterion();
	//param.p			= 0.0;
	param.p				= 0.1;//CHANGED TO MATCH LIBSVM PYTHON EXAMPLE
	param.shrinking		= 1;
	param.nr_weight		= 0;
	param.weight_label	= NULL;
	param.weight		= NULL;
//	param.swap          = IsSwapAllele();
	param.probability   = 0;


//	int trainset = GetNumClasses(TrainingSet);
////	if (trainset == 0)
//		param.classNames    = NULL;
////	else
////	{
//
//	if (operation != OpValidate)
//	{	
//		if (param.classNames == NULL)
//		{
//			param.classNames   = (char **) malloc( sizeof(char*) * trainset);
//			for (int i =0; i < trainset; i++)
//			{
//				string className = GetClassName( TrainingSet, i+1);
//				char*  name = (char*) malloc( sizeof(char) * className.size() + 1);
//				strcpy(name, className.c_str());
//				param.classNames[i] = name;
//			}
//		}
//	}
}

void Options::ClearParam( svm_parameter& param )
{
	//COMMENTED LINES REMOVED BY ED JOHNSON because
	// I'm using original version of LIBSVM,
	// not the version modified by others

	//if (param.classNames != NULL)
	//{
	//	for (int i =0; i < param.classNumber; i++)
	//	{
	//		free ( param.classNames[i] );
	//	}
	//	free( param.classNames );
	//	param.classNames = NULL;
	//}
}

void Options::LoadParam( svm_parameter& param )
{
	char enter;
	cout<<"\nDo you want to use defualt svm parameter? "
		<<"\nY or y for yes, other key for no.\n";
	cout<<"your choice :  ";
	cin>>enter;
	if(enter!='Y'&&enter !='y')	
	{
		int nValue;
		cout << "\nSVM type (C_SVC for 0, nu_SVC for 1):	";
		cin  >> nValue;
		SetSVMType( (ESVMType) nValue );
		cout << "\nKernel type (LINEAR for 0, POLY for 1, RBF for 2, SIGMA for 3, LA for 4):	";
		cin  >> nValue;
		SetKernel((EKernelType) nValue );
		
		cout<<"\ndegree in kernel function (default 3):	";
		cin >> nValue;
		SetDegree( nValue );
		
		double dValue;
		cout<<"\ngamma in kernel function (default 1/k, k is the number of vectors):	";
		cin >> dValue;	// 1/k
		SetGamma( dValue );
		
		cout<<"\nset coef0 in kernel function (default 0):	";
		cin >> dValue;
		SetCoefficiant( dValue);
		cout<<"\nset the parameter nu of nu-SVC, (default 0.5):	";
		cin>> dValue;
		SetNu( dValue );

		cout<<"\ncost : set the parameter C of C-SVC (default 1):	";
		cin>> dValue;
		SetCost( dValue );

		cout<<"\nepsilon : set tolerance of termination criterion (default 0.001):	";
		cin>> dValue;
		SetTermCriterion( dValue );

	}

	GetParam( param );

}

bool Options::IsVerbose() const
{
	return verbose;
}
	
void Options::SetVerbose(bool bVerbose)
{
	verbose = bVerbose;
}

bool Options::IsDefault() const
{
	return defaultSettings;
}

bool Options::HasGamma() const
{
	return hasGamma;
}

void Options::SetDefault(bool bDefault)
{
	defaultSettings = bDefault;
}

bool Options::IsSwapAllele() const
{
	return swapAllele;
}

void Options::SetSwapAllele( bool bSwap )
{
	swapAllele = bSwap;
}

bool Options::IsInteractive() const
{
	return interactive;	
}

void Options::SetInteractive( bool bInteractive)
{
	interactive = bInteractive;
}

int	 Options::GetExpirments() const
{
	return experiments;
}

void Options::SetExpirments( int nExp )
{
	experiments = nExp;
}

int  Options::GetCrossValidation() const
{
	return crossValidate;
}

void Options::SetCrossValidation(int nCross )
{
	crossValidate = nCross;
}

Options::ESVMType Options::GetSVMType() const
{
	return svmType;
}
void	 Options::SetSVMType( Options::ESVMType eType )
{
	svmType = eType;
}


Options::EOperation Options::GetOperation() const
{
	return operation;
}

void Options::SetOperation( Options::EOperation eType )
{
	operation = eType;
}

Options::EKernelType Options::GetKernel() const
{
	return kernel;
}
	
void Options::SetKernel( Options::EKernelType eType )
{
	kernel = eType;
}

Options::ESNPData	Options::GetSNPData() const
{
	return snpData;
}
	
void Options::SetSNPData( Options::ESNPData eType )
{
	snpData = eType;
}

Options::EDataType Options::GetDataType() const
{
	return dataFormat;
}

void Options::SetDataType( Options::EDataType eType )
{
	dataFormat = eType;
}

std::string& Options::GetOptionFile()
{
	return optionFile;
}

std::string& Options::GetProbability()
{
	return probability;
}

void Options::SetProbability( const std::string& prob )
{
	probability = prob;
}


std::string& Options::GetResultFile()
{
	return resultFile;
}

void Options::SetResultFile( const std::string& file )
{
	resultFile = file;
}



void Options::SetModelFile( const std::string& file )
{
	modelFile = file;
}

std::string& Options::GetModelFile()
{
	return modelFile;
}


bool Options::IsAllResults() const
{
	return resultAll;
}
	
void Options::SetAllResults( bool bAll )
{
	resultAll = bAll;
}

void Options::SetTermCriterion( double value )
{
	termCriterion = value;
}

double Options::GetTermCriterion() const
{ 
	return termCriterion;
}
	
void Options::SetGamma( double value )
{
	hasGamma = true;
	gamma = value;
}

double Options::GetGamma() const
{
	return (gamma != 0.0) ? gamma : 1.0 / GetDimensions();
}

void Options::SetNu( double value )
{
	nu = value;
}

double Options::GetNu( ) const
{
	return nu;
}
	
void Options::SetCoefficiant(double val )
{
	coefficiant = val;
}
	
double Options::GetCoefficiant() const
{
	return coefficiant;
}
	
void Options::SetDegree( double value )
{
	degree = value;
}

double Options::GetDegree() const
{
	return degree;
}

void Options::SetCost(double value )
{
	cost = value;
}

double Options::GetCost() const
{
	return cost;
}


void Options::SetDimensions( int dim )
{
	dimensions = dim;
}
	
int  Options::GetDimensions() const
{
	return dimensions;
}

void Options::SetFraction( double f )
{
	fraction = f;
}

double Options::GetFraction() const
{
	return fraction;
}

bool Options::Validate()
{
	if (IsInteractive() )
		return true;

	// make sure we have two groups
//	if (GetNumClasses( TrainingSet ) < 2)
//	{
//		PrintUsage();
//		return false;
//	}


	switch (kernel )
	{
		case Linear:
			return ValidateLinear();
		case Polynomial:
			return ValidatePolynominal();
		case RBF:
			return ValidateRBF();
		case Sigmoid:
			return ValidateSigmoid();
		default:
			PrintUsage();
			return false;
	}

}

// Class types index start with 1.
std::vector<string> Options::GetFileList(EFileType type, int nClassType )
{
	std::vector<string> list;
	int index = nClassType - 1;
	int size  =  (type == TrainingSet) ? fileListTrain.size() : fileListTest.size();
	if (index >=0 && index < size)
	{
		list = (type == TrainingSet) ? fileListTrain.at( index ) : fileListTest.at(index);
	}
	return list;
}

void Options::AddFile(EFileType type, int classType, const std::string& className, const std::string& file )
{
	FileCollection      fileList   = (type == TrainingSet) ? fileListTrain   : fileListTest;
	std::vector<string> classNames = (type == TrainingSet) ? classNamesTrain : classNamesTest;
	int index = classType - 1;
	int size  = fileList.size();
	// Check if the class type exists
	if (index >= 0 && index < size)
	{
		fileList.at( index ).push_back( file );	
	} else
	{
		FileList fList;
		fList.push_back( file );
		fileList.push_back( fList );
		classNames.push_back( className );
	}

	if (type == TrainingSet)
	{
		fileListTrain   = fileList;
		classNamesTrain = classNames;
	} else
	{
		fileListTest    = fileList;
		classNamesTest  = classNames;
	}
}

int Options::GetNumClasses(EFileType type) const
{
	return (type == TrainingSet) ? fileListTrain.size() : fileListTest.size();
}

std::string Options::GetClassName(EFileType type, int classType) 
{
	std::vector<string> classNames = (type == TrainingSet) ? classNamesTrain : classNamesTest;

	int index = classType - 1;
	int size  = classNames.size();
	if (index >= 0 && index < size)
	{
		return classNames.at( index );	
	} 	
	else
	{
		// build a string 
		return string("");
	}
}

std::string& Options::GetTestFile()
{
	return testFile;
}

void Options::SetTestFile( const std::string& file )
{
	testFile = file;
}

void Options::ParseInput( int argc, char * argv[] )
{
	if (argc <= 1 )
	{
		PrintUsage();
		exit(0);
	}

	int classTypeTrain    = 0;
	int classTypeClassify = 0;	

	for (int i = 1; i < argc; i++)
	{

		string arg1 = argv[i];
	
		if (arg1.find( "-h") == 0)
		{
			PrintUsage();
			exit(0);
		}

		// Parse for input file lists.
		else if (arg1.find( "-i" ) == 0)
		{
			classTypeTrain++;
			string className = arg1.substr(2, arg1.size() );
			int j = 0;
			for ( j = i + 1; j < argc; j++)
			{
				string arg2 = argv[j];
				if (arg2[0] != '-')
				{
					AddFile(TrainingSet, classTypeTrain, className, arg2 );
				} else
				{
					i = j - 1;
					break;
				}
			}
			if (j == argc)
				break;
		}

		// Parse for the clasification file list.
		else if ((arg1.find( "-t" ) == 0) && (arg1 != "-train"))
		{
			classTypeClassify++;
			string className = arg1.substr(2, arg1.size() );
			// Parse until the next setting.
			int j = 0;
			for (j = i + 1; j < argc; j++)
			{
				string arg2 = argv[j];
				if (arg2[0] != '-')
				{
					AddFile(ClassifySet, classTypeClassify, className, arg2 );
				} else
				{
					i = j - 1;
					break;
				}
			}	
			if (j == argc)
				break;
		}

		// Output file.
		else if (arg1 == "-o")
		{
			if ( i + 1 < argc )
			{
				resultFile = argv[++i];
			} else
				PrintUsage();
		}
		// Model File
		else if (arg1 == "-m")
		{
			if ( i + 1 < argc )
				SetModelFile( argv[++i] );
			else
				PrintUsage();
		}
			
		// Kernel 
		else if (arg1 == "-k")    // KernelType gamma=xxx nu=nuvalue svmtype=type coef0=xxx term=yyy  
		{
			// Kernel Type
			if ( i + 1 < argc )
				ParseKernel( argv[++i] );
			else
				PrintUsage();
		}

		// SVM-TYPE
		else if (arg1 == "-y")
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				ParseSVMType( arg2 );
			} else
				PrintUsage();
		}
		// Gamma
		else if (arg1 == "-g")
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				ParseGamma( arg2 );
			} else
				PrintUsage();
		}
		// Nu - value
		else if (arg1 == "-n")
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				ParseNu( arg2 );
			} else
			{
				PrintUsage();
			}
		}
		// Coefficant
		else if (arg1 == "-q")
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				ParseCoefficiant( arg2 );
			} else
			{
				PrintUsage();
			}
		}

		// Degree
		else if (arg1 == "-r")
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				ParseDegree( arg2 );
			} else
			{
				PrintUsage();
			}
		}
		// Termination criterion or splitting fraction.
		else if (arg1 == "-x")
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				if (GetOperation() != OpSplit )
				{
					ParseTerm( arg2 );
				} else
				{
					fraction    = atof(arg2.c_str());
				}
			} else
			{
				PrintUsage();
			}
		}
		// operation
		else if ((arg1 == "-classify") || (arg1 == "-train") || (arg1 == "-validate") || (arg1 == "-split") )
		{
			string arg = arg1.substr( 1, arg1.length());
			ParseOperation( arg );
		}

		// verbose
		else if (arg1 == "-v")
		{
			verbose = true;
		}
		
		// data format.
		else if (arg1 == "-d")
		{
			// Data Type
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				ParseEncoding( arg2 );
			} else
			{
				PrintUsage();
			}
		}
		
		
		// allele swapping
		else if (arg1 == "-a")
		{
			SetSwapAllele( true );
		}

		// full results including intermediates.
		else if (arg1 == "-f")
		{
			SetAllResults( true );
		}

		// snp values.
		else if (arg1 == "-s")
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				ParseSNPData( arg2 );
			} else
				PrintUsage();
		}
		
		// number of expirements
		else if (arg1 == "-e")
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				experiments = atoi( arg2.c_str() );
				ValidateExp( experiments );
			} else
				PrintUsage();
		}

		// number for cross validaton
		else if (arg1 == "-c")
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				crossValidate = atoi( arg2.c_str() );
				ValidateCross(crossValidate );
			} else
				PrintUsage();
		}

		// Propability 
		else if (arg1 == "-p")
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				probability = arg2;
				ValidateProb(probability );
			} else
			{
				PrintUsage();
			}
		}	 
		else if (arg1 == "-u")	// scale factor
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				scaleFactor = atoi( arg2.c_str() );
			} else
			{
				PrintUsage();
			}
		}	 
		else if (arg1 == "-C")	// cost
		{
			if ( i + 1 < argc )
			{
				string arg2 = argv[++i];
				ParseCost( arg2 );
			} else
			{
				PrintUsage();
			}
		}	 
		else
		{
			PrintUsage();
		}
	}

}

int  Options::GetScaleFactor() const
{
	return scaleFactor;
}

void Options::SetScaleFactor(int value )
{
	scaleFactor = value;
}

void Options::ParseSetting( const std::string& setting )
{
	std::string option;
	std::string value;
	int pos = setting.find( "=" );
	int size = setting.length();
	if ((pos > 0) && (pos < size))
	{
		option = setting.substr(0, pos);
		value  = setting.substr(pos + 1, setting.length() - 1);
// KernelType gamma=xxx nu=nuvalue svmtype=type coef0=xxx term=yyy  
		if (option == "svmtype")
			ParseSVMType( value );
		if (option == "gamma")
			ParseGamma( value );
		if (option == "nu")
			ParseNu( value );
		if (option == "coef0")
			ParseCoefficiant( value );	
		if (option == "term")
			ParseTerm( value );	
		if (option == "cost")
			ParseCost( value );	
		if (option == "degree")
			ParseDegree( value );	
	}

}
/*
description        values                             type        default            dependencies

SVM type           C_SVC, NU_SVC                      discrete    NU_SVC
nu                 [0, 1]                             cont.       0.2
C (cost)           (0, inf)                           cont.       1.0
kernel type        linear, polynomial, RBF, sigmoid   discrete    polynomial
degree             [1, inf)                           cont.       3.0                polynomial
gamma              (-inf, inf)                        cont.       1/d                polynomial, RBF, sigmoid
coef0              (-inf, inf)                        cont.       0.0                polynomial, sigmoid
termination crit.  (0, inf)                           cont.       0.00001            NU_SVC
termination crit.  (0, inf)                           cont.       0.001              C_SVC
*/

void Options::ParseDegree( const std::string& strdegree )
{

	if (strdegree == "inf")
	{
		degree = numeric_limits< double >::max();
		return;
	}

	degree = atof( strdegree.c_str());

	if (degree < 1.0)
	{
		// Print Error
		degree = 1.0;
	}
}

void Options::ParseGamma( const std::string& strgamma )
{
	if (strgamma == "-inf")
	{
		gamma = - 1.0 / numeric_limits< double >::max();
		hasGamma = true;
		return;
	}
	if ( strgamma == "inf")
	{
		gamma = 1.0 / numeric_limits< double >::max();
		hasGamma = true;
		return;
	}
	if ( strgamma == "1/d" )
	{
		gamma = 0.0;
		hasGamma = false;
		return;
	}
	gamma = atof( strgamma.c_str() );
	hasGamma = true;

}


void Options::ParseNu( const std::string& strnu)
{
	nu = atof( strnu.c_str() );
	if ( nu < 0.0 || nu > 1.0)
	{
		// Invalid value.
		PrintUsage();
	}

}

void Options::ParseCost( const std::string& strcost )
{
	if ( strcost == "inf")
	{
		cost = numeric_limits< double >::max();
		return;
	}
	
	cost = atof( strcost.c_str() );
	if ( cost < 0.0)
	{
		// Print Error
		PrintUsage();
	}
}

void Options::ParseCoefficiant( const std::string& strcoeff )
{

	if (strcoeff == "-inf")
	{
		coefficiant = - 1.0 / numeric_limits< double >::max();
		return;
	}
	if ( strcoeff == "inf")
	{
		coefficiant = 1.0 / numeric_limits< double >::max();
		return;
	}

	coefficiant = atof( strcoeff.c_str() );
}

void Options::ParseOperation( const std::string& strOperation )
{
	if (strOperation == "train")
	{
		SetOperation( OpTrain );
	} else if (strOperation == "classify")
	{
		SetOperation( OpClassify );
	} else if (strOperation == "validate")
	{
		SetOperation( OpValidate );	
	} else if (strOperation == "split")
	{
		SetOperation( OpSplit );	
	}

}

void Options::ParseTerm( const std::string& strTerm )
{
	if ( strTerm == "inf")
	{
		termCriterion = 1.0 / numeric_limits< double >::max();
		return;
	}

	termCriterion = atof( strTerm.c_str() );
	if (termCriterion == 0.0)
	{
		// Print Error.
		PrintUsage();
	}
	
}

void Options::ParseSVMType( const std::string& svmType )
{
	if (svmType == "NU-SVM")
	{
		SetSVMType( Options::NU_SVMType );
	}
	else if (svmType == "C-SVM")
	{
		SetSVMType( Options::C_SVMType );
	}
	else
	{
		// PrintArgumentError
		PrintUsage();
	}
}


// LINEAR, POLY, RBF, SIGMOID, LA
void Options::ParseKernel( const std::string& strKernel )
{
	if (strKernel == "LINEAR")
	{
		SetKernel( Linear );
	}
	else if (strKernel == "POLY")
	{
		SetKernel( Polynomial );
	}
	else if (strKernel == "RBF")
	{
		SetKernel( RBF );
	}
	else if (strKernel == "SIGMOID")
	{
		SetKernel( Sigmoid );
	} 
	else
	{
		PrintUsage();
	}
}


void Options::ParseSNPData( const std::string& strSNP)
{
	if (strSNP == "ALL") // Local Alignment
	{
		SetSNPData ( AllSNPs );
	}
	else if (strSNP == "NEUTRAL")
	{
		SetSNPData ( NeutralSNPs );
	}
	else if (strSNP == "NONNEUTRAL")
	{
		SetSNPData ( NonNeutralSNPs );
	} else
	{
		PrintUsage();
	}
}

void Options::ParseEncoding( const std::string& strEncoding)
{
	if (strEncoding == "SEQUENCE") 
	{
		SetDataType( Sequence );
	}
	else if (strEncoding == "DECIMAL")
	{
		SetDataType( Decimal );
	}
	else if (strEncoding == "LA")
	{
		SetDataType( LocalAlignment );
	}
	else if (strEncoding == "BINARY2")
	{
		SetDataType( Binary2Bits );			// not impl.	7/18/04
	}
	else if (strEncoding == "BINARY4")
	{
		SetDataType( Binary4Bits );			// not impl		7/18/04
	}
	else
	{
		PrintUsage();
	}	
}

bool Options::ValidateProb  ( const std::string& prob)
{
	double val = atof( prob.c_str() );
	if (val >= 0.0 && val < 1.0)
		return true;
	else
		PrintUsage();
	return false;
}

bool Options::ValidateExp   ( int nExperiments )
{
	if (nExperiments >= 1)
		return true;
	else
		PrintUsage();
	return false;

}

bool Options::ValidateCross ( int nGroups )
{
	if (nGroups >= 2 && nGroups < 15)
		return true;
	else
		PrintUsage();
	return false;

}

bool Options::ValidateLinear()
{
	if (nu < 0.0 || nu > 1.0)
	{
		// printerror;
		return false;
	}

	if (cost < 0.0)
	{
		// printerror
		return false;
	}

	if (termCriterion < 0.0)
	{
		// print error
		return false;
	}

	return true;
}

/*
description        values                             type        default            dependencies

SVM type           C_SVC, NU_SVC                      discrete    NU_SVC
nu                 [0, 1]                             cont.       0.2
C (cost)           (0, inf)                           cont.       1.0
kernel type        linear, polynomial, RBF, sigmoid   discrete    polynomial
degree             [1, inf)                           cont.       3.0                polynomial
gamma              (-inf, inf)                        cont.       1/d                polynomial, RBF, sigmoid
coef0              (-inf, inf)                        cont.       0.0                polynomial, sigmoid
termination crit.  (0, inf)                           cont.       0.00001            NU_SVC
termination crit.  (0, inf)                           cont.       0.001              C_SVC
*/
	
bool Options::ValidatePolynominal()
{
	if ( degree < 1.0 )
	{
		return false;
	}
	// HasGamma();
	// HasCoefficant();
	if (termCriterion < 0.0)
	{
		// print error
		return false;
	}
	return true;
}
	
bool Options::ValidateRBF()
{
	return ValidatePolynominal();
}
	
bool Options::ValidateSigmoid()
{
	return ValidatePolynominal();
}

void Options::PrintUsage()
{
	cout << "PhaseMachine is a machine learning program for supervised classification" << endl;
	cout << "of population haplotypes using Support Vector Machine algorithm." << endl;
	cout << "PhaseMachine analyzes sequences produced by the PHASE haplotype inference program." << endl << endl;
	cout << "Usage: PhaseMachine operation_mode -i[name] input_files [OPTIONS]" << endl << endl;

	cout << "Examples:" << endl;
	cout << "  PhaseMachine -train -iPop1 file1 -iPop2 file2    # build SVM classifier using" << endl;
	cout << "                                                   # PHASE output files `file1' and `file2'" << endl;
	cout << "  PhaseMachine -classify file -m model             # classify sequences in PHASE output file `file'" << endl;
	cout << "                                                   # using SVM model in file `model'               " << endl;
	cout << "  PhaseMachine -validate -iPop1 file1 -iPop2 file2 # perform cross-validation analysis of SVM" << endl;
	cout << "                                                   # classifier built using `file1', `file2'      " << endl;
	cout << "  PhaseMachine -split file                         # split PHASE output file `file'" << endl;
	cout << "                                                   # into training and test subsets (files)" << endl << endl;

	cout << "Main operation mode:" << endl;
	cout << "  -train             build SVM classifier (model) using given training data" << endl;
	cout << "  -classify          classify test sequences using a previously built model" << endl;
	cout << "  -validate          perform cross-validation experiments using given training data" << endl;
	cout << "  -split             split PHASE output file to create training and test data sets" << endl << endl;

	cout << "Training, cross-validation and prediction (classification) options:" << endl;
	cout << "  -i[name] <files>   population name and PHASE file(s) containing population sequences" << endl;
	cout << "                     training and cross-validation require at least 2 populations" << endl;
	cout << "  -d encoding        sequence encoding ([DECIMAL], BINARY2, BINARY4, LA)" << endl;
	cout << "                     DECIMAL: A=1, T=2, C=3, G=4; BINARY2: A=00, T=01, C=10, G=11" << endl;
	cout << "                     BINARY4: A=0001, T=0010, C=0100, G=1000; LA: vector of Smith-Waterman scores" << endl;
	cout << "  -s SNPs            use all, non-neutral, or neutral SNPs ([ALL], NEUTRAL, NONNEUTRAL)" << endl;
	cout << "  -p probability     min. PHASE probability for sequence to be included in analysis ([0.0], 0..1)" << endl;
	cout << "  -o file            output file ([output.dat])" << endl;
	cout << "  -v                 verbose output" << endl << endl;

	cout << "Training and prediction (classification) options:" << endl;
	cout << "  -m file            SVM model (classifier) file name ([model.dat])" << endl << endl;

	cout << "Training and cross-validation options:" << endl;
	cout << "  -y SVM_type        SVM type ([C-SVM], NU-SVM)" << endl;
	cout << "  -k kernel_type     kernel type ([RBF], LINEAR, POLY, SIGMOID)" << endl;
	cout << "  -C cost            C-SVM cost parameter ([1.0], 0..inf)" << endl;
	cout << "  -n nu              NU-SVM nu parameter ([0.2], 0..1.0)" << endl;
	cout << "  -g gamma           SVM gamma parameter for RBF, POLY, SIGMOID kernels ([0.01], 0..inf)" << endl;
	cout << "  -q coefficient     c_0 coefficient for POLY and SIGMOID kernels ([0.0], -inf..inf)" << endl;
	cout << "  -r degree          POLY kernel degree parameter ([3.0], 0..inf)" << endl << endl;

	cout << "Cross-validation options:" << endl;
	cout << "  -c folds           number of cross-validation subsets ([10], 2..inf)" << endl;
	cout << "  -e experiments     number of cross-validation experiments ([10], 1..inf)" << endl << endl;

	cout << "Split options:" << endl;
	cout << "  -x fraction        fraction of individuals assigned to test set ([0.5], 0..1)" << endl;
	cout << "                     output goes to [name_]test.dat, [name_]training.dat" << endl;

	exit(0);

}

