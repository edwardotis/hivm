#ifndef CLIENT_H
#define CLIENT_H

#include "std_include.h"

#ifdef CPPUNIT
	#include "unit_tests/TestRun.cpp"
#endif

//#include <dirent.h>
#include "PreProcessor.h"
#include "WorkUnit.h"
#include "OptionsAdapter.h" 
#include "HivPreProcessor.h"
#include "LaBioProcessor.h"
#include "SvmPreProcessor.h"


/**
 * USE ifdef unitTests, to decide who get's main()

 *  @includes PreProcessor.h 
 **/
class Client{

typedef vector<WorkUnit*>::iterator wuIterator;
typedef vector<WorkUnit*>           wuSet;

public:

/**
 * PLACE FILE INPUT STREAM INTO PreProcessor Class
 * pass this class the file name from cmd line
 */

//ifstream * getFile( string str );
	
public:
  /**
   * @fn Client() constructor
   * @param void
   * @pre None
   * @return None
   */
	Client( );

	//default constructor
//	Client();

	//	Client( OptionsAdapter& );
	
	/**
   * @fn Client() destructor
   * @param void - nothing
   * @pre None
   * @return None
   */	
	virtual ~Client();


	/**
	@purpose main entry point into hivm. Decides which hivm functionality
	to use.
	@param cmd line arguments. parsed to determine choice of functionality
	@choices: 
		normal functions:
		-library - creates libraries for hivm to use for prediction
		-predict - typical use for predicting unknown sequences using the libraries
		
		debugging functions:
		-variabilityTest - randomly shuffle dataset, and test specific parameter pair
		so that effect of chance variability can be calculated in a spreadsheet.
		-eval - evaluation of hivm performance

	*/
	virtual void run(  int argc,  char * argv[] );

	/**
	@purpose run prediction on test set using chosen param
	*/
	//virtual void runTest();

	virtual vector<WorkUnit*>&  getTrainSet();
	virtual vector<WorkUnit*>&  getClassifySet();
	virtual vector<WorkUnit*>&  getFullSet();

	//PREDICTION MANAGER FUNCTIONS and MEMBERS
	vector<string> drugSet;
	vector<string> drugTypeSet;
	vector<double> thesholdsSetLow;
	vector<double> thesholdsSetDefault;
	vector<double> thesholdsSetHigh;




protected:
	
	//prediction functions and members
	double cost_;
	double gamma_;
	double tpr_;
	double fpr_;
	double auc_;

	//validatelibrary helpers
	
	//switch between c,g parameter search
	//or using single c,g pair
	bool isSinglePair_;

	/**
	@purpose run validation on single c,g pair
	@param isSinglePair one c,g pair or many?
	*/
	void validatelibrary2_( string i_drug, bool isSinglePair );

	/**
	@purpose run validation on range of c,g pairs
	range is set in the configDefault.txt file.
	*/
	//void validatelibraryRangeOfPairs_( int i_cost, int i_gamma, string i_drug, Stats& o_stat );

	///**
	//@purpose update tpr, fpr, tnr, fpr

	//*/
	//void updateLibValidation_( isResistant );

	/**
	@purpose save the cumulative library validation stats
	*/
	void saveLibValidationStats_( Stats& i_Stat, string descriptor );



	/**
	@purpose run known seqs against libraries to see how
	well the libraries perform
	*/
	void validatelibrary_();

	/**
	@purpose produce data for use in variability test.
	- take full dataset as wu
	- shuffle randomly w/ random seed
	- remove 1/3
	- cross validate on c,g pair from cmd line
	- output c,g pair tpr, fpr to screen (for easy excel use)
	*/
	void variabilityTest_();
	

	/**
	@purpose parses a file of drugs that have a library entry
	*/
	void parsetDrugSet_( string drugListFileName, string enzymeType );


	/**
	@purpose updates a single sequence's resistance profile
	@param was the latest predicton resistant or not
	@param output stringstream
	*/
	void updateProfile_( bool isResistant, stringstream& o_stream );

	/**
	@purpose save a profile for a single aa sequence
	@param stringstream should contain contents of a single
	aa seq's resistance to all drugs in the library
	@param identifier. preferably the isolate name
	*/
	void saveProfile_( stringstream& i_stream, string identifier );

	/**
	@purpose create WorkUnits for prediction only, out of hivdb file format
	@param
	@param
	@param drug name for next run
	*/
	void parsePredictionInputHivDb_( string i_inputFileName, vector<WorkUnit*>& o_wus,  string i_drug );



	/**
	@purpose create WorkUnits out of input of sequences to be predicted
	sequences must be fasta format
	@param filename
	@parm output vector to hold newly made WorkUnits
	*/
	void parsePredictionInput_( string i_inputFileName, vector<WorkUnit*>& o_wus );
	
	/**
	@purpose for each drug in a drug resistance profile, the Options must
	be updated to reflect that drug and its threshold
	@param drug name
	*/
	void updatePredictionOptions_( string i_drug )	 ;

	/**
	@purpose go to correct theshold level file and find out
	threshold for the passed in drug. 
	Sets the found value in OptionAdapter
	@prereq threshold level must have been set in OptionsAdptr
	*/
	void setThresholdFromFile_( string i_drug );


	/**
	@purpose reads in the auto-params file for the drug, 
	and updates OptionsAdapter cost and gamma from this file.
	Also, updates auc, tpr, fpr for a drug's results file
	*/
	void parseAutoParams_( string i_drug );

	/**
	@purpose run a performance evaluation of hivm
	for a particular drug and threshold
	*/
	virtual void evaluateHivmPerformance_();

	/**
	@purpose Create a library for hivm to use for predicting
	*/
	virtual void createLibrary_();

	/**
	@purpose Create a stripped down library for use in variability test
	*/
	virtual void createLibraryBasic_();

	/**
	@purpose find best library parameters
	*/
	virtual void findBestLibraryParams_();

	/**
	@purpose predict unknown sequences
	*/
	virtual void predictUnknownSeqs();

	friend class TestClient;

	vector<WorkUnit*> fullWus;
	vector<WorkUnit*> trainWus;
	vector<WorkUnit*> classifyWus;//test set

	//for cleaning up the class from the constructor
	void destroyWorkUnitContainer( wuSet );

	HivPreProcessor *myHivPreProc; //get's my raw data ready for kernels
	//Kernel *myKernel;//	kernel to compute pattern recognition


	OptionsAdapter optAdptr_;

private:



	//copy constructor
	Client( const Client& );


	//assignment operator
	Client& operator= ( const Client& );

};

#endif // CLIENT_H

