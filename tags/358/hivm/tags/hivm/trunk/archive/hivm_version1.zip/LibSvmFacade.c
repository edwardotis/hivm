#include "LibSvmFacade.h"

//LibSvmFacade::LibSvmFacade()
//{}
//
//LibSvmFacade::~LibSvmFacade()
//{}

//void LibSvmFacade::svm_destroy_param(struct svm_parameter *param)
//{
//	svm_destroy_param( param );
//}
//
//void LibSvmFacade::svm_destroy_model(struct svm_model *model)
//{
//	svm_destroy_model( model );
//}
