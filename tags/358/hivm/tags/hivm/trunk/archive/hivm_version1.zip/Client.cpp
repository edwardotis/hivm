#include "Client.h"
//#include "unit_tests/TestLaBioProcessor.cpp"

Client::Client() :
isSinglePair_( true )
{
}


void Client::run(  int argc,  char * argv[] )
{
	string purpose = optAdptr_.parseInput( argc, argv );

	if( purpose == "-unit_tests" )
	{
		#ifdef CPPUNIT
			TestRun t;
			t.run();
		#else 
			cout << "Sorry, the Preprocessor definition, 'CPPUNIT',";
			cout << " was not defined during compilation." << endl;
			cout << "Please make sure that you have installed cppunit onto your system before running the unit tests." << endl;
			cout << "Also, make sure that 'CPPUNIT' is defined." << endl;
			cout << "CppUnit is an open source unit testing framework for C++. It is available from: http://cppunit.sourceforge.net " << endl;
			//optAdptr_.printUsage();
			exit(0);
		#endif

				
	}
	else if( purpose == "-eval" )//DEPRECATED
	{
		cout << "Sorry, the -eval function is not supported any more." << endl;
		optAdptr_.printUsage();
		exit(0);
		//evaluateHivmPerformance_();
	}
	else if( purpose == "-library" )
	{
		createLibrary_();
		findBestLibraryParams_();
	}
	else if( purpose == "-profile" )
	{
		cout << "Sorry, there is a new bug in the 'profile' function that hasn't been fixed. Exiting..." << endl;
		exit(0);
		predictUnknownSeqs();
	}
	else if( purpose == "-validatelibrarySinglePair")
	{
		//ok, I've got 3 ways to use -val in my head
		//1. one drug, one c,g pair (current)
		//2. all drugs from drugset.txt. one c,g pair from autoparams.txt per drug. (original)
		//3. one drug, range of c,g pairs from config.txt. [and a whole lot of data generated and saved to files] (next version)
		//I think 2 is out for good. autoparams didn't do well anyhow.
		//so, just need a cmd line switch between v1 and v3. maybe -range after the drug name?
		//then what? 
		//I need to mix validatelibrary with some elements of library.
		//new function or switches inside the current vallibrary?
		//new function based upon cutandpaste from old sounds acceptable at this point. or if I sleep, I can easily see
		//where I just make subfunctions out of the common shit. still:
		//can I loop through validatelibrarySinglePair_() for each c,g coming in. (and with a Results collection, like -library)
		//or just make that and validatelibraryRange_()?
		isSinglePair_ = true;
		validatelibrary_();
	}
	else if( purpose == "-validatelibraryParamSearch")
	{
		isSinglePair_ = false;
		validatelibrary_();
	}
	else if( purpose == "-variabilityTest")
	{
		isSinglePair_ = true;

		//create library with the new training dataset.
		createLibraryBasic_();

		//run cross-validation of cmd line c,g parameters
		variabilityTest_();
	}
	else
	{
		cout << "Sorry, " << purpose << " is not a valid parameter to run hivm." <<endl;
		optAdptr_.printUsage();
		//cout << "Hit any key and Enter to exit" << endl;
		//char c;
		//cin >> c;
		exit(0);
	}
}

//make wu's out of fasta file
/**
>CA39292
dfkjdkfdfldj
sdfkdjf
>CA3993
dlkfkjdjfdkf
dsfkljdfkldjf
etc....
*/
void Client::parsePredictionInput_( string i_inputFileName, vector<WorkUnit*>& o_wus )
{
	//get input file
	stringstream path;
	path << "";

	stringstream inputStream;

	stringstream inputFileName;
	inputFileName << i_inputFileName;

	IO::readFile( inputFileName, inputStream, path ); 

	//now split it up by '>'
	StringTokenizerAdapter _strTok;
	_strTok.setString( inputStream.str(), ">" );

	//get each sequence out of the input file
	while( _strTok.hasMoreTokens() )
	{
		WorkUnit *wu = new WorkUnit();

		string nameAndSeq = _strTok.nextToken();
		//check for empty token
		if( nameAndSeq != "" )
		{
			//now split it up by new line
			StringTokenizerAdapter _strTok2;
			_strTok2.setString( nameAndSeq, "\n" );
			
			//1st line is the isolate/fasta name
			wu->setIsolateName( _strTok2.nextToken() );

			//build aa sequence
			stringstream _aaSeq;
			while( _strTok2.hasMoreTokens() )
			{
				_aaSeq << _strTok2.nextToken();
			}
			
			wu->setAaSeq( _aaSeq.str() );
		}

		o_wus.push_back( wu );
	}

	//DebugHelper::debug( o_wus, true );
}

//make wu's out of hivdb file
/**
>CA39292
dfkjdkfdfldj
sdfkdjf
>CA3993
dlkfkjdjfdkf
dsfkljdfkldjf
etc....
*/
void Client::parsePredictionInputHivDb_( string i_inputFileName, vector<WorkUnit*>& o_wus, string i_drug )
{
	//get input file
	//stringstream path;
	//path << "";

	//stringstream inputStream;

	//stringstream inputFileName;
	//inputFileName << i_inputFileName;

	//IO::readFile( inputFileName, inputStream, path ); 

	//ok, we temporarily set 'dataset' to the predictee input filename.
	//this is ok, b/c we call parse() each iteration before doing prediction, cache hits, etc
	optAdptr_.dataSet( i_inputFileName );

	//set drug name
	optAdptr_.drug( i_drug );

	//b/c we just set the dataset to the predictee, we will get WU's made out of that file :)
	//and we can use those for the testing of the libraries
	HivPreProcessor _hpp( this->optAdptr_ );
	_hpp.parse( o_wus, false );
	

}

void Client::setThresholdFromFile_( string i_drug )
{
//	threshold  (from library file: low, default, high file)
	/**
	file looks like this:
	#Default Thresholds according to http://195.37.60.133/cgi-bin/g2p_contact.pl
	#DRUG THRESHOLD COST GAMMA
	ZDV 8.5
	DDC 2.5
	DDI 2.5
	*/
	stringstream thesholdsFileName;
	thesholdsFileName << optAdptr_.thresholdsLevel() << "_thresholds.txt";
	
	stringstream thresholdsFile;
	if( IO::readFile( thesholdsFileName, thresholdsFile, optAdptr_.libraryPath() ) == false )
	{
		cout << "Error reading Thresholds file" << endl;
	}

	StringTokenizerAdapter _strtok;
	_strtok.setString( thresholdsFile.str(), "\n" );//split on std::endl
	while( _strtok.hasMoreTokens() )
	{
		StringTokenizerAdapter _strtok2;
		_strtok2.setString( _strtok.nextToken(), " " );
		while (_strtok2.hasMoreTokens() )
		{
			if( _strtok2.nextToken() == i_drug )
			{
				//is this working correctly?
				optAdptr_.threshold( _strtok2.nextFloatToken() );
			}
		}
	}
}



void Client::parseAutoParams_( string i_drug )
{



//	susceptibility dataset (from library, parse correct name)
//		//-additionally, the library dataset file doesn't use a threshold to make it.
		//so, remove that from the name.	
//so, 
	stringstream datasetFileName;
	datasetFileName << optAdptr_.libraryPath();
	//datasetFileName << "lib_" << i_drug;
	//datasetFileName << "_threshold-" << optAdptr_.threshold();
	datasetFileName << i_drug;
	datasetFileName << "_dataset.txt";

	optAdptr_.dataSet( datasetFileName.str() );

	
	//@todo save these filenames somewhere in Optionsadapter instead of
	//recreating them like this.
	stringstream libraryParamsFileName;
//	libraryParamsFileName << "lib_" << i_drug;
	libraryParamsFileName << i_drug;
	libraryParamsFileName << "_threshold-" << optAdptr_.getThresholds().front();
	libraryParamsFileName << "_auto_params.txt";

	stringstream inAutoParams;
	
	if( IO::readFile( libraryParamsFileName, inAutoParams ,optAdptr_.libraryPath() ) == false )
	{
		//cout << "Error reading auto_params file" << endl;
	}
	
	//parse autoparams
	//where do cost and gamma go? the get set in options.
	//the rest are just for the output file.
	StringTokenizerAdapter _strTok;

	//breakup by newline
	_strTok.setString( inAutoParams.str(), "\n" );

	while( _strTok.hasMoreTokens() )
	{
		string line = _strTok.nextToken();
		//breakup by ':'
		StringTokenizerAdapter _strTok2;
		_strTok2.setString( line, ":" );
		
		while( _strTok2.hasMoreTokens() )
		{
			string descriptor = _strTok2.nextToken();
			
			//look through labels
			//if( descriptor.find( '#', 0 ) != 0 )
			//{	
			//	//commented lines start with '#' in the files.
			//}
			if( descriptor == "estimated_tpr" )
			{
				tpr_ = _strTok2.nextFloatToken();
			}
			else if( descriptor == "estimated_fpr" )
			{
				fpr_ = _strTok2.nextFloatToken();
			}
			else if( descriptor == "auc" )
			{
				auc_ = _strTok2.nextFloatToken();
			}
			else if( descriptor == "cost" )
			{
				cost_ = _strTok2.nextFloatToken();
				optAdptr_.setCost( cost_ );
			}
			else if( descriptor == "gamma" )
			{
				gamma_ = _strTok2.nextFloatToken();
				optAdptr_.setGamma( gamma_ );
			}
			else if( descriptor == "numTrainingSamples" )
			{
				int i = _strTok2.nextIntToken();
			}
			else
			{
				string badline = _strTok2.nextToken();
				if( badline != "" )
				{
					cout << "Error parsing auto param file" << endl;
					cout << badline << endl;
				}
			}
		}
	}

//3952558381_APV_470samples_best_parameters_stats.txt
	/**
	and special for results:
//	cost (from library, auto params)
//	gamma (from library, auto params)
	tpr(from library, auto params)
	fpr(from library, auto params)
	auc(from library, auto params)
	
	*/
}

//@todo error checking, etc
void Client::updatePredictionOptions_( string i_drug )
{	
	//things to set

	//drug name
	optAdptr_.drug( i_drug );

	//threshold for drug
	//setting this required b efore using rest of this.
	setThresholdFromFile_( i_drug );

	//cost and gamma for the prediction are set
	//also stats for results output file
	parseAutoParams_( i_drug );

	//set orig virus seq (RT or PI )
	int index = 0;
	vector<string>::const_iterator it;
	for(it=drugSet.begin();it!=drugSet.end();it++)
	{
		if( (*it) != i_drug )
		{
			index++;
		}
	}
	if( drugTypeSet.at( index ) == "PI" )
	{
		optAdptr_.origVirusSeqFileName( "library/PI.seq" );
		optAdptr_.origVirusSeq( "library/PI.seq" );
	}

	if( drugTypeSet.at( index ) == "RT" )
	{
		optAdptr_.origVirusSeqFileName( "library/RT.seq" );
		optAdptr_.origVirusSeq( "library/RT.seq" );
	}

		
}

void Client::parsetDrugSet_( string drugListFileName, string enzymeType )
{
//	threshold  (from library file: low, default, high file)
	/**
	file looks like this:
#Drugs that have a library entry for creating drug profile
#DRUG
APV
D4T
	*/
	stringstream fileName;
	fileName << drugListFileName;
	
	stringstream inFile;
	IO::readFile( fileName, inFile, optAdptr_.libraryPath() );

	StringTokenizerAdapter _strtok;
	_strtok.setString( inFile.str(), "\n" );//split on std::endl
	while( _strtok.hasMoreTokens() )
	{
		string line = _strtok.nextToken();
		if( line.find( '#', 0 ) != 0 )//commented lines start with '#' in the files.
		{
			//check for lines with chosen enzyme type only
			if( line.find( "enzymeType", 0 ) != 0 )
			{
				StringTokenizerAdapter _strtok2;
				_strtok2.setString( line, " " );//split on space
				
				drugSet.push_back( _strtok2.nextToken() );
				drugTypeSet.push_back( _strtok2.nextToken() );
			}
		}
	}
}

//void Client::updateLibValidation_( bool isResistant, WorkUnit* wu )
//{
//	//ok, 
//}

//updates a single sequence's resistance profile.
void Client::updateProfile_( bool isResistant, stringstream& o_stream )
{
	o_stream << optAdptr_.getDrug() << ",";
	o_stream << optAdptr_.threshold() << ",";
	if( isResistant == true )
	{
		o_stream << "T" << ",";
	}
	else
	{
		o_stream << "F" << ",";
	}
	
	o_stream << this->cost_  << ",";
	o_stream << this->gamma_ << ",";
	o_stream << this->tpr_ << ",";
	o_stream << this->fpr_ << ",";
	o_stream << this->auc_ << ",";
	o_stream << endl;

}

void Client::saveProfile_( stringstream& i_stream, string identifier )
{
	//create header
	stringstream outstream;
	outstream << "DRUG,THRESHOLD,RESISTANT? (True/False),Log2Cost,Log2Gamma,Estimated TPR,Estimated FPR,AUC:" << endl;

	//add contents of each resistance for each drug in the library
	outstream << i_stream.str();

	//now write to results folder
    stringstream fileName;
	fileName << identifier;
	fileName << "_hiv_drug_resistance_profile.csv";

	stringstream inFile;
	IO::writeFile( fileName, outstream, optAdptr_.resultsPath() );

	cout << "Saved " << identifier << " drug resistance profile to results directory." << endl;
}


void Client::saveLibValidationStats_( Stats& i_Stat, string descriptor )
{
	//print to screen
	i_Stat.print();
	i_Stat.printClassInfo();

	//save to file
	stringstream outfile;
	i_Stat.print( outfile );
	i_Stat.printClassInfo( outfile );

	stringstream fileName;
	fileName << descriptor << "_";
	fileName << optAdptr_.thresholdsLevel() << "-thresholds_";
	//fileName << optAdptr_.predicteeSeqsFileName();
	fileName << "_Library_Validation.txt";

	IO::writeFile( fileName, outfile, this->optAdptr_.resultsPath() );

}

void Client::variabilityTest_()
{
	//cout << "Running Variability Test..." << endl;
	bool isLibrary = true;//creating a library
	
//scale the data
	SvmPreProcessor _svmPreProc( optAdptr_ );
	_svmPreProc.scale( getTrainSet() );
	_svmPreProc.scale( getClassifySet() );

	//set location for ROC curve data to be saved as library
	optAdptr_.resultsPath( "variability_test/" );

	//find optimal parameters for training model
	//and create ROC curve
	{
		//cout << "Finding best parameters using 10 fold cross validation..." << endl;
		LibSvmAdapter libAdptr( optAdptr_ );
		Stats _crossValidationStat( optAdptr_ );
		int cvFold = 10;
		
		//is this the missing link?
		WorkUnit::initActivePositions( getTrainSet().size() );
		
		libAdptr.crossValidate( getTrainSet(), cvFold, optAdptr_.cmdLineCost(), optAdptr_.cmdLineGamma(), _crossValidationStat );
		//_svmPreProc.findBestParameters( getTrainSet(), libAdptr, 10, optAdptr_ );
		
		cout << _crossValidationStat.cost() << "," << _crossValidationStat.gamma() << "\t";
		cout << _crossValidationStat.truePositiveRate();
		cout << "\t" << _crossValidationStat.falsePositiveRate() << endl;
#ifdef DEBUG	
		DebugHelper::debug( _crossValidationStat, true );
#endif
	}	


	//_svmPreProc.saveLibraryStats();//
	//_svmPreProc.printBestStats( 0 );
	//_svmPreProc.printBestStats(1);

	//fuck this. cut and paste.
	//how do I make the	WU's. then cut 1/3 out nicely?
	//fuck if I know.
	//just do creatLibrary2 or something.

	/**
	a. use virtual functions in a new class to extend my existing createLibrary function
	b. use perl/python to script the shuffle and 1/3 cut. then call function to 
	-create library
	-run a single pair cv. on library
	c. and figure way to get results into excel cleanly
	*/

}

void Client::validatelibrary_()
{
	cout << "Validating library..." << endl;
	bool isLibrary = false;//not creating a library

	//load up the drugs we are actively working with. aka Drug Set
	//if I give a drug that doesn't have a library entry, my current code will crash
	//@todo set this name in a more centralized list of file names/locations
	//@todo Make a choice between 'validate all drugs' and 'validate 1 drug from cmd line'
//	parsetDrugSet_( "drugset.txt", optAdptr_.enzyme() );

	//ok, so we're switching from 'do all' to one at a time from cmd line.
	//@todo check drugset.txt to see if drug lib has been created for the cmd line drug
	drugSet.push_back( optAdptr_.getDrug() );

	//@todo use drugset.txt to determine type of cmdline drug, PI or RT
	//we only have PI today.
	drugTypeSet.push_back( "PI" );


	//to hold overall stats on the lib validation
	//Stats cumulativeStat( this->optAdptr_ );
	////initialize stat
	//cumulativeStat.setCost ( 0 );
	//cumulativeStat.setGamma( 0 );


	//stringstream profileStream;
	//DebugHelper::debug( validateLibrarySet, true );
	

	//working instance of Stat
	//Stats _crossValidationStat(m_optAdptr);
	//OptionsAdapter _optAdptr;

	//this loop is run only once, if we get a drug from cmd line.
	vector<string>::const_iterator drugIt;
	for( drugIt=drugSet.begin(); drugIt!=drugSet.end(); drugIt++ )
	{
		validatelibrary2_( *drugIt, isSinglePair_ );

	}//end drug run



	//@todo Make a stat for each drug, and save that so we can see if
	// this predicts some drugs much better than others. 
	//saves a single sequence's resistance profile.
	//saveProfile_( profileStream, (*seqWuIt)->getIsolateName() );
	//saveLibValidationStats_( cumulativeStat, "Cumulative" );
		
	cout << "Finished running library validation.." << endl;	
}

//void Client::validatelibraryRangeOfPairs_( int i_cost, int i_gamma, string i_drug, Stats& o_stat )
//{
//}

void Client::validatelibrary2_( string i_drug, bool isSinglePair_ )
{
	cout << endl << i_drug << endl;

	//@todo make sure this updates my categories correctly
	updatePredictionOptions_( i_drug );//
	
	//storage for sequences to be classified
	vector<WorkUnit*> validateLibrarySet;

	//loads the known predictee hivdb set into wu's, for each drug
	parsePredictionInputHivDb_( optAdptr_.predicteeSeqsFileName(), validateLibrarySet, i_drug );

	//run this again to reset dataset correctly for cache hits.
	updatePredictionOptions_( i_drug );//

	//to hold  stats for each drug during the lib validation
	//Stats drugStat( this->optAdptr_ );
	//initialize stat


	//Q. Should validateLibSet and getClassifySet be the same?
	//right now, I push valSet 1 at a time onto classifyset. is that right?
	//vector<WorkUnit*>::const_iterator seqWuIt;
	//for( seqWuIt = validateLibrarySet.begin(); seqWuIt != validateLibrarySet.end(); seqWuIt++ )
	//{
		this->optAdptr_.numSamplesToUse( 0 );//set to use all samples. I know, isn't 0==all intuitive? :)

		//sets the current fasta input sequence into the classifySet one at a time, 
		//before each drug run
		//getClassifySet().push_back( (*seqWuIt) );
		DebugHelper::debug( getClassifySet(), false );

	//	DebugHelper::debug( drugSet, true );

		int cacheId;
		bool isLibrary = false;

		// loads FullSet with correct number of values from library
		//b/c library input dataset is set in prev function
		//fullset is from library and will equal trainset
		{
			cout << "Preprocessing..." << endl;
			HivPreProcessor myHivPreProc( optAdptr_ ); 
			myHivPreProc.parse( getFullSet(), isLibrary );
			getTrainSet() = getFullSet();//two vectors pointing to same content
			getFullSet().clear();//remove fullSet's pointers to the same Wu's
			cacheId = myHivPreProc.cacheId();
			DebugHelper::debug( getTrainSet(), false );
		}

//			DebugHelper::debug( getTrainSet(), true );

		//look for cache hit
		{
			cout << "Local Alignment Preprocessing..." << endl;
			LaBioProcessor laBio;
			bool cacheHit =  laBio.checkCache( optAdptr_, getTrainSet(), isLibrary, cacheId );
			laBio.process( getTrainSet(), validateLibrarySet, cacheHit );
			if( cacheHit == false)//don't save same cache twice
			{
				//cout << "Error loading library for drug: " << (*drugIt) << endl;
				//cout << "Hit 'x' and Enter to exit." << endl;
				//char c;
				//cin  >> c;
				//exit(0);
				cout << "Finishing creating Local Alignment matrix, and saving it to cache." << endl;
				laBio.saveCache( optAdptr_, getTrainSet(), isLibrary, cacheId );
			}
		}

		DebugHelper::debug( getTrainSet(), false );

		//scale the data
		
		SvmPreProcessor _svmPreProc( optAdptr_ );
		_svmPreProc.scale( getTrainSet() );
		_svmPreProc.scale( validateLibrarySet );

		
		
		//make prediction, and update results stat 
		{
			LibSvmAdapter libAdptr( optAdptr_ );

			//Q. and this guy. there's a problem here. (may have fucked up old validate too.)
			//I'm predicting single seqWuIt, but I have been using getclassifyset() to build
			//up the model. got a conflict here.
			//I think I should send the whole classifyset in here.
			//libAdptr.predictionTest( getTrainSet(), (*seqWuIt), o_stat );
			DebugHelper::debug( validateLibrarySet, false);
			
			//get ready


			if( isSinglePair_ == true ) 
			{
				cout << "Predicting using: cost = " <<  optAdptr_.cmdLineCost();
				cout << " and gamma = " << optAdptr_.cmdLineGamma() << endl;
				//HERE IS WHERE COST AND GAMMA CAN BE WRITTEN SAFELY FROM CMD LINE
				//ok, get them here.
				optAdptr_.setCost( 	optAdptr_.cmdLineCost()  );
				optAdptr_.setGamma( optAdptr_.cmdLineGamma() );

				Stats _valLibraryStatSingle( optAdptr_ );

				_valLibraryStatSingle.setCost(  optAdptr_.cost()  );
				_valLibraryStatSingle.setGamma( optAdptr_.gamma() );
				
				libAdptr.predictionTest( getTrainSet(), validateLibrarySet, _valLibraryStatSingle );

				saveLibValidationStats_( _valLibraryStatSingle, i_drug );
			}
			else//need to compute a range of c,g pairs
			{
				cout << endl;
				cout << "Finding the best parameters via a grid search. This may take a while." << endl;

				double _c = DBL_MIN;
				double _g = DBL_MAX;

				//hold the data points
				Stats _dataPointSet( optAdptr_ );
		
				//broad grid search
				for( _c = optAdptr_.costLow(); _c <= optAdptr_.costHigh(); _c += optAdptr_.costIncrement() )
				{
					for( _g = optAdptr_.gammaLow(); _g <= optAdptr_.gammaHigh(); _g += optAdptr_.gammaIncrement() )
					{
						Stats _valLibraryStat( optAdptr_ );
						_valLibraryStat.setCost( _c );
						_valLibraryStat.setGamma( _g );

						//update the svm_param for cross validation
						optAdptr_.setCost(  _c  );
						optAdptr_.setGamma( _g );

						//validatelibrarySinglePair_( _c, _g, *drugIt, _valLibraryStat );
						libAdptr.predictionTest( getTrainSet(), validateLibrarySet, _valLibraryStat );

						_svmPreProc.updateBestStats_( _valLibraryStat );

						_dataPointSet.updateDataPointSet( 
							_g,
							_c,
							_valLibraryStat.truePositiveRate(), 
							_valLibraryStat.falsePositiveRate(),
							_valLibraryStat.trueNegativeRate(), 
							_valLibraryStat.falseNegativeRate()
						);
					}
					cout << ".";
				}//end outer for loop
				
				//saveLibValidationStats_( _valLibraryStat, optAdptr_.getDrug() );

				//finish up
					cout << endl;
				cout << "Finished search!" << endl;
				cout << endl;
				//cout << "Saving parameters for testing from Best TPR-FPR Difference found:" << endl;

				//_svmPreProc.storeBestParameters( optAdptr_, _svmPreProc.bestTprFprDifference_.cost(),
				//	_svmPreProc.bestTprFprDifference_.gamma() );

				_svmPreProc.areaUnderCurve_ = _dataPointSet.computeAreaUnderROCCurve();

				//write datapoints to file for use by a graphing tool
				//true means save file of pruned datapoints
				_dataPointSet.saveDataPoints( false );
				_dataPointSet.saveDataPoints( true );
				//set location for results

				_svmPreProc.saveLibraryStats();

				_svmPreProc.printBestStats( 0 );
				_svmPreProc.printBestStats(1);
			}
	
			
			//bool isResistant =	libAdptr.predictIsResistant( getTrainSet(), (*seqWuIt) );
			
			//@TODO update this to store cumulative stats on tp,fp,tn,fn
			//updates a single sequence's resistance profile.
			//updateLibValidation_( isResistant, seqWuIt );
			//updateProfile_( isResistant, profileStream );
		}

		destroyWorkUnitContainer( getFullSet() );
		destroyWorkUnitContainer( getTrainSet() );

		//classifySet was given WU by validateLibrarySet
		//so, let validateLibrarySet handle destruction of that set.
		getClassifySet().clear();

		getFullSet().resize(0);
		getTrainSet().resize(0);
		getClassifySet().resize(0);

		cout << ".";//something to know it's working
	//}//end sequence run
	
	destroyWorkUnitContainer( validateLibrarySet );
	validateLibrarySet.clear();
	validateLibrarySet.resize(0);

	
}

void Client::predictUnknownSeqs()
{
	cout << "Predicting unknown sequences..." << endl;
	bool isLibrary = false;//not creating a library

	//load up the drugs we are actively working with. aka Drug Set
	//if I give a drug that doesn't have a library entry, my current code will crash
	//@todo set this name in a more centralized list of file names/locations
	parsetDrugSet_( "drugset.txt", optAdptr_.enzyme() );
	

	//load up sequences to be classified
	vector<WorkUnit*> resistanceProfileSet;
	parsePredictionInput_( optAdptr_.predicteeSeqsFileName(), resistanceProfileSet );

	cout << "Creating Resistance Profiles." << endl;

	vector<WorkUnit*>::const_iterator seqWuIt;
	for( seqWuIt = resistanceProfileSet.begin(); seqWuIt != resistanceProfileSet.end(); seqWuIt++ )
	{
		stringstream profileStream;
		//DebugHelper::debug( resistanceProfileSet, true );

		vector<string>::const_iterator drugIt;
		for( drugIt=drugSet.begin(); drugIt!=drugSet.end(); drugIt++ )
		{
			//sets the current fasta input sequence into the classifySet, 
			//before each drug run
			getClassifySet().push_back( (*seqWuIt) );

		//	DebugHelper::debug( drugSet, true );

			int cacheId;
			updatePredictionOptions_( (*drugIt) );//
			// loads FullSet with correct number of values from library
			//b/c library input dataset is set in prev function
			//fullset is from library and will equal trainset
			{
				HivPreProcessor myHivPreProc( optAdptr_ ); 
				myHivPreProc.parse( getFullSet(), isLibrary );
				getTrainSet() = getFullSet();//two vectors pointing to same content
				getFullSet().clear();//remove fullSet's pointers to the same Wu's
				cacheId = myHivPreProc.cacheId();
			}

			//look for cache hit
			{
				LaBioProcessor laBio;
				bool cacheHit =  laBio.checkCache( optAdptr_, getTrainSet(), isLibrary, cacheId );
				laBio.process( getTrainSet(), getClassifySet(), cacheHit );
				if( cacheHit == false)//don't save same cache twice
				{
					cout << "Error loading library for drug: " << (*drugIt) << endl;
					cout << "Hit 'x' and Enter to exit." << endl;
					char c;
					cin  >> c;
					exit(0);
					//laBio.saveCache( optAdptr_, getTrainSet(), isLibrary, cacheId );
				}
			}

			//scale the data
			{
				SvmPreProcessor _svmPreProc( optAdptr_ );
				_svmPreProc.scale( getTrainSet() );
				_svmPreProc.scale( getClassifySet() );
			}
			
			//make prediction, and update results file
			{
				LibSvmAdapter libAdptr( optAdptr_ );
				bool isResistant =	libAdptr.predictIsResistant( getTrainSet(), (*seqWuIt) );
				
				//updates a single sequence's resistance profile.
				updateProfile_( isResistant, profileStream );
			}
			
			//clear train and full set for next drug run
			//getTrainSet().clear();
			//getTrainSet().resize(0);
			//getFullSet().clear();
			//getFullSet().resize(0);
			////reset Classify Set
			//getClassifySet().clear();
			//getClassifySet().resize(0);

			destroyWorkUnitContainer( getFullSet() );
			destroyWorkUnitContainer( getTrainSet() );

			//classifySet was given WU by resistanceProfileSet
			//so, let resistanceProfileSet handle destruction of that set.
			getClassifySet().clear();

			getFullSet().resize(0);
			getTrainSet().resize(0);
			getClassifySet().resize(0);

		}//end drug run

		//set location for results

		//saves a single sequence's resistance profile.
		saveProfile_( profileStream, (*seqWuIt)->getIsolateName() );
	
	}//end sequence run

	cout << "Finished creating Resistance Profiles." << endl;

	destroyWorkUnitContainer( resistanceProfileSet );
	
}


/**

machine reads in and write out:
done 1. la matrices         lib_APV_3.5_local_alignment_matrix.txt
later 2. model caches    lib_APV_3.5_libsvm_model.txt
done 3. plus it needs, automatic stats.
TPR, FPR, c,g pair, AUC
                            lib_APV_3.5_auto_params.txt
#Auto generated c,g pair determined by Best TPR-FPR rate
estimated_tpr:
estimated_fpr:
auc:
cost:
gamma:
numTrainingSamples:

human may read:
done 1. ROC  curve plt (and image) lib_D4T_3.4_gnuplot_script.plt

*/
void Client::createLibrary_()
{
	cout << "Creating " << optAdptr_.getDrug() << " library file..." << endl;
	bool isLibrary = true;
	int cacheId;
	//get's my raw data ready
	{
		HivPreProcessor myHivPreProc( optAdptr_ ); 
		
		//writes library partial files, and loads FullSet
		//with correct number of values
		myHivPreProc.parse( getFullSet(), isLibrary );
		myHivPreProc.preparePerformanceEvalSamples( getFullSet(),
					getTrainSet(), getClassifySet(), isLibrary );
		cacheId = myHivPreProc.cacheId();

		//DebugHelper::debug( getTrainSet(), false );
	#ifndef QUIET
		cout << "Printing fasta file" << endl;
	#endif	
		myHivPreProc.printToFile( getTrainSet() );
	}
	
	//now save lib_APV_NumSamples_LABioProcessor.txt (la matrix)
	//we will use everything in the full set, classify set is emptys

	{
		LaBioProcessor laBio;

		//look for cache hit
		bool cacheHit =  laBio.checkCache( optAdptr_, getTrainSet(), isLibrary, cacheId  );
		
		laBio.process( getTrainSet(), getClassifySet(), cacheHit );
		
		//don't save same cache twice
		if( cacheHit == false)
		{
			laBio.saveCache( optAdptr_, getTrainSet(), isLibrary, cacheId );
		}
	}	
}

void Client::createLibraryBasic_()
{
#ifndef QUIET
	cout << "Creating " << optAdptr_.getDrug() << " library file..." << endl;
#endif	
	bool isLibrary = true;
	int cacheId;
	//get's my raw data ready
	{
		HivPreProcessor myHivPreProc( optAdptr_ ); 
		
		//writes library partial files, and loads FullSet
		//with correct number of values
		myHivPreProc.parse( getFullSet(), isLibrary );
		myHivPreProc.preparePerformanceEvalSamples( getFullSet(),
					getTrainSet(), getClassifySet(), isLibrary );
		cacheId = myHivPreProc.cacheId();

		DebugHelper::debug( getTrainSet(), false );
	#ifndef QUIET
		cout << "Printing fasta file" << endl;
	#endif
		myHivPreProc.printToFile( getTrainSet() );
	}
	
	//now save lib_APV_NumSamples_LABioProcessor.txt (la matrix)
	//we will use everything in the full set, classify set is emptys

	{
		LaBioProcessor laBio;

		//look for cache hit
		bool cacheHit =  laBio.checkCache( optAdptr_, getTrainSet(), isLibrary, cacheId  );
		
		laBio.process( getTrainSet(), getClassifySet(), cacheHit );
		
		//don't save same cache twice
		if( cacheHit == false)
		{
			laBio.saveCache( optAdptr_, getTrainSet(), isLibrary, cacheId );
		}
	}	
}

void Client::findBestLibraryParams_( )
{
	//scale the data
	SvmPreProcessor _svmPreProc( optAdptr_ );
	_svmPreProc.scale( getTrainSet() );
	//	_svmPreProc.scale( getClassifySet() );

	//set location for ROC curve data to be saved as library
	optAdptr_.resultsPath( "library/" );

	//find optimal parameters for training model
	//and create ROC curve
	{
		cout << "Finding best parameters using 10 fold cross validation..." << endl;
		LibSvmAdapter libAdptr( optAdptr_ );
		_svmPreProc.findBestParameters( getTrainSet(), libAdptr, 10, optAdptr_ );

	}	
	
	_svmPreProc.saveLibraryStats();//
	_svmPreProc.printBestStats( 0 );
	_svmPreProc.printBestStats(1);
}

void Client::evaluateHivmPerformance_()
{
	bool isLibrary = false;

	  {
		HivPreProcessor myHivPreProc( optAdptr_ ); //get's my raw data ready for kernels
		myHivPreProc.parse( getFullSet(), isLibrary );
	#ifndef NO_RANDOMIZATION 	
		myHivPreProc.randomize( getFullSet() );
	#endif					
		// DebugHelper::debug( getClassifySet(), false );
		myHivPreProc.preparePerformanceEvalSamples( getFullSet(),
				getTrainSet(), getClassifySet(), isLibrary );
	#ifndef QUIET
		cout << "Printing fasta file" << endl;
	#endif
		myHivPreProc.printToFile( getTrainSet() );

	  }
	  // DebugHelper::debug( getClassifySet(), false );

		//myHivPreProc.printToFile( trainWus );
		//myHivPreProc.printToFile( classifyWus );
		{
			LaBioProcessor laBio;
			laBio.process( getTrainSet(), getClassifySet(), false );
		}
		//laBio.printUnscaled( trainWus );//to read la values
		//laBio.saveFile( getTrainSet(), "hivmDataSet.txt" );

		//scale the data
		SvmPreProcessor _svmPreProc( optAdptr_ );
		_svmPreProc.scale( getTrainSet() );
		_svmPreProc.scale( getClassifySet() );

		//DebugHelper::debug( getTrainSet(), false );

		//find optimal parameters for training model
		cout << "Finding best parameters using 10 fold cross validation..." << endl;
		LibSvmAdapter libAdptr( optAdptr_ );
		_svmPreProc.findBestParameters( getTrainSet(), libAdptr, 10, optAdptr_ );
		_svmPreProc.printBestStats( 0 );
		_svmPreProc.printBestStats(1);
	
	Stats _stat( optAdptr_ );
	_stat.setCost(  optAdptr_.cost() );
	_stat.setGamma( optAdptr_.gamma() );
	
	 //train and predict
	 libAdptr.predictionTest( getTrainSet(), getClassifySet(), _stat );

	//print results
	cout << endl;
	cout << "Printing Prediction Test Results:" << endl;
	
	stringstream sstream;
	_stat.printClassInfo( sstream );
	_stat.print( sstream );

	//write to file
	stringstream fileName;
	fileName << optAdptr_.uniqueID();
	fileName << "_" <<  optAdptr_.getDrug();
	fileName << "_test_stats.txt";

	stringstream pathName;
	pathName << optAdptr_.resultsPath();

	cout << sstream.str() << endl;
	IO::writeFile( fileName, sstream, pathName );
}

Client::~Client()
{
	//DebugHelper::debug( fullWus, true );
	//DebugHelper::debug( trainWus, true );
	//DebugHelper::debug( classifyWus, true );

	//fullWus.clear();
	//trainWus.clear();
	//classifyWus.clear();

	destroyWorkUnitContainer( fullWus );
	destroyWorkUnitContainer( trainWus );
	destroyWorkUnitContainer( classifyWus );	
}

//@todo vector.clear() does this better
void Client::destroyWorkUnitContainer( wuSet Wus )
{
	wuIterator it = Wus.begin();
	while( it != Wus.end() ) 
	{
		if( (*it) != NULL )
		{
			delete (*it);
		}
		it++;
	}

	//Wus.clear();
}

vector<WorkUnit*>&  Client::getTrainSet()
{
	return trainWus; 
}

vector<WorkUnit*>&  Client::getClassifySet()
{
	return classifyWus;
}

vector<WorkUnit*>&  Client::getFullSet()
{
	return fullWus;
}





//void Client::run(  ){
//
//}


//main( int argc, char *argv[] ){





	 // 	std::vector<WorkUnit*> wu;
		//OptionsAdapter myOptionsAdapter;
		//HivPreProcessor myHivPreProc( myOptionsAdapter, wu ); //get's my raw data ready for kernels
		//
		//myHivPreProc.parse();
		//myHivPreProc.printToFile();

		//LaBioProcessor a;
		//a.process( wu );
		//a.printToScreen( wu );//to read la values




	//HivPreProcessor myHivPreProc; //get's my raw data ready for kernels
	////Kernel *myKernel;//	kernel to compute pattern recognition
	//vector<WorkUnit*> myWuVector;
	//OptionsAdapter myOptionsAdapter;

	//cout << "Hello, I hope you passed in arguments separate by spaces\n";
	//cout << "- the command-line arguments are:\n\n";
 //   cout << "- input file name (no spaces allowed)\n";
 //   cout <<  "- virus sequence file\n";
 //   cout << "- name of the drug (no spaces allowed)\n";
 //   cout << "- number of resistance categories\n";
 //   cout << "- resistance threshold(s) separated by spaces\n";

	//cout << "PreProcessing..." << endl;

	/**
		OptionsAdapter class handles the input
		Preprocessor class takes:
		a. the OptionsAdapter for OptionsAdapters on preprocessing
		b. a WorkUnit Vector to hold the results of preprocessing.
	*/

	/**
		ok, so using the visual studio, how do I pass in cmd line paramaters?
		So i can use the VS debugger.
		answer: In project > properties
	*/

/**
	BEGIN: use this section if you don't want to put in true cmd line paramaters
*/
		//int myArgC;
		//char* myArgV[ 8 ];

  //		myArgC = 8;
	 // 	myArgV[1] = "unit_tests/files/PI_susceptibility.dat";//stanford suspectibility
	 // 	myArgV[2] = "unit_tests/files/PI.seq";//virus seq
	 // 	myArgV[3] = "APV";//drug name
	 // 	myArgV[4] = "4";//#resistance categories
	 // 	myArgV[5] = "1";//resistance threshold,
	 // 	myArgV[6] = "2";//resistance threshold,
	 // 	myArgV[7] = "3";//resistance threshold,

	//Because argv[0] is always the name of the command, the value of argc is always
	// one greater than the number of command-line arguments that the user enters. 

	//myOptionsAdapter = new OptionsAdapter( argc, myArgV );
	//myHivPreProc = new HivPreProcessor( myOptionsAdapter, myWuVector );
	//string susceptibilityFileName = myArgV[1];

/**
	END: use this section if you don't want to put in true cmd line paramaters
*/

//	std::vector<WorkUnit*> myWuVector;
//	OptionsAdapter myOptionsAdapter;
//	HivPreProcessor myHivPreProc( myOptionsAdapter, myWuVector ); //get's my raw data ready for kernels
//	myHivPreProc.parse();
//	//print the preprocessed results
//	myHivPreProc.printToFile();
//
//	//myOptionsAdapter = new OptionsAdapter();
//	//myHivPreProc = new HivPreProcessor( myOptionsAdapter, myWuVector );
//	//string susceptibilityFileName = argv[1];
//
////	myHivPreProc->parse( susceptibilityFileName );
//


//	cout << "Thanks, I'm done preprocessing your data and printing it to files. Goodbye" << endl;
//	return 0;

//}
//void Client::runTest( )
//{
//	cout << "Running test on known sequences..." << endl;
//	bool isLibrary = false;
//
//		//std::string str = "configTest.txt";
//  //	  OptionsAdapter oa( str );//custom testing file
//
//	  {
//		HivPreProcessor myHivPreProc( optAdptr_ ); //get's my raw data ready for kernels
//		myHivPreProc.parse( getFullSet(), isLibrary );
//		myHivPreProc.randomize( getFullSet() );
//					
//		// DebugHelper::debug( getClassifySet(), false );
//		myHivPreProc.preparePerformanceEvalSamples( getFullSet(),
//				getTrainSet(), getClassifySet(), isLibrary );
//	  }
//	  // DebugHelper::debug( getClassifySet(), false );
//
//		//myHivPreProc.printToFile( trainWus );
//		//myHivPreProc.printToFile( classifyWus );
//		{
//			LaBioProcessor laBio;
//			laBio.process( getTrainSet(), getClassifySet(), false );
//		}
//		//laBio.printUnscaled( trainWus );//to read la values
//		//laBio.saveFile( getTrainSet(), "hivmDataSet.txt" );
//
//		//scale the data
//		SvmPreProcessor _svmPreProc( optAdptr_ );
//		_svmPreProc.scale( getTrainSet() );
//		_svmPreProc.scale( getClassifySet() );
//
//		//DebugHelper::debug( getTrainSet(), false );
//
//		//find optimal parameters for training model
//		LibSvmAdapter libAdptr( optAdptr_ );
//		//_svmPreProc.findBestParameters( getTrainSet(), libAdptr, 0, optAdptr_ );
//		_svmPreProc.printBestStats( 1 );
//	
//	Stats _stat( optAdptr_ );
//	_stat.setCost(  optAdptr_.cost() );
//	_stat.setGamma( optAdptr_.gamma() );
//	
//	 //train and predict
//	 libAdptr.predictionTest( getTrainSet(), getClassifySet(), _stat );
//
//	//print results
//	cout << endl;
//	cout << "Printing Prediction Test Results:" << endl;
//
//	stringstream sstream;
//	_stat.printClassInfo( sstream );
//	_stat.print( sstream );
//
//	//write to file
//	stringstream fileName;
//	fileName << optAdptr_.uniqueID();
//	fileName << "_" <<  optAdptr_.getDrug();
//	fileName << "_test_stats.txt";
//
//	stringstream pathName;
//	pathName << optAdptr_.resultsPath();
//
//	IO::writeFile( fileName, sstream, pathName );
//}
