
#ifdef CPPUNIT

#include "../std_include.h"

// CppUnit: MFC TestRunner DOESN'T WORK FOR ME FOR SOME REASON...oh well.
//#include <cppunit/ui/mfc/TestRunner.h>

// CppUnit: TestFactoryRegistry to retreive the top test suite that contains all registered tests.
#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/CompilerOutputter.h>
#include <cppunit/ui/text/TestRunner.h>
//#include "TestClient.cpp"
//#include "TestHivPreProcessor.cpp"
//#include "TestPreProcessor.cpp"
//#include "TestWorkUnit.cpp"
//#include "TestHivWorkUnit.cpp"
//#include "TestOptionsAdapter.cpp"
//#include "TestInstruction.cpp"
//#include "TestLaBioProcessor.cpp"
#include "TestStringTokenizerAdapter.cpp"

class TestRun
{

public:

//int main( int argc, char *argv[] )
	bool TestRun::run() 
	{

	CppUnit::TextUi::TestRunner runner;
	  
	CppUnit::TestFactoryRegistry &registry =
		CppUnit::TestFactoryRegistry::getRegistry();

	runner.addTest( TestStringTokenizerAdapter::suite() );
	//runner.addTest( TestOptionsAdapter::suite() );
	//runner.addTest( TestLaBioProcessor::suite() );
	//runner.addTest( TestWorkUnit::suite() );  
	//runner.addTest( TestHivWorkUnit::suite() ); 
	//runner.addTest( TestInstruction::suite() ); 
	//runner.addTest( TestPreProcessor::suite() );
	//runner.addTest( TestHivPreProcessor::suite() );
	//runner.addTest( TestClient::suite() );

	runner.addTest( registry.makeTest() );
	    
	bool wasSucessful = runner.run( "", false );
	return wasSucessful;
	}

};

#endif
