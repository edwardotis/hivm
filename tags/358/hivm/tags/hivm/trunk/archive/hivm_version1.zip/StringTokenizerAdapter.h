#ifndef STRINGTOKENIZERADAPTER_H
#define STRINGTOKENIZERADAPTER_H

/**
@purpose Provide added functionality to StringTokenizer without altering the existing StringTokenizer class which was written
by another developer.
*/

#include "string_tokenizer/StringTokenizer.h"

#include <string>
//#include <memory>
//typedef auto_ptr<StringTokenizer> StrTokPtr;

class StringTokenizerAdapter
{

public:

	//default constructor
	//sets to empty string and empty delimiter
	StringTokenizerAdapter();

	//constructor that takes new string
	StringTokenizerAdapter( string input, string delim );

	//default destructor
	virtual ~StringTokenizerAdapter();

	/**
	@purpose To reset a stringtokenizeradapter instance with a new string.
	@param   new string to tokenize
	@param   new delimiter to tokenize string
	*/
	virtual void setString( std::string input, std::string delim );

//expose the original StringTokenizer public interface

    int    countTokens();
    bool   hasMoreTokens();
    string nextToken();
    int    nextIntToken();
    double nextFloatToken();
    string nextToken(string delim);
    string remainingString();
    string filterNextToken(string filterStr);


private:


	//StrTokPtr _strTok;
	StringTokenizer *_strTok;

	//copy constructor
	StringTokenizerAdapter( const StringTokenizerAdapter& );


	//assignment operator
	StringTokenizerAdapter& operator= ( const StringTokenizerAdapter& );

};

#endif
