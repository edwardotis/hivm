#ifndef HASH_H	
#define HASH_H


class Hash
{

public:

	/*
	@purpose Hash a string quantity 
	@credit C.B. Falconer
	@url http://cbfalconer.home.att.net/
	*/
	 static unsigned long hshstrhash( const char *string );

private:
	
	//constructor
	Hash();

	//destructor
	~Hash();

	//copy constructor
	Hash( const Hash& );

	//assignment operator
	Hash& operator= ( const Hash& );
};

#endif

