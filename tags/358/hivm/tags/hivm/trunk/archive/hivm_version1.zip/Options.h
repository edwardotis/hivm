// **************************************************************
//						Copyright (C) 2003 - 2005 
//			Martin Eggenberger, Ljubomir Buturovic, SFSU
//
// **************************************************************
//
// Permission is hereby granted, free of charge, to any person obtaining 
// a copy of this software and associated documentation files (the "Software"), 
// to deal in the Software without restriction, including without limitation 
// the rights to use, copy, modify, merge, publish, distribute, sublicense,
// and/or sell copies of the Software, and to permit persons to whom the 
// Software is furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES 
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
// IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
// CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, 
// TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
// SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
// **************************************************************
//
// PhaseMachine is a program that allows the classification of 
// two species based on the individual genetic sequecne as 
// obtained by the phase program.
//			
// For further information, please read the documentation to the 
// phasemachine program or conact.
//
//	meggenbe@sfsu.edu
//	ljubomir@sfsu.edu
// 
// **************************************************************

#ifndef OPTIONS_
#define OPTIONS_ 1

#include "std_include.h"
#include "svm.h"

class Options  
{
public:

	enum EKernelType
	{
		Linear		   = 0,
		Polynomial	   = 1,
		RBF			   = 2,	
		Sigmoid		   = 3
	};

	enum EDataType
	{
		Sequence	   = 0,			// unused
		Decimal		   = 1,			// decimal A = 1,  T = 2,  C = 3,  G = 4
		Binary2Bits    = 2,			// binary  A = 00, T = 01, C = 10, G = 11
 		Binary4Bits    = 3,			
		LocalAlignment = 4			// preprocess with LA
	};

	enum ESNPData 
	{
		AllSNPs		   = 1,
		NeutralSNPs	   = 3,
		NonNeutralSNPs = 2
	};

	enum ESVMType
	{
		C_SVMType	   = 0,
		NU_SVMType     = 1                
	};

	enum EOperation
	{
		OpTrain			= 0,
		OpValidate      = 1,
		OpClassify		= 2,
		OpSplit			= 3
	};

	
	enum EFileType
	{
		TrainingSet = 0,
		ClassifySet = 1
	};


	// Usage : phase_machine -iPos <inputfile1> .. <inputFileN>		// the psoistive input files.
	//						 -iNeg <inputfile1> .. <inputfileN>     // the negative input files.
	//						 -o <resultFile>						// The result file
	//                       -k <kernelType>						// The kernel to be used
	//						 -d <dataFormat>						// The Data Format
	//						 -v										// verbose option
	//                       -I										// Interactive Mode 
	//						 -e [number of expirments]
	//						 -c [cross validation]
	//						 -t <classifyFile>	
	Options();
	Options( const Options& rhs );
	virtual ~Options();

	Options& operator=( const Options& rhs );

	bool Validate();
	void GetParam ( svm_parameter& param );
	void SetParam ( svm_parameter& param );
	void LoadParam( svm_parameter& param );
	void ClearParam( svm_parameter& param );

	void ParseInput( int argc, char* argv[] );

	bool IsVerbose() const;
	void SetVerbose(bool bVerbose);
	bool IsDefault() const;
	void SetDefault(bool bDefault);
	bool IsInteractive() const;	
	void SetInteractive( bool bInteractive);

	bool IsAllResults() const;
	void SetAllResults( bool bAll );

	bool IsSwapAllele() const;
	void SetSwapAllele( bool bSwap );

	int	 GetExpirments() const;
	void SetExpirments( int nExp );
	int  GetCrossValidation() const;
	void SetCrossValidation(int nCross );
		
	void SetDimensions( int dim );
	int  GetDimensions() const;

	EKernelType GetKernel() const;
	void SetKernel( EKernelType eType );

	ESVMType GetSVMType() const;
	void SetSVMType( ESVMType eType );

	EDataType   GetDataType() const;
	void SetDataType( EDataType eType );

	ESNPData	GetSNPData() const;
	void SetSNPData( ESNPData eType );

	// additional parameters for the svm.
	void SetTermCriterion( double value );
	double GetTermCriterion() const;
	void SetGamma( double value );
	double GetGamma() const;
	void SetNu( double value );
	double GetNu( ) const;
	void SetCoefficiant(double val );
	double GetCoefficiant() const;
	void SetDegree( double value );
	double GetDegree() const;
	void SetCost(double cost );
	double GetCost() const;

	bool HasGamma() const;

	std::string& GetProbability();
	void SetProbability( const std::string& prob );

	std::string& GetOptionFile();
	std::string  GetClassName(EFileType type, int classType );

	int GetNumClasses(EFileType type) const;
	std::vector<string> GetFileList(EFileType type, int classType );
	std::vector<string> GetFileList(EFileType type, const std::string& className );

	void AddFile(EFileType type, int classType, const std::string& className, const std::string& file );
	
	std::string& GetTestFile();
	void SetTestFile( const std::string& file );
	std::string& GetResultFile();
	void SetResultFile( const std::string& file);

	void SetOperation ( EOperation eType );
	EOperation GetOperation( ) const;


	void SetModelFile ( const std::string& model );
	std::string& GetModelFile();

	void SetFraction( double fraction );
	double GetFraction() const;

	int  GetScaleFactor() const;
	void SetScaleFactor(int value);

private:

	void ParseOperation( const std::string& operation );
	void ParseKernel  ( const std::string& kernel );
	void ParseSetting ( const std::string& setting );
	void ParseEncoding( const std::string& encoding );
	void ParseSNPData ( const std::string& data );
	void ParseSVMType ( const std::string& svmType );
	void ParseGamma   ( const std::string& gamma );
	void ParseNu	  ( const std::string& nu );
	void ParseTerm    ( const std::string& term );
	void ParseCoefficiant ( const std::string& coefficant );
	void ParseCost    ( const std::string& cost );
	void ParseDegree  ( const std::string& degree );

	bool ValidateProb  ( const std::string& prob);
	bool ValidateExp   ( int nExperiments );
	bool ValidateCross ( int nGroups );

	bool ValidateLinear();
	bool ValidatePolynominal();
	bool ValidateRBF();
	bool ValidateSigmoid();

	void PrintUsage();

	typedef std::vector<string>    FileList;
	typedef std::vector<FileList>  FileCollection;

	FileCollection			fileListTrain;
	FileCollection			fileListTest;

	std::vector<string>     classNamesTrain;
	std::vector<string>     classNamesTest;

	std::string				resultFile;
	std::string             modelFile;
	std::string				testFile;

	std::string				optionFile;
	std::string             probability;
	
	bool					verbose;
	bool					defaultSettings;
	bool					interactive;
	bool					resultAll;
	bool                    swapAllele;
	bool                    hasGamma;

	ESNPData				snpData;
	EDataType				dataFormat;
	EKernelType				kernel;
	ESVMType				svmType;
	EOperation				operation;
	int						experiments;
	int						crossValidate;
	int                     scaleFactor;

	// additional parameters for the svm.
	double                  termCriterion;
	double                  gamma;
	double                  nu;
	double                  coefficiant;
	double                  degree;
	double                  cost;
	double                  fraction;
	int                     dimensions;

};

#endif
