#ifndef DEBUGHELPER_H
#define DEBUGHELPER_H

#include "std_include.h"
#include "WorkUnit.h"
#include "Stats.h"

class DebugHelper{

protected:

	//typedefs
	//typedef std::vector<WorkUnit*>::const_iterator wuConstIt;

public:

	//default ctor
	DebugHelper();

	//default dtor
	virtual ~DebugHelper();
	
	/**
	@purpose Static methods to show allow stepping through containers with debugger.
	@param vector to be examined
	@param switch for printing contents of vector to std::out
	*/
	static void debug( const vector<WorkUnit*>& v, bool print );
	static void debug( const vector<bool>& v, bool print );
	static void debug( const vector<int>& v, bool print );
	static void debug( const Stats&, bool print );
	static void debug( const vector<double>& v, bool print );
	static void debug( const vector<string>& v, bool print );
};

#endif
