#include "SvmPreProcessor.h"

//set max and min to default extremes
SvmPreProcessor::SvmPreProcessor( const OptionsAdapter& oa ) 
:	_optAdptr( oa ),
	bestSensitivity_( _optAdptr ),
	bestSpecificity_(_optAdptr ),
	bestErrorRate_(_optAdptr ),
	bestPositivePredictiveValue( _optAdptr),
	bestNegativePredictiveValue_(_optAdptr ),
	bestTprOverFprRatio_(_optAdptr),
	bestTprFprDifference_(_optAdptr),
	areaUnderCurve_( 0 )
{
	resetExtrema_();
	//double negative_DBL_MIN = DBL_MAX;
	//negative_DBL_MIN *= -1;
	//_max = negative_DBL_MIN,

	//costTestParam_.startBound = -30;
	//costTestParam_.endBound = 30;
	//costTestParam_.increment = 1;

	//gammaTestParam_.startBound = -30;
	//gammaTestParam_.endBound = 30;
	//gammaTestParam_.increment = 1;

	//bestParameters_.bestCost = DBL_MIN;
	//bestParameters_.bestGamma = DBL_MIN;
	//bestParameters_.successRate = 0.0;

}

SvmPreProcessor::~SvmPreProcessor()
{}

void SvmPreProcessor::scale( std::vector<WorkUnit*>& i_wus )
{
	scale_( i_wus );
}

void SvmPreProcessor::findBestParameters( std::vector<WorkUnit*>& i_wus, LibSvmAdapter& i_libSvmAdptr, int i_nFold, OptionsAdapter& m_optAdptr )
{	
	cout << endl;
	cout << "Finding the best parameters via a cross validation grid search. This may take a while." << endl;

	//working instance of Stat
	//Stats _crossValidationStat(m_optAdptr);
	Stats _dataPointSet(m_optAdptr);

    WorkUnit::initActivePositions( i_wus.size() );

	gridSearchBroad_( i_wus, i_libSvmAdptr, i_nFold, _dataPointSet);
	
	//gridSearch Narrow messes up my Area Under Curve calculation
	//it falsely inflates it, so I had to remove this
	//gridSearchNarrow_( i_wus, i_libSvmAdptr, i_nFold, _dataPointSet );

	cout << endl;
	cout << "Finished search!" << endl;
	cout << endl;
	cout << "Saving parameters for testing from Best TPR-FPR Difference found:" << endl;

	storeBestParameters( m_optAdptr, bestTprFprDifference_.cost(),
		bestTprFprDifference_.gamma() );

	areaUnderCurve_ = _dataPointSet.computeAreaUnderROCCurve();

	//write datapoints to file for use by a graphing tool
	//true means save file of pruned datapoints
	_dataPointSet.saveDataPoints( false );
	_dataPointSet.saveDataPoints( true );

	//active positions is only a function of cross validation
	//we should only call cross_validation from within the parameter search
	//so, we should reset active positions back to 'all' so as not to 
	//interfere with future training and prediction
	//...or is everything just jacked?

}

/**
@purpose perform grid search in broad increments of cost and gamma
*/
void SvmPreProcessor::gridSearchBroad_( std::vector<WorkUnit*>& wus, LibSvmAdapter& libSvmAdptr, int nFold , Stats& m_dataPointSet )
{

	double _c = DBL_MIN;
	double _g = DBL_MAX;
	
	//DRY violation here w/ c ang g. I'm storing in stats and in separate vars.
	cout << endl;

	for( _c = _optAdptr.costLow(); _c <= _optAdptr.costHigh(); _c += _optAdptr.costIncrement() )
	{
		for( _g = _optAdptr.gammaLow(); _g <= _optAdptr.gammaHigh(); _g += _optAdptr.gammaIncrement() )
		{
			Stats _crossValidationStat( _optAdptr );
			
			libSvmAdptr.crossValidate( wus, nFold, _c, _g, _crossValidationStat );
			
			updateBestStats_( _crossValidationStat );

			m_dataPointSet.updateDataPointSet( 
				_g,
				_c,
				_crossValidationStat.truePositiveRate(), 
				_crossValidationStat.falsePositiveRate(),
				_crossValidationStat.trueNegativeRate(), 
				_crossValidationStat.falseNegativeRate()
			);
		}
		cout << ".";
	}
	

	//for( _c = costTestParam_.startBound; _c <= costTestParam_.endBound; _c += costTestParam_.increment )
	//{
	//	for( _g = gammaTestParam_.startBound; _g <= gammaTestParam_.endBound; _g += gammaTestParam_.increment )
	//	{
	//		Stats _crossValidationStat( _optAdptr );
	//		
	//		libSvmAdptr.crossValidate( wus, nFold, _c, _g, _crossValidationStat );
	//		
	//		updateBestStats_( _crossValidationStat );

	//		m_dataPointSet.updateDataPointSet( 
	//			_g,
	//			_c,
	//			_crossValidationStat.truePositiveRate(), 
	//			_crossValidationStat.falsePositiveRate(),
	//			_crossValidationStat.trueNegativeRate(), 
	//			_crossValidationStat.falseNegativeRate()
	//		);
	//	}
	//	cout << ".";
	//}

}

/**
@purpose perform grid search in narrow increments of cost and gamma, based upon broad grid search best result
*/
//void SvmPreProcessor::gridSearchNarrow_( std::vector<WorkUnit*>& wus, LibSvmAdapter& libSvmAdptr, int nFold, Stats& m_dataPointSet )
//{
//	double _c = DBL_MAX;
//	double _g = DBL_MIN;
//	//the narrow bounds are fixed to avoid repeating the boundary cross
//	//validation every time
//	double _narrowIncrement = .5;
//	double _lowBoundC = bestErrorRate_.cost()   - (costTestParam_.increment/2.0)  + _narrowIncrement;
//	double _highBoundC = bestErrorRate_.cost()  + (costTestParam_.increment/2.0)  - _narrowIncrement;
//	double _lowBoundG = bestErrorRate_.gamma()  - (gammaTestParam_.increment/2.0) + _narrowIncrement;
//	double _highBoundG = bestErrorRate_.gamma() + (gammaTestParam_.increment/2.0) - _narrowIncrement;
//	
//
//	cout << endl;
//
//	for( _c = _lowBoundC; _c <= _highBoundC; _c += _narrowIncrement )
//	{
//		
//		for( _g = _lowBoundG; _g <= _highBoundG; _g += _narrowIncrement )
//		{
//			Stats _crossValidationStat( _optAdptr );
//
//			libSvmAdptr.crossValidate( wus, nFold, _c, _g, _crossValidationStat );
//			
//			updateBestStats_( _crossValidationStat );
//
//			m_dataPointSet.updateDataPointSet( 
//				_g,
//				_c,
//				_crossValidationStat.truePositiveRate(), 
//				_crossValidationStat.falsePositiveRate(),
//				_crossValidationStat.trueNegativeRate(), 
//				_crossValidationStat.falseNegativeRate()
//			);
//		}
//		cout << ".";
//	}
//	
//}

/**
@purpose print special library file
*/
void SvmPreProcessor::saveLibraryStats( )
{
/**
. plus it needs, automatic stats.
TPR, FPR, c,g pair, AUC
                            lib_APV_3.5_auto_params.txt
#Auto generated c,g pair determined by Best TPR-FPR rate
estimated_tpr:
estimated_fpr:
auc:
cost:
gamma:
numTrainingSamples:
*/
	//DebugHelper::debug( bestTprFprDifference_, false );

	stringstream outstream;
		
	outstream << "#Auto generated c,g pair determined by Best TPR-FPR Difference" << endl;
	outstream << "estimated_tpr: " << bestTprFprDifference_.truePositiveRate() << endl;
	outstream << "estimated_fpr: " << bestTprFprDifference_.falsePositiveRate() << endl;
	outstream << "auc: " << this->areaUnderCurve_ << endl;
	outstream << "cost: " << bestTprFprDifference_.cost() << endl;
	outstream << "gamma: " << bestTprFprDifference_.gamma() << endl;
	outstream << "numTrainingSamples: " << _optAdptr.numSamplesToUse() << endl;


		stringstream fileName;
		//fileName << "lib";
		fileName << _optAdptr.getDrug();
		fileName << "_threshold-" << _optAdptr.getThresholds().front();
		fileName << "_auto_params.txt";

		stringstream pathName;
		pathName << _optAdptr.resultsPath();

		IO::writeFile( fileName, outstream, pathName );
}


void SvmPreProcessor::printBestStats( int i_destination )
{
	stringstream sstream;
	
	sstream << "Best TPR - FPR Difference:" << endl;
	bestTprFprDifference_.print( sstream );
	bestTprFprDifference_.printClassInfo( sstream );

	sstream << "Best TPR/FPR Ratio:" << endl;
	bestTprOverFprRatio_.print( sstream );
	bestTprOverFprRatio_.printClassInfo( sstream );

	sstream << "Best Positive Predictive Value:" << endl;
	bestPositivePredictiveValue.print( sstream );
	bestPositivePredictiveValue.printClassInfo( sstream );

	sstream << "Best Negative Predictive Value_:" << endl;
	bestNegativePredictiveValue_.print( sstream );
	bestNegativePredictiveValue_.printClassInfo( sstream );

	sstream << "Best Error Rate:" << endl;
	bestErrorRate_.print(sstream);
	bestErrorRate_.printClassInfo( sstream );

	if( i_destination == 0 )
	{
		cout << sstream.str();
	}

	if( i_destination == 1 )
	{
		stringstream fileName;
		fileName << _optAdptr.getDrug();
		fileName << "_threshold-" << _optAdptr.getThresholds().front();
		//fileName << "_" << _optAdptr.numSamplesToUse() << "samples";
		fileName << "_best_parameters_stats.txt";

		stringstream pathName;
		pathName << _optAdptr.resultsPath();

		IO::writeFile( fileName, sstream, pathName );
	}

	//cout << "Best True Positive Rate:" << endl;
	////TPR = sensitivity
	//bestSensitivity_.print(sstream);
	//bestSensitivity_.printClassInfo( sstream );

	//cout << "Best False Positive Rate (specificity):" << endl;
	////FPR = 1 - specificity
	//bestSpecificity_.print(sstream);
	//bestSpecificity_.printClassInfo( sstream );

}

//@todo finish implementing these stats
void SvmPreProcessor::updateBestStats_( Stats& i_stat )
{
	//DebugHelper::debug( i_stat, true );
	
	if( !bestTprFprDifference_.isInitialized() )
	{
		//cout << "SvmPreProcessor::bestSensitivity_ not initialized" << endl;
		bestTprFprDifference_ = i_stat;
	}
	if( i_stat.tprFprDifference() > bestTprFprDifference_.tprFprDifference() )
	{
		bestTprFprDifference_ = i_stat;
	}


	if( !bestTprOverFprRatio_.isInitialized() )
	{
		//cout << "SvmPreProcessor::bestSensitivity_ not initialized" << endl;
		bestTprOverFprRatio_ = i_stat;
	}
	if( i_stat.tprOverFprRatio() > bestTprOverFprRatio_.tprOverFprRatio() )
	{
		bestTprOverFprRatio_ = i_stat;
	}

	if( !bestSensitivity_.isInitialized() )
	{
		//cout << "SvmPreProcessor::bestSensitivity_ not initialized" << endl;
		bestSensitivity_ = i_stat;
	}
	if( i_stat.sensitivity() > bestSensitivity_.sensitivity() )
	{
		bestSensitivity_ = i_stat;
	}


	if( !bestSpecificity_.isInitialized() )
	{
		//cout << "SvmPreProcessor::bestSpecificity_ not initialized" << endl;
		bestSpecificity_ = i_stat;
	}
	if( i_stat.specificity() > bestSpecificity_.specificity() )
	{
		bestSpecificity_ = i_stat;
	}

	if( !bestErrorRate_.isInitialized() )
	{
		//cout << "SvmPreProcessor::bestErrorRate_ not initialized" << endl;
		bestErrorRate_ = i_stat;
	}
	if( i_stat.errorRate() < bestErrorRate_.errorRate() )
	{
		bestErrorRate_ = i_stat;
	}

	if( !bestPositivePredictiveValue.isInitialized() )
	{
		//cout << "SvmPreProcessor::bestPositivePredictiveValue not initialized" << endl;
		bestPositivePredictiveValue = i_stat;
	}
	if(	i_stat.positivePredictiveValue() > bestPositivePredictiveValue.positivePredictiveValue() )
	{
		bestPositivePredictiveValue = i_stat;
	}

	if( !bestNegativePredictiveValue_.isInitialized() )
	{
		//cout << "SvmPreProcessor::bestNegativePredictiveValue_ not initialized" << endl;
		bestNegativePredictiveValue_ = i_stat;
	}
	if(	i_stat.negativePredictiveValue() > bestNegativePredictiveValue_.negativePredictiveValue() )
	{
		bestNegativePredictiveValue_ = i_stat;
	}

}

//todo test and update this
void SvmPreProcessor::storeBestParameters( OptionsAdapter &m_optAdptr, double cost, double gamma )
{
/*	cout << "WARNING! We now have a choice of best parameters to store for training models." << endl;
	cout << "We need to give an option for using params for best Sensitivity, Specificity, or Error Rate." << endl;
	*///cout << "Defaulting to store best Sensitivity parameters." << endl;
	//if( verbose )
	//{
		cout << "Now using Cost: " << cost << " and Gamma: " << gamma << endl;
		cout << endl;
	//}
	m_optAdptr.setCost( cost );
	m_optAdptr.setGamma( gamma );

	//still need to update the param used for prediction!!
}
	
void SvmPreProcessor::print() const
{
	//std::cout << "\nResults of Search for Best Parameters:\n" << std::endl;
	//std::cout << "Best Success Rate: " << bestParameters_.successRate << std::endl;
	//std::cout << "Best Cost: " << bestParameters_.bestCost << std::endl;
	//std::cout << "Best Gamma: " << bestParameters_.bestGamma << std::endl;
}

//void SvmPreProcessor::setBestParams_( double s, double c, double g )
//{
//	if( s > bestParameters_.successRate )
//	{
//		bestParameters_.successRate = s;
//		bestParameters_.bestCost = c;
//		bestParameters_.bestGamma = g;
//	}
//}



//void SvmPreProcessor::setCostTestParam( int start, int end, float increment )
//{
//	costTestParam_.startBound = start;
//	costTestParam_.endBound = end;
//	costTestParam_.increment = increment;
//}
//
//void SvmPreProcessor::setGammaTestParam( int start, int end, float increment )
//{
//	gammaTestParam_.startBound = start;
//	gammaTestParam_.endBound = end;
//	gammaTestParam_.increment = increment;
//}

//struct SvmPreProcessor::bestParameters SvmPreProcessor::getBestParameters()
//{
//	return bestParameters_;
//}


//double SvmPreProcessor::getBestCost() const
//{
//	return bestParameters_.bestCost;
//}
//
//double SvmPreProcessor::getBestGamma() const
//{
//	return bestParameters_.bestGamma;
//}

//protected

void SvmPreProcessor::resetExtrema_()
{
	_min = DBL_MAX;

	double smallestDbl = DBL_MAX;
	smallestDbl *= -1;
	_max = smallestDbl;
}

void SvmPreProcessor::sanityCheckExtrema_()
{
	//make sure the findExtrema function changed _max,_min defaults
	assert( _max != DBL_MIN );
	assert( _min != DBL_MAX );
	
	//make sure that max and min values aren't the same
	//this causes divide by zero
	//@updated This check happens during computation, not here.
	//It's unlikely but possible that max and min are the same. (i.e. someone
	//loads identical data into system. Assert if for "impossible", not improbable
	//assert( _max != _min );
}

void SvmPreProcessor::scale_( std::vector<WorkUnit*>& wus )
{
	//reset max,min for each attribute
	//resetExtrema_();

	std::vector<WorkUnit*>::iterator i;
	for( i=wus.begin(); i != wus.end(); i++ )
	{
		//reset max,min for each attribute
		resetExtrema_();

		//find max,min of the attribute
		findExtrema_( *i );
		
		//make sure extrema fall within reasonable range
		sanityCheckExtrema_();
		
		//computes and write the scaled data to WorkUnit
		setScaledNumSeq_( *i );

	}
}

void SvmPreProcessor::setScaledNumSeq_( WorkUnit *w )
{
	vector<double>::const_iterator it;
	
	for( it=w->getNumSeq().begin(); it != w->getNumSeq().end(); it++ )
	{
//		double temp =  computeScaledNum_( *it );
		//DebugHelper::debug( w->getNumSeqScaled(), false );
//		w->getNumSeqScaled().push_back( 0 );
		w->getNumSeqScaled().push_back( computeScaledNum_( *it ) );
	}
}

/**
@purpose scales EACH ATTRIBUTE in data set to [-1,1]
	x'' =  [ ( 2* (x-mini) )/(Maxi-mini) ] - 1
 */
double SvmPreProcessor::computeScaledNum_( double x )
{	
	double result, numerator;

	//check for example of only one sample
	//@todo is this the right number to scale it to in this case?
	if( _max == _min )
	{
		return 0.0;
	}

	double denominator = ( _max - _min );

		//check for divide by zero
	if( denominator == 0.0 )
	{
		std::cout << "Sorry, Divide by zero error in SvmPreProcessor::computeScaledNum_()." << std::endl;
		cout<< "Press 'x' and Enter to exit program." << endl;
		char x;
		cin >> x;
		std::cout << "Exiting program..." << endl;
		exit(1);
	}

	numerator = 2*( x - _min );
	result = (numerator/denominator) - 1.0;


	return result;
}

void SvmPreProcessor::findExtrema_( WorkUnit* w )
{
	findMax_( w );
	findMin_( w );
}

void SvmPreProcessor::findMin_( WorkUnit *w )
{
	
	std::vector<double>::iterator i;	

	//find min
	i =	std::min_element( w->getNumSeq().begin(), w->getNumSeq().end() );
	
	double _myMinVal = *i;
	
	if( _myMinVal < _min )
	{
		_min = _myMinVal;
	}
}

void SvmPreProcessor::findMax_( WorkUnit *w )
{
	
	std::vector<double>::iterator i;	

	//find max
	i =	std::max_element( w->getNumSeq().begin(), w->getNumSeq().end() );
	
	double _myMaxVal = *i; 

	if( _myMaxVal > _max )
	{
		_max = _myMaxVal;
	}	

}
