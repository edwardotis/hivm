#ifndef DEFINITIONS_H
#define DEFINITIONS_H
/**
@purpose: definitions for changing behavior of application among different
debug scenarios
*/

//Run Unit Tests using cppunit, otherwise use alterntive tests
//#define CPPUNIT

//Run testing code instead of Release code
//#define   TESTING
//#define   DEBUG
#define   QUIET
#define	  NO_RANDOMIZATION //keeps hivm from randomizing data. special test case.


//Toggle assertions on/off with No Debug macro
//#define NDEBUG

//for running assert with messages
//if condition evaluates to FALSE, error message displayed and
//program exits
//by Steve McConnell
//"Code Complete", 2nd ed.
// If the macro NDEBUG is defined, the assert() macros will be ignored.
//# ifndef NDEBUG
//#define ASSERT( condition, message )					\
//{														\
//	if( !(condition) )									\
//	{													\
//	LogError( "Assertion failed: ",						\
//		#condition, message );							\
//		exit( EXIT_FAILURE );										\
//	}													\
//}		
//# else
//	# define ASSERT( condition, message )
//# endif


#endif
















