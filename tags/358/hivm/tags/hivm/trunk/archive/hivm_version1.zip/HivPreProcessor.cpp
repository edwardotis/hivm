#include "HivPreProcessor.h"


//HivPreProcessor::HivPreProcessor( OptionsAdapter* newInstr, vector<WorkUnit*>&  newWuV)
//: PreProcessor( newInstr, newWuV ) 
//{
//	//cout << "2nd HivPreProcessor Constructor" << endl;
//	myInstr = newInstr;
//	myWuVector = newWuV;	
//	drugNameIndex = -1;
//	mutationListIndex = -1;
//	noDrugValueName = "na";
//	MUTATIONLIST_HEADERNAME = "MutList";
//	ISOLATE_HEADERNAME = "IsolateName";
//} 

HivPreProcessor::HivPreProcessor( OptionsAdapter& newInstr )
: PreProcessor( newInstr ),
cacheId_( 0 )
{
	//cout << "2nd HivPreProcessor Constructor" << endl;
//	myInstr = newInstr;
//	myWuVector = newWuV;	
	drugNameIndex = -1;
	mutationListIndex = -1;
	noDrugValueName = "na";
	MUTATIONLIST_HEADERNAME = "MutList";// pre Nov 4, 2004 format
	MUTATIONLIST_HEADERNAME_2 = "CompMutList";//post Nov 4, 2004 format
	ISOLATE_HEADERNAME = "IsolateName";

	//cout << "Just ran HivPreProcessor constructor" << endl;
	//cout << "MUTATIONLIST_HEADERNAME = " << MUTATIONLIST_HEADERNAME << endl;

} 

HivPreProcessor::~HivPreProcessor(){}


//void HivPreProcessor::parse( string susceptibilityDataFileName )
//{
//	loadFile( susceptibilityDataFileName,  getDataSetVector() );
//	setHeaderIndices( headerVector );
//	setHeaders();
//	parseData();
//}
	
void HivPreProcessor::parse( vector<WorkUnit*>& o_myWuVector, bool isLibrary  )
{
	stringstream filename;
	filename << myInstr.getSusceptibilityDataFileName();

	if( isLibrary == false )
	{
		stringstream input;
		
		IO::readFile( filename, input, "" );
		string inputString =input.str();
		//cout << inputString;
		cacheId_ = Hash::hshstrhash( inputString.c_str() );
	}
		
	stringstream inFile;

	IO::readFile( filename, inFile, "" );
	StringTokenizerAdapter _strtok;
	_strtok.setString( inFile.str(), "\n" );

	while( _strtok.hasMoreTokens() )
	{
		//commented lines start with '#' in the files.
		string line = _strtok.nextToken();
		dataSetVector.push_back( line );
	}

	//loadFile( myInstr.getSusceptibilityDataFileName(),  dataSetVector );
	setHeaderIndices( headerVector );
	setHeaders();
	parseData( o_myWuVector, isLibrary );

	//call the superclass parse to run setup functions that
	//apply to all derived classes
	PreProcessor::parse( o_myWuVector, false );

}

	/**
	Print a separate text file for each category specified at the cmd line
	Name the text files: DrugName_CategoryNumber.txt i.e. APV_Category2.txt
	
	one output file per resistance category
	filename: "APV FOLD Cat#"
	format:
	>isolateName
	DFJKIFDFLKJ
*/
void HivPreProcessor::printToFile( vector<WorkUnit*>& myWuVector )
{
	if( outFile.is_open() ){
		outFile.close();
	}

	int currentCategory;
	string currentDrugName = myInstr.getDrug();
	int maxCategories = myInstr.getNumOfCategories();
	stringstream myStream;
	string catStr;
	vector<WorkUnit*>::iterator wUIterator;
	
	/**
			For each category, open a new file, when a Work Unit from that category is found, 
			add Isolate Name and Mutated Sequence to that file.
			
			note: This isn't the most efficient way, but it's only big0(n) = maxCategories*#WorkUnits
	
			
		if a file is open that matches the wu category
			print to that file
		if file isn't open, then open a handle to a new file
			print to that file
	*/

	for( currentCategory = 0; currentCategory < maxCategories; currentCategory++ )
	{
		//todo: the files are appending instead of overwriting. 
		
		stringstream myStringStream;
		//clear old data before making next output file
		outFile.flush();
		outFile.clear();
		myStream.str("");//reset myStream to ""

		myStream << currentCategory;
		//example: "library\APV_3.5-threshold_Category0.fasta"
		//example: "library\APV_8.5-threshold_Category1.fasta"
		stringstream currentFileName;
		currentFileName << "library\\" << currentDrugName << "_" << myInstr.threshold();
		currentFileName << "-threshold_Category" << myStream.str() << ".fasta";

		string fileName = currentFileName.str();
		outFile.open( fileName.c_str(), ofstream::out );

		for( wUIterator = myWuVector.begin(); wUIterator != myWuVector.end(); wUIterator++ )
		{
			if( currentCategory == (*wUIterator)->getCategory() )
			{	
				//myStringStream << "\n";
				myStringStream << ">" + (*wUIterator)->getIsolateName() << endl;
				myStringStream << (*wUIterator)->getAaSeq() << endl;
				outFile << myStringStream.rdbuf();
				//for( i=(*wUIterator)->getAaSeq().begin(); i != (*wUIterator)->getAaSeq().end(); i++ )
				//{	
				//	//@todo rework this code. do I need to delete the char *?
				//	char buffer[20];
				//	//change to float using char *  fcvt ( double value, int num, int * dec, int * sign ); 
				//	sprintf(buffer, "%f", *i);
				//	//str += itoa( *i, buffer, 10 );
				//	str += buffer;

				//	str += "\t";
				//}

				//vector<double>::iterator i;
				//string str;
				//for( i=(*wUIterator)->getNumSeq().begin(); i != (*wUIterator)->getNumSeq().end(); i++ )
				//{	
				//	//@todo rework this code. do I need to delete the char *?
				//	char buffer[20];
				//	//change to float using char *  fcvt ( double value, int num, int * dec, int * sign ); 
				//	sprintf(buffer, "%f", *i);
				//	//str += itoa( *i, buffer, 10 );
				//	str += buffer;

				//	str += "\t";
				//}
				//myStringStream << str.c_str();
				
			}
		}//end myWUVector loop

		outFile.close();
	}//end currentCategory loop


}

int HivPreProcessor::getIsolateNameIndex()
{
	return isolateNameIndex;
}

bool HivPreProcessor::setHeaderIndices( const vector<string>& myVector  ){

	//tokenize myVector from one long string into a vector of strings
	//StringTokenizer *strTok;
	vector<string> tempVector;
	vector<string>::iterator stringIterator;
	stringIterator = ( dataSetVector.begin() );
	strTok_.setString( (*stringIterator), "\t"  );
	while( strTok_.hasMoreTokens() )
	{
		tempVector.push_back( strTok_.nextToken() );
	}

	//find the index of Mutation List
	if(	findStringIndex( tempVector, MUTATIONLIST_HEADERNAME ) != -1 )
	{
		mutationListIndex  = findStringIndex( tempVector, MUTATIONLIST_HEADERNAME );
	}
	else if( findStringIndex( tempVector, MUTATIONLIST_HEADERNAME_2 ) != -1 )
	{
		mutationListIndex  = findStringIndex( tempVector, MUTATIONLIST_HEADERNAME_2 );
	}
	else
	{
		return false;
	}

	//find the index of Isolate Name
	if(	findStringIndex( tempVector, ISOLATE_HEADERNAME ) != -1 )
	{
		isolateNameIndex  = findStringIndex( tempVector, ISOLATE_HEADERNAME );
	}
	else
	{
		return false;
	}

	return true;
}

int HivPreProcessor::getMutListIndex()
{
	return mutationListIndex;	
}

/**
This version handles pre 11/2004 and post 11/2004 version of hivdb datasets
*/
string HivPreProcessor::genMutatedSeq( string mutList )
{
	vector<string>::iterator stringIterator;
	vector<string> tempVector;
	vector<string> aaVector;
	vector<int>    positionVector;
	int posFirstLetter = -1;
	int posLastNum  = -1;
	string tempStrInt = "";
	//*, ~,  # are special chars used in stanford hiv db datasets
	string alphaChars = "~*#ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	string numChars =   "0123456789";

	/**
		Take mutation list String and parse it into data structures that make it possible to apply
		the mutations to the original virus sequence
	*/

	//Separate big mutation list string into individual mutation strings, i.e. E43IV or 43IV
	strTok_.setString( mutList, "," );

	while( strTok_.hasMoreTokens() )
	{
		//removes quote marks from the string, if they are present
		string tempStr = strTok_.filterNextToken( "\"" );

		//check for bad mutation list values. ie. no aa substitutions in the mutation list
		//don't add them to the working set of mutations if the mutation list value is bad
		if( isValidMutationList_( tempStr ) )
		{
			tempVector.push_back(tempStr);
		}
	}

	/**
		separate each individual mutation string into two parts:
		a. Position of mutation in the sequence
		b. the actual amino acid mutation: i.e. change current aa to 'LK'
	*/
	for( stringIterator = tempVector.begin(); stringIterator != tempVector.end(); stringIterator++ )
	{
		string tempStr = "@@@@";//set to non-alphanumeric string
		tempStr = *stringIterator;

		//clean up string from post Nov/2004 hivdb format to look like pre Nov/2004 Hivdb format

		//remove leading blank spaces (' E43V' b/c 'E43V') (new in post Nov/2004 code)
		while( (int)tempStr.find_first_of( ' ' ) == 0 )
		{
			tempStr = tempStr.substr( 1, (tempStr.length()-1) );
		}

		//remove leading amino acid(s) ( E43V becomes 43V )
		while( (int)tempStr.find_first_of( alphaChars ) == 0 )
		{
			tempStr = tempStr.substr( 1, (tempStr.length()-1) );
		}

		//find position of first letter. counting from 0.
		posFirstLetter = (int)tempStr.find_first_of( alphaChars );

		//find position of last number. 0 based. 
		posLastNum = (int)tempStr.find_last_of( numChars );

		//find and save mutation position
		tempStrInt = tempStr.substr( 0, posFirstLetter );
		int tempPosition =  atoi( tempStrInt.c_str() );
		positionVector.push_back( tempPosition );
		//cout << "tempStrInt.c_str() = " << tempStrInt.c_str() << endl;
		//cout << "atoi( tempStrInt.c_str() ) = " << atoi( tempStrInt.c_str() ) << endl;

		//find and save amino acids that will be substituted at the position
		string subString = tempStr.substr( posFirstLetter, (posLastNum-posFirstLetter) );
		aaVector.push_back( subString );
	}
	

	/**
	 * Create the mutated virus sequence by injecting the mutations into the original virus sequence
	 */

	string mutVirusSeq = myInstr.getOrigVirusSeq();
	vector<int>::iterator positionIterator;

	stringIterator = aaVector.begin();
	positionIterator    = positionVector.begin();
	int posAdjuster = 0;//positionAdjuster
	while( stringIterator != aaVector.end() ){
		if( (*positionIterator) > (int)myInstr.getOrigVirusSeq().size() || (*positionIterator) < 1 ){
			//cout << "(*positionIterator) " << (*positionIterator) << endl;
			//cout << "myInstr.getOrigVirusSeq().size() " << myInstr.getOrigVirusSeq().size() << endl;
			//cout << "positionVector.size() " << positionVector.size() << endl;
			cerr << "\nMutation List attempted to change amino acid at position outside orginal sequence range." << endl;
			cerr << "Mutated Sequence has been corrupted." << endl;
			//cerr << "Bad mutation list = \"" << mutList << "\"" << endl;
			//cerr << "Bad position = " << (*intIterator) << endl;
			//cerr << "String at bad position = " << (*stringIterator) << endl;

		}else{
			mutVirusSeq.replace( ((*positionIterator)-1+posAdjuster), 1, *stringIterator );
		}		
			posAdjuster += (int)(*stringIterator).size() - 1;//adjust position for strings w/ >1 aa
			stringIterator++;
			positionIterator++;
	}
	return mutVirusSeq;
}



/**
pre 11/2004 format version only
*/
//string HivPreProcessor::genMutatedSeq( string mutList ){
//   
//	//cout << endl;
//	//cout << mutList << endl;
//
//	vector<string>::iterator stringIterator;
//	vector<string> tempVector;
//	vector<string> aaVector;
//	vector<int>    positionVector;
//	int posFirstLetter = -1;
//	int posLastNum  = -1;
//	string tempStr = "not set";
//	string tempStrInt = "";
//	//*, ~ and # are special chars used in stanford hiv db datasets
//	string alphaChars = "*~#ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
//	string numChars =   "0123456789";
//
//	/**
//		Take mutation list String and parse it into data structures that make it possible to apply
//		the mutations to the original virus sequence
//	*/
//
//	//Separate big mutation list string into individual mutation strings
//	//@todo make sure setString() handles -, ., and empty mutlist correctly
//	strTok_.setString( mutList, "," );
//
//	while( strTok_.hasMoreTokens() ){
//
//		//removes quote marks from the string, if they are present
//		string tempStr = strTok_.filterNextToken( "\"" );
//
//		//check for bad mutation list values. ie. no aa substitutions in the mutation list
//		//don't add them to the working set of mutations if the mutation list value is bad
//		if( isValidMutationList_( tempStr ) )
//		{
//			//if we just pushed on an invalid mutlist, pop it back off. It means no mutations occured.
//			tempVector.push_back(tempStr);
//		}
//	}
//
////	delete strTok;
//	/**
//		separate each individual mutation string into two parts:
//		a. Position of mutation in the sequence
//		b. the actual amino acid mutation: i.e. change current aa to 'LK'
//	*/
//	for( stringIterator = tempVector.begin(); stringIterator != tempVector.end(); stringIterator++ ){
//		tempStr = *stringIterator;
//		posFirstLetter = (int)tempStr.find_first_of( alphaChars );
//		posLastNum = (int)tempStr.find_last_of( numChars );
//		tempStrInt = tempStr.substr( 0, posFirstLetter );
//		//cout << "tempStrInt.c_str() = " << tempStrInt.c_str() << endl;
//		//cout << "atoi( tempStrInt.c_str() ) = " << atoi( tempStrInt.c_str() ) << endl;
//		int tempPosition =  atoi( tempStrInt.c_str() );
//		positionVector.push_back( tempPosition );
//
//		string subString = tempStr.substr( posFirstLetter, (posLastNum-posFirstLetter) );
//		aaVector.push_back( subString );
//	}
//	
//	string mutVirusSeq = myInstr.getOrigVirusSeq();
//
//	/**
//	 * Create the mutated virus sequence by injecting the mutations into the original virus sequence
//	 */
//
//	vector<int>::iterator positionIterator;
//
//	stringIterator = aaVector.begin();
//	positionIterator    = positionVector.begin();
//	int posAdjuster = 0;//positionAdjuster
//	while( stringIterator != aaVector.end() ){
//		if( (*positionIterator) > (int)myInstr.getOrigVirusSeq().size() || (*positionIterator) < 1 ){
//			//cout << "(*positionIterator) " << (*positionIterator) << endl;
//			//cout << "myInstr.getOrigVirusSeq().size() " << myInstr.getOrigVirusSeq().size() << endl;
//			//cout << "positionVector.size() " << positionVector.size() << endl;
//			cerr << "\nMutation List attempted to change amino acid at position outside orginal sequence range." << endl;
//			cerr << "Mutated Sequence has been corrupted." << endl;
//			//cerr << "Bad mutation list = \"" << mutList << "\"" << endl;
//			//cerr << "Bad position = " << (*intIterator) << endl;
//			//cerr << "String at bad position = " << (*stringIterator) << endl;
//
//		}else{
//			mutVirusSeq.replace( ((*positionIterator)-1+posAdjuster), 1, *stringIterator );
//		}		
//			posAdjuster += (int)(*stringIterator).size() - 1;//adjust position for strings w/ >1 aa
//			stringIterator++;
//			positionIterator++;
//	}
//	return mutVirusSeq;
//}

void HivPreProcessor::parseData( vector<WorkUnit*>& myWuVector, bool isLibrary  ){

	//setup output streams for library
	stringstream outSuscepStream;
	stringstream outDrugStream;
	vector<string> drugLibSet;

	//save header row for library output
	outSuscepStream << dataSetVector.front() << endl;
	outDrugStream   << dataSetVector.front() << endl;
	{
		//find drug name index
		vector<string> headerVector;
		//(dataSetVector.begin()+1) makes it skip the header row
		headerVector.push_back( dataSetVector.front() );
		setDrugNameIndex( headerVector, myInstr.getDrug() );
	}

	//remove header line
	dataSetVector.erase( dataSetVector.begin() );

	vector<string>::iterator stringIterator;
	int _counter;//good samples used
	int _counterSamplesOutOfRange = 0;//samples out of range >, or <
	int _maxSamples;

	// numSamplesToUse equals zero, denotes 'use all possible samples'
	//numSamplesToUse variable is set in config file or cmd line
	if( isLibrary == true )
	{
		_maxSamples = myInstr.libraryFraction() * dataSetVector.size();
	}
	else
	{
		if( myInstr.numSamplesToUse() == 0 )
		{
			_maxSamples = dataSetVector.size();
		}
		else
		{
			_maxSamples = myInstr.numSamplesToUse();
		}
	}

	//first let's randomize which lines we want to use
	random_shuffle( dataSetVector.begin(), dataSetVector.end() );


//loop through entire susceptibility file
	for( 
		stringIterator = dataSetVector.begin(), _counter = 0; 
		stringIterator != dataSetVector.end() && _counter < _maxSamples; 
		stringIterator++ 
		)
	{
		//string currentString = (*stringIterator);

		//branch for creating  dataset for creating a new library
		//this will be a terminating point
		if( isLibrary == true )
		{
			//determine whether the line has the current drug positive, or not
			//&&
			//check if foldmatch is within range for this drug mutation combo
			if( _hasDrug( (*stringIterator) ) &&
				_isInFoldMatchRange( (*stringIterator) ) )
			{
				//save the drug strings for processing after we find them all
				drugLibSet.push_back( (*stringIterator) );
			}
			else
			{
				//add it to the shortened susceptibility stream
				outSuscepStream << (*stringIterator) << endl;
			}

		}
		
		//ok, don't make this a mutually exclusive thing. library creation is just addition
		//we need to make the WU's in order to save the cache of LA matrix
		
		/**
			Create Work Units that each have their:
			a. appropriate mutated viral sequence
			b. category
			c. all have the same OptionsAdapter reference
			d. IsolateName
		*/
			//determine whether the line has the current drug positive, or not
			//&&
			//check if foldmatch is within standard range for this drug mutation combo
			if( _hasDrug( *stringIterator ) )
			{
				if(	_isInFoldMatchRange( *stringIterator ) )
				{
					//now we're ready to make a WorkUnit with category, mutSeq from this line of data
					//and push that on the WorkUnitVector
					WorkUnit *w = new WorkUnit();
					_counter++;

					vector<string> drugLine;//holds the line
					_makeStringVector( (*stringIterator), drugLine );
			
					string str = drugLine.at( getDrugNameIndex() );
					double drugValue = atof( str.c_str() );
					w->setCategory( getCategory( drugValue ) );

					w->setIsolateName( drugLine.at( getIsolateNameIndex() ) );

					//@todo make a check where the genMutatedSeq can kill workunits if
					//it finds bad data in the input set. for instance, '*' symbol in a mutlist
					//denotes a poor datapoint, and should not be used.
					//or, should I make an aa seq checker function separately to scan the newly made
					//Wu's. This could be more easily updated as the dataset formats/or params change
					//-maybe, pass a container of 'bad' characters or strings that mean a Wu shouldn't be used.

					//cout << "drugLine.at( getMutListIndex() ) " << drugLine.at( getMutListIndex() ) << endl;
					//we currently assume data is cleaned already
					w->setAaSeq( genMutatedSeq( drugLine.at( getMutListIndex() ) ) );
					
					//store the workunit to output set
					myWuVector.push_back( w );
				}
				else
				{
					//increment counter of how many samples in the dataset had to be thrown out
					//for being out of range.
					_counterSamplesOutOfRange++;
				}
			}
			
		
	}//end for loop

	myInstr.numSamplesToUse( _counter );

	//cout << "Total number of usable samples pulled from the dataset = " << _counter << endl;
	//cout << "Total number of samples out of range from the dataset = " << _counterSamplesOutOfRange << endl;

	if( _counter < 10 )
	{
		cout << "Warning! Total number of usable samples was less than 10" << endl;
		cout << "Results may be unreliable" << endl;
	}

	//Library creation signifies end of program.
	//@todo make this a function
	if( isLibrary == true )
	{	
		//divide drugs to put in lib and ones to put back in outSuscepStream
		_separateLibDrugs( drugLibSet, outDrugStream, outSuscepStream );

		_saveLibraryFiles( outDrugStream, outSuscepStream  );

		//make a unique ID for checking/saving cache hits
		string str = outDrugStream.str();
		//cout << str;
		cacheId_ = Hash::hshstrhash( str.c_str() );

		//tell user we're done with this part
#ifndef QUIET
		cout << "Finished Phase 1 of library creation for " << myInstr.getDrug() << endl;
#endif		
		return;
	}
}

void HivPreProcessor::_makeStringVector( const string& i_string, vector<string>& o_stringSet )
{
	StringTokenizerAdapter _strTok;
	_strTok.setString( i_string, "\t" );

	while( _strTok.hasMoreTokens() )
	{
		o_stringSet.push_back( _strTok.nextToken() );
	}

	//DebugHelper::debug( o_stringSet, false );

}

//double HivPreProcessor::_parseDrugValue( const string& i_string )
//{
//	StringTokenizerAdapter _strTok;
//	_strTok.setString( i_string, "\t" );
//
//	vector<string> strSet;
//	while( _strTok.hasMoreTokens() )
//	{
//		strSet.push_back( _strTok.nextToken() );
//	}
//
//	string tempStr = strSet.at( getDrugNameIndex() );
//	double result = atof( tempStr.c_str() );
//	return result;
//}

bool HivPreProcessor::isValidMutationList_( const string&  i_string )
{
	if( i_string == "-" ||
		i_string == "." || 
		i_string == "" 
	  )
	{
		return false;
	}
	else
	{
		return true;
	}
}

bool HivPreProcessor::_isInFoldMatchRange( const string&  i_string )
{
	vector<string> strSet;
	_makeStringVector( i_string, strSet );
	
//	DebugHelper::debug( strSet, false );

	//foldmatch is always one column more than the fold value column for every drug
	string value = strSet.at( getDrugNameIndex()+1 );

	// > or < means the match is outside the normal range of values
	if( value == ">" || value == "<" ||
		value == "&gt;" || value == "&lt;" )
	{
		return false;
	}
	else
	{
		return true;
	}
}

bool HivPreProcessor::_hasDrug( const string& i_string )
{
	//StringTokenizerAdapter _strTok;
	//_strTok.setString( i_string, "\t" );

	//vector<string> strSet;
	//while( _strTok.hasMoreTokens() )
	//{
	//	strSet.push_back( _strTok.nextToken() );
	//}

	vector<string> strSet;
	_makeStringVector( i_string, strSet );
	
//	DebugHelper::debug( strSet, false );

	if( strSet.at( getDrugNameIndex() ) != noDrugValueName )
	{
		return true;
	}
	else
	{
		return false;
	}
}

void HivPreProcessor::_separateLibDrugs
	(
	vector<string>& m_strSet,
	stringstream& o_drugStream, 
	stringstream& o_suscepStream 
	)
{
	vector<string> o_libset;
	vector<string> o_nonlibset;
	
	//ok, now we separate the drugs to lib or not lib
	if( myInstr.libraryFraction() == 0.0 )
	{
		cout << "libraryFraction() is 0.0. This makes an empty library!" << endl;
		cout << "location of call:  HivPreProcessor::_separateLibDrugs" << endl;
		exit(1);

	}

	makeTrainAndClassifySets_
		( (1.0 - myInstr.libraryFraction() ), m_strSet, o_libset, o_nonlibset );

	//now add separate groups to the correct output streams
	vector<string>::const_iterator it;
	
	//to library output stream
	for( it=o_libset.begin();it!=o_libset.end();it++)
	{
		o_drugStream << *it << endl;
	}

	//to susceptibility output stream
	for( it=o_nonlibset.begin();it!=o_nonlibset.end();it++)
	{
		o_suscepStream << *it << endl;
	}
}



void HivPreProcessor::_saveLibraryFiles( const stringstream& i_drugStream, const stringstream& i_suscepStream )
{
		//write  new file to library folder
		//and drugfile.lib.

		stringstream drugPath;
		drugPath << "library/";

				//-additionally, the library dataset file doesn't use a threshold to make it.
		//so, remove that from the name.

		//write drug library dataset file
		stringstream drugFileName; 
		drugFileName << myInstr.getDrug();
		//drugFileName << "_threshold-" << myInstr.threshold();
		drugFileName << "_dataset.txt";
		
		IO::writeFile( drugFileName, i_drugStream, drugPath );

		stringstream suscepPath;
		suscepPath << "";


		//@todo remove all this crap.
		//this was stupid. I can't overwrite the old file b/c each line
		//has multiple drugs in it. not one. doh!

		//write shortened susceptibility file
		stringstream suscepFileName;
		suscepFileName << myInstr.getSusceptibilityDataFileName();
		//cout << "myInstr.getSusceptibilityDataFileName() " << myInstr.getSusceptibilityDataFileName() << endl;
		
		//temporary solution
		//IO::writeFile( suscepFileName, i_suscepStream, suscepPath );
}



//void HivPreProcessor::makeLibraryDataSets_( string& m_string )
//{
//
//	
//	//StringTokenizerAdapter _strTok;
//	//while( _strTok.hasMoreTokens() )
//	//{
//	//	tempVector.push_back( _strTok.nextToken() );
//	//}	
//}

int HivPreProcessor::getDrugNameIndex()
{
	return drugNameIndex;	
}

/**
	Since I don't know how to put in a space character from the cmd line, I'll need to tell the user
	to give me just the drugname part, 'APV', not 'APV FOLD'.  I think this is what Ljubomir would like
	any way. 
*/
bool HivPreProcessor::setDrugNameIndex( const vector<string>& myVector, string drugName  ){

	//tokenize myVector from one long string into a vector of strings
	//StringTokenizer *strTok;
	vector<string> tempVector;
	vector<string>::iterator stringIterator;
	stringIterator = ( dataSetVector.begin() );
	
	int counter = 0;
	string str = "";
	strTok_.setString( (*stringIterator), "\t" );
	while( strTok_.hasMoreTokens() ){
		//if first 3 letters of a token == drugName 
		str = ( strTok_.nextToken() ).substr(0,3);
		if( str == drugName  )
		{
			drugNameIndex = counter;
			return true;
		}
		else
		{
			counter++;
		}
		
		//tempVector.push_back( strTok->nextToken() );
	}

	//delete strTok;

	cout << "\nThe drug, " << drugName << ", was not found in the specified data set. Please recheck the data set and try again. \n" << endl;	
	cout << "Exiting";
	exit(0);

	//cout << "Enter a new drug name: ";
	//string newDrug = "New Drug Name Not Set";
	//cin >> newDrug;
	//myInstr->setDrug( newDrug );
	
	//exit(1);

	//if(	findStringIndex( tempVector, drugName ) != -1 ){
	//	drugNameIndex  = findStringIndex( tempVector, drugName );
	//	return true;
	//}else{
	//	cout << "\nThe drug, " << drugName << ", was not found in the specified data set. Please try again. \nExiting program." << endl;	
	//	exit(1);
	//	
	//}
}





void HivPreProcessor::setHeaders(){

	strTok_.setString( *dataSetVector.begin(), "\t" );
	while( strTok_.hasMoreTokens() ){
		headerVector.push_back( strTok_.nextToken() );
	}

	//delete strTok;
	//stringIterator = dataSetVector.begin();
	//while( stringIterator != dataSetVector.end() ){
	//	headerVector.push_back( *stringIterator );
	//	stringIterator++;
	//}
}

//now find the index, if not found, terminate the program or (better) ask for a new drug name
//also, we need to use the stl find algo to see if APV is in APV FOLD, see about.com reference
//find locates the position of the first occurrence of a value.	

//is find right? will it return true if if finds 'APV FOLD' while searching for 'APV'?
int HivPreProcessor::findStringIndex( const vector<string>& myVector, string searchString ){
	
	vector<string>::const_iterator stringIteratorConst;
	int counter = 0;

	//find it using STL find()
	stringIteratorConst = std::find(myVector.begin(), myVector.end(), searchString);

	//return -1 if not found
	if (stringIteratorConst == myVector.end()) {
       // cout << searchString << " was not found" << endl;
		return -1;
    }

	//great, we found the searchString, but
	//we still have to calculate the index to return.
	//count back to the beginning using the iterator
	while( stringIteratorConst != myVector.begin() ) {
			counter++;
			stringIteratorConst--;
	}

	return counter;

	//CODE below is for finding literal value.

	//stringIteratorConst = myVector.begin();
	////don't forget to tokenize this!
	//while( stringIteratorConst != myVector.end() &&
	//	*stringIteratorConst != searchString ) {
	//		counter++;
	//		stringIteratorConst++;
	//}

	//if( stringIteratorConst == myVector.end() ){
	//	return -1; //not found
	//}else{	
	//	return counter;
	//}
}



//	/**
//	 drugNameIndex refers to the header vector
//	*/
//bool HivPreProcessor::setDrugNameIndex( string drugName ){
//	
//	drugNameIndex = 0;
//
//	stringIterator = headerVector.begin();
//	while( stringIterator != headerVector.end() &&
//		*stringIterator != drugName ) {
//			drugNameIndex++;
//			stringIterator++;
//	}
//
//	if( stringIterator == headerVector.end() ){
//		drugNameIndex = -1;//not found 
//		return false;
//	}else{
//		return true;
//	}
//
//}
//int HivPreProcessor::getDrugNameIndex(){
//	return drugNameIndex;
//}
//
////TODO: change these two functions to one generic function: int findIndex(string)
//bool HivPreProcessor::setMutationListIndex( string mutName ){
//	mutationListIndex = 0;
//
//	stringIterator = headerVector.begin();
//	while( stringIterator != headerVector.end() &&
//		*stringIterator != mutName ) {
//			mutationListIndex++;
//			stringIterator++;
//	}
//
//	if( stringIterator == headerVector.end() ){
//		mutationListIndex = -1;//not found 
//		return false;
//	}else{
//		return true;
//	}
//}
//int HivPreProcessor::getMutationListIndex(){
//	return mutationListIndex;	
//}

int HivPreProcessor::cacheId()
{
	return cacheId_;
}
