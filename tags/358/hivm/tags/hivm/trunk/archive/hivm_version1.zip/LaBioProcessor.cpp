#include "LaBioProcessor.h"

LaBioProcessor::LaBioProcessor()
: BioProcessor()
{}

LaBioProcessor::~LaBioProcessor(){}

//@queestion any issues with randomization?
void LaBioProcessor::saveCache( const OptionsAdapter& i_optAdptr, const vector<WorkUnit*>& i_wus, bool isLibrary, int cacheId )
{
	//@todo implement regular cache
	//if( !isLibrary )
	//{
	//	return;
	//}

	//if( isLibrary)
	{
		//lib_APV_NumSamples_local_alignment.txt (la matrix)
		stringstream fileName;
		//fileName << "lib_";
		fileName << cacheId;
		fileName << "_" << i_optAdptr.getDrug();
	//	fileName << "_threshold-" << i_optAdptr.getThresholds().front();
		fileName << "_local_alignment_matrix.txt";

		stringstream pathName;
		pathName << "library/";

		stringstream output;
		vector<WorkUnit*>::const_iterator it;
		for( it=i_wus.begin(); it!=i_wus.end(); it++ )
		{
			vector<double> laScoreSet = (*it)->getNumSeq();
			
			//keep the extra comma from being put on the end of each line
			vector<double>::const_iterator dIt;
			for( dIt=laScoreSet.begin(); dIt!=(laScoreSet.end()-1); dIt++ )
			{
				output << *dIt << ", ";
			}
			
			output << *dIt;
			output << endl;
		}


		IO::writeFile( fileName, output, pathName );
	}
}

bool LaBioProcessor::checkCache( const OptionsAdapter& i_optAdptr, vector<WorkUnit*>& m_wus, bool isLibrary, int cacheId )
{
	//@todo implement regular cache
	//if( !isLibrary )
	//{
	//	return false;
	//}

	//@todo implement library cache
	//if( isLibrary )
	{
		//build proper file name and path	
		
		//lib_APV_NumSamples_local_alignment.txt (la matrix)
		stringstream fileName;
		//fileName << "lib_";
		fileName << cacheId;
		fileName << "_" << i_optAdptr.getDrug();
		fileName << "_local_alignment_matrix.txt";

		stringstream pathName;
		pathName << "library/";
	//	pathName << i_optAdptr.fractionSamplesToTest();_

		
		stringstream input;
		if( IO::readFile( fileName, input, pathName ) == false )
		{
			//no cache hit
			return false;
		}

		////check if file exists. ie. cache hit or not
		//if( input.str() == "" )
		//{
		//	return false;
		//}

		//load cache into WU set
		//now load the cached la scores into the current WorkUnit Set
		string lamatrix = input.str();
		StringTokenizerAdapter _strtok;
		_strtok.setString( lamatrix, "\n" );//split on std::endl

		vector<WorkUnit*>::const_iterator it;
		for( it=m_wus.begin(); it!=m_wus.end(); it++ )
		{
			vector<double> laScoreSet;
			string laRow = _strtok.nextToken();

			//get a vector of double
			parseLaRow_( laRow, laScoreSet );
			
			//copy the Local alignment score vector into the current wu
			(*it)->getNumSeq() = laScoreSet;
		}

		//cout << "Local Alignment Matrix Cache Hit! Id = " << cacheId << endl;
		return true;
	}
}

void LaBioProcessor::parseLaRow_( const string i_string, vector<double>& o_dblSet )
{
	StringTokenizerAdapter _strtok;
	_strtok.setString( i_string, "," );
	while( _strtok.hasMoreTokens() )
	{
		//cout << "_strtok.nextFloatToken() " << _strtok.nextFloatToken() << " ";
		o_dblSet.push_back( _strtok.nextFloatToken() );
	}

	//cout << endl;
}

/**
THIS IS WRONG. 5/1/05 UPDATE the algorithm.

1. push needClassifyingWUs on back of training WU's before BioProcess occurs. -no
2. after every WU gets a numSeq filled, pop the needClassifyingWUs off the traiingWU's set -no
3. I think that's it. do some tests to make sure everyone has correct information afterwards 

CORRECT ALGORITHM

sub function. 
for each vector in "needsClassifyfingWus".
	compute LA of that vector against each vector in TrainingVector. excluding the identity LA.
	store this in the needsClassifyingWu's numSeq vector
	this numSeq must equal the number of trainingWus
	scale this NumSeq this

rules: 
-The trainingWUs NEVER store any information about the predictionWus
-The predictionWus NEVER store any information about the other predictionWus

2 sub functions:
1. map trainingWus to feature space
2. map a predictionWu to feature space

*/
/**
@purpose create local alignment matrix, and prepare predictees for libsvm use
@param
@param
@param isCacheHit if LA matrix is cached set to true
*/
void LaBioProcessor::process( 
		vector<WorkUnit*>& m_trainingWUs, 
		vector<WorkUnit*>& m_predictionCandidateWUs,
		bool isCacheHit
		)
{

	//don't run this if cache hit already occurred
	if( isCacheHit == false )
	{
		mapTrainingModelToFeatureSpace( m_trainingWUs );
	}
#ifndef QUIET
	cout << "Mapping " << m_predictionCandidateWUs.size() << " Prediction Sequences against ";
	cout << m_trainingWUs.size() << " Training Sequences." << endl;
#endif	
	for( wuIterator i = m_predictionCandidateWUs.begin(); i != m_predictionCandidateWUs.end(); i++ )
	{
		mapAPredictionCandidateToFeatureSpace( m_trainingWUs, (*i) );
		cout << ".";
	}
	cout << endl;

}

/**

i_trainingWUs = Training Work Units are not modified by this function
m_needClassifyingWUs = Prediction Candidates are modified by this function
*/
void LaBioProcessor::mapAPredictionCandidateToFeatureSpace( std::vector<WorkUnit*>& i_trainingWUs, WorkUnit* m_predictionCandidateWU )
{
	string tempPredStr = m_predictionCandidateWU->getAaSeq();
	const char* predictionStr = tempPredStr.c_str();
	
	float result;
	wuIterator curPos = i_trainingWUs.begin();	
	
	while( curPos != i_trainingWUs.end() )
	{
		string tempTrainStr = (*curPos)->getAaSeq();
		const char* trainingStr = tempTrainStr.c_str();
		//run Local Alignment from dpl
		result = local_alignment( (char*)trainingStr, (char*)predictionStr, 1, NULL, 0.0, 0.0 );
		m_predictionCandidateWU->getNumSeq().push_back( result );
		curPos++;
		//cout << ".";
	}
	//cout << endl;
}

/**

m_trainingWUs = Training Work Units are modified by this function
*/
void LaBioProcessor::mapTrainingModelToFeatureSpace( std::vector<WorkUnit*>& m_trainingWUs )
{

	wuIterator curPos = m_trainingWUs.begin();//current WU comparing self to all others
	

	wuIterator walker;//walker to traverse other WU's
	float result;

	curPos = m_trainingWUs.begin();
#ifndef QUIET
	std::cout << "Computing Local Alignment scores for a " << (int)m_trainingWUs.size();
	std::cout << " x " << (int)m_trainingWUs.size() << " matrix." << std::endl;
#endif
	//row specifies which row of the matrix to start with per iteration
	//using 0 based counting
	int row = 0;
	int col = 0;

	//for each m_trainingWUs, compute it's local alignment score against all other work units 
	//(including self), and store this back in the curPos work unit
	//curPos is the matrix row
	while( curPos != m_trainingWUs.end() )
	{
		//convert from string to char*
		string str = (*curPos)->getAaSeq();
		const char* curPosCstringConst = str.c_str();

		walker = m_trainingWUs.begin();
		//let's walker skip past completed rows in matrix
		//we complete a row each iteration, and never want to return to it.
		walker = walker + row;
		
		col = row;//reset column counter to match 

		//walk down the list of work units
		//walker is the matrix column
		while( walker != m_trainingWUs.end() )
		{
			//convert from string to char*
			string str2 = (*walker)->getAaSeq();
			const char* walkerCstringConst = str2.c_str();

			//run Local Alignment from dpl.c
			result = local_alignment( (char*)curPosCstringConst, (char*)walkerCstringConst, 1, NULL, 0.0, 0.0 );

			//insert local_alignment value into m_trainingWUs numSeq (current matrix row )
			(*curPos)->getNumSeq().push_back( result );

			//don't pushback for la(AA) = la(AA)
			if( col != row )
			{
				//insert same value into current matrix column la(AB) = la(BA)
				(*walker)->getNumSeq().push_back( result );
			}

			
			//#ifdef _DEBUG
			//	//now print partial matrix for debugging
			//	this->printUnscaled( m_trainingWUs );
			//#endif
			//increment walker
			walker++;
			//increment column
			col++;
		}
		curPos++;
		row++;
	}

}

//void LaBioProcessor::process( std::vector<WorkUnit*>& wu )
//{
//
//	std::vector<WorkUnit*>::iterator curPos = wu.begin();//current WU comparing self to all others
//	std::vector<WorkUnit*>::iterator walker;//walker to traverse other WU's
//	float result;
//
////temp
//	while( curPos != wu.end() )
//	{
//		std::cout << (*curPos)->getAaSeq() << std::endl;
//		curPos++;
//	}
//	curPos = wu.begin();
//
//	std::cout << "Computing Local Alignment scores for a " << (int)wu.size();
//	std::cout << " x " << (int)wu.size() << " matrix." << std::endl;
//
//	//int nextStartingPoint = 0;
//	//walker = wu.begin();
//
//	//for each wu, compute it's local alignment score against all other work units 
//	//(including self), and store this back in the curPos work unit
//	while( curPos != wu.end() )
//	{
//		//convert from string to char*
//		string str = (*curPos)->getAaSeq();
//		const char* curPosCstringConst = str.c_str();
//
//		//copy constant c-string to non-constant string, including '\0'
//	//	char* curPosCstring = (char*)curPosCstringConst;
//		//char* resultCstring = std::strcpy( curPosCstring, curPosCstringConst );
//
//		//increment walker
//		//walker = wu.begin(); //wuCtnr Work Unit Container
//		//now I need to walker to not always start at position 0.
//		//I need it circle the container list. better container class for this?
//		walker = wu.begin();
//		//walker += nextStartingPoint;
//		//nextStartingPoint++;
//
//		//walk down the list of work units
//		while( walker != wu.end() )
//		{
//			//convert from string to char*
//			string str2 = (*walker)->getAaSeq();
//			const char* walkerCstringConst = str2.c_str();
//			
//			//copy constant c-string to non-constant string, including '\0'
//			//char* walkerCstring = (char*)walkerCstringConst;
//		//	strcpy( walkerCstring, walkerCstringConst );
//			
//			//cout << "curPosCstring = " << curPosCstring << endl;
//			//cout << "walkerCstring = " << walkerCstring << endl;
//			//
//			//cout << "curPosCstring = " << (*curPos)->getIsolateName() << endl;
//			//cout << "walkerCstring = " << (*walker)->getIsolateName() << endl;
//
//
//			//run Local Alignment from dpl.c
//			result = local_alignment( (char*)curPosCstringConst, (char*)walkerCstringConst, 1, NULL, 0.0, 0.0 );
//
//			//insert local_alignment value into WU numSeq
//			//cout << "pushing LA result on WU # " << (*curPos)->getIsolateName() << ": ";
//			//cout << result << endl;
//			//cout << endl;
//			(*curPos)->getNumSeq().push_back( result );
//
//			//increment walker
//			walker++;
//		}
//		curPos++;
//	}
//	
//
//}
