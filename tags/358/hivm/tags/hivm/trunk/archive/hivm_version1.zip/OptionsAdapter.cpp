#include "OptionsAdapter.h"


int OptionsAdapter::getNumOfCategories() const
{
	return Instruction::getNumOfCategories();
}

unsigned long OptionsAdapter::uniqueID() const
{
	return uniqueID_;
}

string OptionsAdapter::resultsPath() const
{
	return resultsPath_;
}

void OptionsAdapter::resultsPath( string resultsPath )
{
	resultsPath_ = resultsPath;
}

string OptionsAdapter::libraryPath() const
{
	return libraryPath_;
}

void OptionsAdapter::libraryPath( string libraryPath )
{
	libraryPath_ = libraryPath;
}

//returns the first threshold
double OptionsAdapter::threshold()
{
	return instr_.getThresholds().front();
}

//Default Constructor
//uses default options file
//initializes internal Instruction and Options
OptionsAdapter::OptionsAdapter() :
	instr_(),
	options_(),
	strTok_(),
	numSamplesToUse_(0),
	fractionSamplesToTest_(0.0),
	sampleType_( All ),
	costLow_(0.0),
	costHigh_(0.0),
	costIncrement_(0.0),
	gammaLow_(0.0),
	gammaHigh_(0.0),
	gammaIncrement_(0.0),
	libraryFraction_(0.0),
	predicteeSeqsFileName_(""),
	thresholdsLevel_(""),
	libraryPath_("library/"),
	enzyme_("PI")
{

	//std::cout << "called OptionsAdapter ctor" << endl;
	//DEFAULT_OPTIONS_FILE_NAME = "configDefault.txt";
	//initialize( DEFAULT_OPTIONS_FILE_NAME );
}

//Constructor for custom options file
OptionsAdapter::OptionsAdapter( string optionsFileName ) :
	instr_(),
	options_(),
	strTok_(),
	numSamplesToUse_(0),
	fractionSamplesToTest_(0.0),
	sampleType_( All ),
	costLow_(0.0),
	costHigh_(0.0),
	costIncrement_(0.0),
	gammaLow_(0.0),
	gammaHigh_(0.0),
	gammaIncrement_(0.0),
	libraryFraction_(0.0),
	predicteeSeqsFileName_(""),
	thresholdsLevel_(""),
	libraryPath_("library/"),
	enzyme_("PI")
{
	//std::cout << "called OptionsAdapter ctor" << endl;
	//initialize( optionsFileName );
	
}

//Default Destructor
OptionsAdapter::~OptionsAdapter( )
{
	//std::cout << "called OptionsAdapter dtor" << endl;
}


// hard coded var's from PhaseMachine Option class
int OptionsAdapter::getCacheSize() const
{
	return 40;
}

double OptionsAdapter::getP() const
{
	return 0.1;
}

int OptionsAdapter::getProbability() const
{
	return 0;
}
int OptionsAdapter::getShrinking() const
{
	return 1;
}
int OptionsAdapter::getNrWeight() const
{
	return 0;
}
std::string OptionsAdapter::getWeightLabel() const
{
	return "N/A";
}

std::string OptionsAdapter::getWeight() const
{
	return "N/A";
}


void OptionsAdapter::printParam()
{
	std::cout << "Printing svm parameters\n" << std::endl;
	std::cout << "Svm Type:" << options_.GetSVMType() << std::endl;
	std::cout << "Kernel Type:" << options_.GetKernel() << std::endl;
	std::cout << "degree:" << options_.GetDegree() << std::endl;
	std::cout << "gamma:" << options_.GetGamma() << std::endl;
	std::cout << "coefficient:" << options_.GetCoefficiant() << std::endl;
	std::cout << "nu:" << options_.GetNu() << std::endl;
	std::cout << "cache size:" << this->getCacheSize() << std::endl;
	std::cout << "C:" << options_.GetCost() << std::endl;
	std::cout << "eps:" << options_.GetTermCriterion() << std::endl;
	std::cout << "p:" << this->getP() << std::endl;
	std::cout << "shrinking:" << this->getShrinking() << std::endl;
	std::cout << "probability:" << this->getProbability() << std::endl;
	std::cout << "nr_weight:" << this->getNrWeight() << std::endl;
	std::cout << "weight_label:" << this->getWeightLabel() << std::endl;
	std::cout << "weight:" << this->getWeight() << std::endl;

}

//protected
//@todo - include cmd line parameters in hashing function to make uniqueID
void OptionsAdapter::initialize( string fileName )
{
	ifstream inFile( fileName.c_str() ); // Read
//	int i = 1; // Line counter
	string myStr;//buffer
	stringstream configStream;//for hashing uniqueID

	if( inFile.is_open() ){// Verify open
		
		//Instruction
		//line 1,2 label and definitions
		std::getline( inFile, myStr );configStream << myStr << endl;
		std::getline( inFile, myStr );configStream << myStr << endl;
		//line 3 for Instruction class params
		std::getline( inFile, myStr );configStream << myStr << endl;
		//process line 3 - NOT ANY MORE. Do this using cmd line now in parseInput()
		//instr_.initialize( myStr );

		//space line 4
		std::getline( inFile, myStr );configStream << myStr << endl;

		//SVM PARAM
		//line 5,6 label and definitions
		std::getline( inFile, myStr );configStream << myStr << endl;
		std::getline( inFile, myStr );configStream << myStr << endl;
		//line 7 for Options class params
		std::getline( inFile, myStr );configStream << myStr << endl;
		//process line 7
		initSvmParam( myStr );
		
		//space line 8
		std::getline( inFile, myStr );configStream << myStr << endl;

		//PERFORMANCE EVALUATION PARAMETERS:
		//line 9,10 label and definitions
		std::getline( inFile, myStr );configStream << myStr << endl;
		std::getline( inFile, myStr );configStream << myStr << endl;
		//line 11 for performance evaluation params
		std::getline( inFile, myStr );configStream << myStr << endl;
		//process line 11 at line 14
		//DEPRECATED: Don't use eval performance option anymore
		//string performStr = myStr;

		//space line 12,13
		std::getline( inFile, myStr );configStream << myStr << endl;
		std::getline( inFile, myStr );configStream << myStr << endl;

		//line 14 label and definitions
		std::getline( inFile, myStr );configStream << myStr << endl;// cout << "14 " << myStr;
		//line 15 for performance evaluation params
		std::getline( inFile, myStr );configStream << myStr << endl;//cout << "15 " << myStr;
		//process line 15
		//combine performance eval params
		//string performStr2 = performStr + " " + myStr;
		initPerformanceEvaluationOptions( myStr );


	//svmParamPtr->svm_type = NU_CLASSIFICATION;
	//svmParamPtr->kernel_type = RBF;
	//svmParamPtr->degree = 3.0;	/* for poly */
	//svmParamPtr->gamma = 0.0;	/
	//	* for poly/rbf/sigmoid */
	//svmParamPtr->coef0 = 0.0;	/* for poly/sigmoid */

	///* these are for training only */
	//svmParamPtr->cache_size = 40; /* in MB */
	//svmParamPtr->eps = 0.0;	/* stopping criteria */
	//svmParamPtr->C = 1;	/* for C_SVC, EPSILON_SVR and NU_SVR */
	//svmParamPtr->nr_weight = 1;/* for C_SVC */
	//svmParamPtr->nu = 0.0;	/* for NU_SVC, ONE_CLASS, and NU_SVR */
	//svmParamPtr->p = 0.0;	/* for EPSILON_SVR */
	//svmParamPtr->shrinking = 0;	/* use the shrinking heuristics */
	//svmParamPtr->probability = 0;

	}
	else//can't find options file or open it for some reason
	{
		std::cerr << "Cannot open options file named: " + fileName << std::endl;
		std::cerr << "Exiting program" << std::endl;
		exit(1);
	}

	inFile.clear();//clean out inFile
	inFile.close();

	//add cmd line parameters to the bottom of the config file output
	configStream << endl << "COMMAND LINE PARAMETERS" << endl;

	vector<string>::const_iterator it;
	for(it=cmdLineArgSet_.begin(); it!=cmdLineArgSet_.end(); it++)
	{
		configStream <<  *it << " ";
	}
	

	//now create uniqueID
	string tempStr = configStream.str();
	uniqueID_ = Hash::hshstrhash( tempStr.c_str() );

	//set results relative path
	resultsPath_ = "results/";

	//save config details to file. along w/ cmd line
	printConfiguration_( configStream );
}



void OptionsAdapter::printConfiguration_( const stringstream& i_outStream )
{
	////prepare outfile
	//ofstream outFile;
	//if( outFile.is_open() )
	//{
	//	outFile.close();
	//}
	//outFile.flush();
	//outFile.clear();

	//prepare filename
	stringstream fileName;
	fileName << uniqueID();
	//fileName << "_" << this->getDrug();//use cmdLine drug
	//	fileName << "_" << getDrug();
	fileName << "_" << "config.txt";

	stringstream pathName;
	pathName << resultsPath();

	IO::writeFile( fileName, i_outStream, pathName );

	//outFile.open( fileNameStream.str().c_str(), ofstream::out );

	////write to file system
	//outFile << i_outStream.rdbuf();
	//outFile.close();

}

void OptionsAdapter::printUsage()
{
	cout << "hivm is an application for prediction of HIV drug resistance using Support Vector Machine algorithsm" << endl;
	cout << "Usage: hivm.exe operation_mode input_files [OPTIONS]" << endl << endl;

	cout << "User Examples:" << endl;
	cout << "  hivm -profile FASTA_input_file	[resistance_threshold_level (low, default, high)] [hiv_enzyme (RT,PI)] " << endl << endl;

	cout << "  The profile function takes in a list of unknown hiv enzyme sequences, and outputs a drug resistance profile file for each sequence.";
	cout << "  In other words, it reports whether a sequence is resistant or not for every RT or PI antiviral drug in hivm's drug list." << endl;
	cout << "  The drug list is located at: /library/drugset.txt " << endl;
	cout << "  The FASTA input file should contain either RT or PI enzymes, but not both. "<< endl;
	cout << "  The resistance threshold levels are different for different drugs. The individual levels can be viewed in the /library/[default,low,high]_thresholds.txt " << endl;
	cout << "  The hiv enzyme parameter should match the input FASTA file. Choices are Reverse Transcriptase (RT) or Protease (PI). " << endl;
	cout << "  Output files are placed in the 'results' folder " << endl << endl;
	
	cout << "Administrator Examples:" << endl;

	cout << " 	hivm -library [HIVDB susceptiblity file] [standard enzyme sequence FASTA file] [drug name abreviation] [resistance threshold (3.5, 2.0, etc)] "<< endl << endl;

	cout << "  Caution: This process can take more than 24 hours to complete if the input dataset greater than 100 samples." << endl << endl;

	cout << "  The library function creates a cache from the known drug resistance data that is used to make predictions for the drug profiles, ";
	cout << "  and also creates gnuplot scripts that can create ROC Curve images for each drug using a wide range of parameter";
	cout << "  pairs. The resulting ROC curve can be used to choose optimal cost, gamma pairs for training each drug�s model." << endl;
	cout << "  Output files are placed in the 'library' folder " << endl << endl;

	cout << "  There are two main options for running -validate library. You can choose to pass a single cost, gamma pair for validation or you ";
	cout << " can type '-paramsearch' instead of giving the cost and gamma. This will try every c,g pair in the range defined by the file: configDefault.txt." << endl << endl;

	cout << " 	hivm -validatelibrary [HIVDB susceptiblity file]  [resistance_threshold_level (low, default, high)] [drug name abreviation] ";
	cout << " [cost] [gamma] " << endl << endl;
	
	cout << " 	hivm -validatelibrary [HIVDB susceptiblity file]  [resistance_threshold_level (low, default, high)] [drug name abreviation] ";
	cout << " -paramsearch " << endl << endl;


	cout << "  The validatelibrary function is used to evaluate the effectiveness of hivm to correctly predict drug resistance." << endl;
	cout << "  Choose a drug and set it's cost and gamma parameters. The threshold must be use a preset value of low, default or high. "<< endl;
	cout << "  The susceptibility file should be in Stanford HIV Database format, and should not have been used during hivm library creation." << endl;	
}

string OptionsAdapter::parseInput( int argc,  char * argv[] )
{
	//if no args, tell them how to use the system and exit
	if (argc <= 1 )
	{
		printUsage();
		exit(0);
	}

/**
USAGE:
hivm.exe [type of execution] [location of FASTA/stanford db src file ] [location of standard sequence ][drug] [theshold] 
		
	//  -eval runs roc and also automatically picks g,c pair[s] for testing. 
		-eval			files/PI_suscep.dat	unit_tests/files/PI.seq	APV		3.5		[number samples to use, 0=all]		[fraction of 'num of samples' to test on] -config [config filename]
	
	depricated // -roc outputs a roc curve
	depricated	-roc			files/RT_suscep.dat	unit_tests/files/RT.seq	APV		3.5		[number samples to use]		[fraction of src file to test]				
	
	depricated// -test doesn't create a roc curve. splits b/t training and test. g,c pair provided by user
	depricated	-test			files/PI_suscep.dat	unit_tests/files/PI.seq	APV		3.5		[number samples to use]		[fraction of src file to test] [cost] 3.0  [gamma] 15.0 
	
	//-library [susceptiblity file for library only!] [location of standard sequence ] [drug] [percent of dataset for library] [theshold (3.5, 2.0, etc)]

	// -profile (might be a better term since we're making drug profiles with this.)
	// -profile the model is auto chosen from library. user provides unknown samples and g,c pair
	// unknown samples should be in FASTA format
	// Requires creation of fixed set of library of training sets.
	-profile		files/unkown_seqs.fasta		[threshold level (low, default, high)]	
	-profile		files/unkown_seqs.fasta		[threshold level (low, default, high)]	

	@purpose to see how each known sequence does for it's drug profile
	similar to eval, but don't run 'findbestparams'. use the library recommendations instead.
	so,
	1. grab a seq, use the library of each drug on it.
	2. Record profiles like normal. (or ditch this for now)
	3. Also, keep up with hits and misses, and output the stats for each drug. (use the eval stats)
	
	-validatelibrary files/hivdb-testset.dat    [threshold level (low, default, high)]
	hivm -validatelibrary [HIVDB susceptiblity file]  [resistance_threshold_level (low, default, high)] [drug name abreviation] [cost] [gamma] 
*/	
	//start saving cmd args (not hivm.exe)
	for (int i = 1; i < argc; i++)
	{
		string str = argv[i];
		cmdLineArgSet_.push_back( argv[i] );
	}

	//check for custom config file
	bool isCustomConfig = false;
	vector<string>::const_iterator it;
	for(it=cmdLineArgSet_.begin(); it!=cmdLineArgSet_.end(); it++)
	{
		if( (*it) == "-config" )
		{
			isCustomConfig = true;
			it++;
			//initialize custom config
			initialize( *it );
			break;
		}
	}

	DEFAULT_OPTIONS_FILE_NAME = "configDefault.txt";
	if( isCustomConfig == false )
	{
		initialize( DEFAULT_OPTIONS_FILE_NAME );
	}

	if( cmdLineArgSet_[0] == "-help" || cmdLineArgSet_[0] == "-h" )
	{
		printUsage();
		exit(0);
	
	}//full performance evaluation
	else if( cmdLineArgSet_[0] == "-eval" )
	{
		cout << cmdLineArgSet_[0] << endl;
		
		//@todo
		//ok, we're going ot put this in a string and pass it to 
		//	Instruction(initialize)
		//now, can I set the percent later? yes b/c I just input the entire
		//dataset first. then I randomize and select a percent later.
		stringstream instructionStream;

		//set dataset
		instructionStream << cmdLineArgSet_[1] << " ";

		//set orig virus seq
		instructionStream << cmdLineArgSet_[2] << " ";

		//set drug name
		instructionStream << cmdLineArgSet_[3] << " ";

		//set number of thresholds to fixed 2. ROC analysis requires
		//binary classification, but originally, we planned on more categories
		instructionStream << 2 << " ";

		//set threshold value
		instructionStream << atof ( cmdLineArgSet_[4].c_str() ) << " ";

		//now pass this string to the local Instruction var.
		//Instruction was written first, and takes input in this format.
		instr_.initialize( instructionStream.str() );

		//these variables are used later in processing. not by Instruction.
		numSamplesToUse_ = atoi( cmdLineArgSet_[5].c_str() );
		
		fractionSamplesToTest_ = atof ( cmdLineArgSet_[6].c_str() );

		return cmdLineArgSet_[0];
	}
	else if( cmdLineArgSet_[0] == "-library" )
	{
		//-library [susceptiblity file for library only!] [location of standard sequence ] [drug] [percent for library] 
		
		cout << "Creating a drug library. Caution: This process can take more than 24 hours to complete if the input dataset greater than 100 samples." << endl;

		//ok, we're going ot put this in a string and pass it to 
		//	Instruction(initialize)
		//now, can I set the percent later? yes b/c I just input the entire
		//dataset first. then I randomize and select a percent later.
		stringstream instructionStream;

		//set dataset
		instructionStream << cmdLineArgSet_[1] << " ";

		//set orig virus seq
		instructionStream << cmdLineArgSet_[2] << " ";

		//set drug name
		instructionStream << cmdLineArgSet_[3] << " ";

		//set number of thresholds to fixed 2. ROC analysis requires
		//binary classification, but originally, we planned on more categories
		//not actually used to create Library
		instructionStream << 2 << " ";

		//set threshold value
		//not actually used to create Library.
		//update: actually, creating the library involves classification.
		//a threshold must be used to determine which class. that's just how it works.
		//now, the la matrix doesn't involve classification, so that cache can be used
		//regardless of threshold 
		//it's the auto-param's file that needs a threshold to be part of it.
		//-additionally, the library dataset file doesn't use a threshold to make it.
		//so, remove that from the name.
		instructionStream << atof( cmdLineArgSet_[4].c_str() ) << " ";

		//now pass this string to the local Instruction var.
		//Instruction was written first, and takes input in this format.
		instr_.initialize( instructionStream.str() );

		//for library, use 100%
		//libraryFraction_ = atof ( cmdLineArgSet_[4].c_str() );
		libraryFraction_ = 1;

		//for libraries use, all possible samples
		numSamplesToUse_ = 0;

		return cmdLineArgSet_[0];

	}
	else if( cmdLineArgSet_[0] == "-profile" )
	{
	//-predict		files/unkown_seqs.fasta		[threshold Level]

		predicteeSeqsFileName_ = cmdLineArgSet_[1];
		
		thresholdsLevel_ = cmdLineArgSet_[2];//low,default, high

		enzyme_ = cmdLineArgSet_[3];//PI or RT

		//check for legal enzyme types
		if( enzyme_ == "PI" || enzyme_ == "RT" )
		{
			//do nothing
		}
		else
		{
			cout << "Sorry, the enzyme type must be either PI or RT. You used: " << enzyme_ << endl;
			printUsage();
			exit(0);
		}

		//now set some bogus values for Instruction initializer
		//i know, i know, this is bad form. refactor later.
		//anyway, prediction doesn't use these, and we set the necessary
		//variables before each run.

		stringstream instructionStream;

		//set dataset
		instructionStream << "n/a" << " ";

		//set orig virus seq
		instructionStream << "library/PI.seq" << " ";

		//set drug name
		instructionStream << "n/a" << " ";

		//set number of thresholds to fixed 2. ROC analysis requires
		//binary classification, but originally, we planned on more categories
		//not actually used to create Library
		instructionStream << 2 << " ";

		//set threshold value
		//not actually used to create Library
		instructionStream << 2 << " ";

		//now pass this string to the local Instruction var.
		//Instruction was written first, and takes input in this format.
		instr_.initialize( instructionStream.str() );

		//I need a new class to handle all this shit.
		//do I need to setup the OptionAdapter? yes, that's why you saved
		//those apv_3.4threshold_dataset.txt's in the library.
		//just need to turn the fasta into ClassifySet WU's.
		//then let the program do it's thing.

		//then write functions to save the results. done. :)

		//need uml diagram
//		parsePredicteeSeqsFile();
//		savePredicteeResults();
		
		//NOPE, not taking cost and gamma from cmd line.
		//b/c c,g is different for each drug. use automated version now
		//we can allow custom work later. maybe store automated c,g's into the
		//thresholds files? some way for user to peruse the ROC curves, and list
		//out her choices of c,g for each drug. might as well be all in one file
		//only thing is me putting cost and gamma in that file. well, I can do
		//that by hand if I need to. ain't but 57 times to do it. 19*default,low,high
		//whatever, worry about that feature later...

		//double cost      = atof ( cmdLineArgSet_[3].c_str() );
		//double gamma     = atof ( cmdLineArgSet_[4].c_str() );

		return cmdLineArgSet_[0];

		//ok, if I let the user put threshold here, then it will apply to all sequences in the file
		//it will NOT have to look for library based on that threshold. ok, good.
		// but it would put the same theshold o

		//ok, GOAL?
		//give a sequence(s). check it against all 19 drugs. write "resistant or not" results to a file.
		//ok, but what about, the thesholds? it's a threshold for each drug. possibly different for each drug.
		//possible solutions:
		//offer choices of -low, -regular, -high, and I hard code these into the program. get these from the geno2pheno program.
		//	or better yet, I put them in files in the library. and ultimately, I let the user make their own files in my
		//	format, and choose them. so, maybe: -custom [user thresholds filename]
	
		//ok, so, let's start w/ -regular file. does that cover our goal?
		//let's see, library is threshold independent. then, we train (and cache) many models based on a thresholds.
		//then cycle through all the test sequences, yada, yada. ..
		//output a file to the results dir: "inputfilename"_"thesholdfilename"_hivm_results.txt
		//format:
		//sequence fasta ID> CA2322
		//sequence DFKLJDKDK
//header  DRUG	THRESHOLD	RESISTANT? (True/False)	Log2Cost: -2 Log2Gamma: 4
		//APV	   3.5			T
		//NFV	   4.0			F
		//etc
		//space

		//REPEAT

		//OK, I LIKE THAT. GOOD PLAN. 

	}
	else if ( cmdLineArgSet_[0] == "-unit_tests" )
	{
		return cmdLineArgSet_[0];
	}
	//-variabilityTest [HIVDB training set file] [orig virus seq] [drug name abreviation] [resistance_threshold_level (low, default, high)]  [cost] [gamma]
	else if( cmdLineArgSet_[0] == "-variabilityTest" )
	{

//ok, we're going ot put this in a string and pass it to 
		//	Instruction(initialize)
		//now, can I set the percent later? yes b/c I just input the entire
		//dataset first. then I randomize and select a percent later.
		stringstream instructionStream;

		//set dataset
		instructionStream << cmdLineArgSet_[1] << " ";

		//set orig virus seq
		instructionStream << cmdLineArgSet_[2] << " ";

		//set drug name
		instructionStream << cmdLineArgSet_[3] << " ";

		//set number of thresholds to fixed 2. ROC analysis requires
		//binary classification, but originally, we planned on more categories
		//not actually used to create Library
		instructionStream << 2 << " ";

		//set threshold value
		instructionStream << atof ( cmdLineArgSet_[4].c_str() ) << " ";

		//now pass this string to the local Instruction var.
		//Instruction was written first, and takes input in this format.
		instr_.initialize( instructionStream.str() );

		cmdLineCost_      = atof ( cmdLineArgSet_[5].c_str() );
		cmdLineGamma_     = atof ( cmdLineArgSet_[6].c_str() );

		//for library, use 100%
		//libraryFraction_ = atof ( cmdLineArgSet_[4].c_str() );
		libraryFraction_ = 1;

		//for libraries use, all possible samples
		numSamplesToUse_ = 0;

		return cmdLineArgSet_[0];


	}
	else if( cmdLineArgSet_[0] == "-validatelibrary" )
	{
//-validatelibrary [HIVDB susceptiblity file]  [resistance_threshold_level (low, default, high)] [drug name abreviation] [cost] [gamma] 
//DEPRECATED -validatelibrary files/hivdb-testset.dat    [threshold level (low, default, high)]
		
		predicteeSeqsFileName_ = cmdLineArgSet_[1];
		
		thresholdsLevel_ = cmdLineArgSet_[2];//low,default, high

		//now set some bogus values for Instruction initializer
		//i know, i know, this is bad form. refactor later.
		//anyway, prediction doesn't use these, and we set the necessary
		//variables before each run.

		stringstream instructionStream;

		//set dataset
		instructionStream << "n/a" << " ";

		//set orig virus seq. For validatelibrary function, this will be set after
		//the program reads the seq name from drugset.txt. This links enzyme to drug name.
		instructionStream << "library/PI.seq" << " ";

		//set drug name
		instructionStream <<  cmdLineArgSet_[3].c_str() << " ";

		//set number of thresholds to fixed 2. ROC analysis requires
		//binary classification, but originally, we planned on more categories
		//not actually used to create Library
		instructionStream << 2 << " ";

		//set threshold value
		//not actually used to in validate library, since we're pulling this number from a threshold list in 'library'
		instructionStream << 99999 << " ";



		//now pass this string to the local Instruction var.
		//Instruction was written first, and takes input in this format.
		instr_.initialize( instructionStream.str() );

		//choose between running a c,g parameter search, or being handed a
		//single c,g pair from cmd line

		string _isParamSearch = cmdLineArgSet_[4].c_str();

		if( _isParamSearch == "-paramsearch" )
		{
			return "-validatelibraryParamSearch";
		}
		else //single c,g pair. 
		{
			cmdLineCost_      = atof ( cmdLineArgSet_[4].c_str() );
			cmdLineGamma_     = atof ( cmdLineArgSet_[5].c_str() );
			
			return "-validatelibrarySinglePair";
		}
		
	}
	else
	{	
		cout << "Sorry, " << cmdLineArgSet_[0] << " is not a valid parameter to run hivm" << endl;
		printUsage();
		return cmdLineArgSet_[0];
	}



}

void OptionsAdapter::initPerformanceEvaluationOptions( string i_options )
{
	strTok_.setString( i_options, " " );

	//numSamplesToUse_ = atoi( strTok_.nextToken().c_str() );
	//fractionSamplesToTest_ = atof( strTok_.nextToken().c_str() );
	//sampleType_ = static_cast<OptionsAdapter::enumSampleType>(atoi( strTok_.nextToken().c_str() ) ) ;

	costLow_ = atof( strTok_.nextToken().c_str() );
	costHigh_ = atof( strTok_.nextToken().c_str() );
	costIncrement_ = atof( strTok_.nextToken().c_str() );

	gammaLow_ = atof( strTok_.nextToken().c_str() );
	gammaHigh_ = atof( strTok_.nextToken().c_str() );
	gammaIncrement_ = atof( strTok_.nextToken().c_str() );
}

/**
	pow(2,-3) == pow(1/2, 3 )
*/
double OptionsAdapter::powSigned_( double base, double exponent )
{
	double tmpBase = base;
	double tmpExp = exponent;

	if( exponent < 0 ){
		tmpBase = 1.0/base;
		tmpExp = exponent * -1;
	}
	
	return pow( tmpBase, tmpExp );

}

double OptionsAdapter::logSigned_( double base, double exponent )
{
	// double log10( double num );
	// The log10() function returns the base 10 logarithm for num.
	//There's a domain error if num is negative, a range error if num is zero.
	//	logb2(x) = logb10(x)/logb10(2)

	//special case 1
	if( exponent == 0.0 )//2^0 == 1
	{
		return 1.0;
	}

	double tempResult;
	double tmpExp = exponent;

	//special case 2
	//logb2(-3) = 1/(2^3)
	//if( exponent < 1.0 )
	//{
	//	tmpExp = exponent * -1;
	//	tempResult = 1.0 / pow( base, tmpExp );
	//	return tempResult;
	//}
	
	//normal case
	tempResult = log( tmpExp )/log(base);

	return tempResult;

//
//	double tmpBase = base;
//	double tmpExp = exponent;
//
//	if( exponent < 1.0 ){
//		tmpExp = exponent * -1;
//	}
//	
//	return pow( tmpBase, tmpExp );
//
//	log2 3 = 8;
//	log of 8 =3;
//	log10(x)
//base 10 logarithm log10(x), x>0.
}

void OptionsAdapter::initSvmParam( std::string str )
{

//	StringTokenizer* strTok = new StringTokenizer( str, " ");
	strTok_.setString( str, " " );
	
	
	options_.SetSVMType( static_cast<Options::ESVMType>    (atoi( strTok_.nextToken().c_str() ) ) );
	//options_.SetKernel( static_cast<Options::EKernelType>(2) );//2 == RBF
	//string s = strTok_.nextToken();
	//int kernel = atoi( s.c_str() );
	options_.SetKernel( static_cast<Options::EKernelType>    (atoi( strTok_.nextToken().c_str() ) ) );
	//setCost(  atof( strTok_.nextToken().c_str() ) );//C aka penalty parameter
	//setGamma( atof( strTok_.nextToken().c_str() ) );//g, aka bandwidth
	options_.SetDegree( atof( strTok_.nextToken().c_str() ) );
	options_.SetCoefficiant( atof( strTok_.nextToken().c_str() ) );

	/* these are for training only */
	//cache_size	= 40;//hard coded in phasemachine Options. remember to make this variable later if code is slow.
	options_.SetTermCriterion(atof( strTok_.nextToken().c_str() ) ); //aka eps/Stopping Criteria	
	//p				= 0.0;
	//shrinking		= 1;
	//nr_weight		= 0;
	//weight_label	= NULL;
	//weight			= NULL;
	//probability		= 0;

//	delete strTok;

}


////ALL 
//
//std::string  OptionsAdapter::getString( string key ) const
//{
////	 The find() function returns an iterator to key, or an iterator to the end of the map if key is not found.
//
//	//if( ssMap.find(key) != ssMap.end() )
//	//{
//		//cout << ssMap.find(key)->second << endl;
//		return ssMap.find(key)->second ;
//	//}
//
//	//return "";
//}
//
//double OptionsAdapter::getDouble( string key ) const
//{
////	 The find() function returns an iterator to key, or an iterator to the end of the map if key is not found.
//
//	//if( sdMap.find(key) != sdMap.end() )
//	//{
//		//cout << sdMap.find(key)->second << endl;
//		return sdMap.find(key)->second ;
//	//}
//	//
//	//return  ;
//}
//
//double OptionsAdapter::getInt( string key ) const
//{
////	 The find() function returns an iterator to key, or an iterator to the end of the map if key is not found.
//
//	//if( sdMap.find(key) != sdMap.end() )
//	//{
//		//cout << sdMap.find(key)->second << endl;
//		return siMap.find(key)->second ;
//	//}
//	//
//	//return  ;
//}
//
//void OptionsAdapter::setString( string key, std::string value )
//{
//	//cout << "calling set string" << endl;
//	ssMap[key] = value ;
//}
//
//void OptionsAdapter::setInt( string key, int value )
//{
//	siMap[key] = value ;
//}
//
//void OptionsAdapter::setDouble( string key, double value )
//{
//	//cout << "calling set double" << endl;
//	sdMap[key] = value ;
//}


//LIBSVM configuration
void OptionsAdapter::getSVMParam( struct svm_parameter& param )
{
	//struct svm_paramater& s (param);
	//struct svm_parameter &svmParamPtr;
	options_.GetParam( param );
}


//Instruction interface
std::vector<double> OptionsAdapter::getThresholds() const
{
	return instr_.getThresholds();
}

std::string OptionsAdapter::getDrug() const
{
	return instr_.getDrug();
}


std::string OptionsAdapter::getOrigVirusSeq() const
{
	return instr_.getOrigVirusSeq();
}

std::string OptionsAdapter::getSusceptibilityDataFileName() const
{
	return instr_.getDataSet();
}

//returns internal Options class
const Options& OptionsAdapter::getOptionsClass()
{
	return options_;
}

//double OptionsAdapter::costLog2()
//{
//	return options_.GetCost();
//}
//
//double OptionsAdapter::gammaLog2()
//{
//	return options_.GetGamma();
//}

double OptionsAdapter::cost( )
{
	double log2Value = options_.GetCost();
	return logSigned_( 2.0, log2Value );
}

void OptionsAdapter::setCost( double i_value )
{
	double trueValue = powSigned_( 2.0, i_value );
	options_.SetCost( trueValue );
}

double OptionsAdapter::gamma( )
{
	double log2Value = options_.GetGamma();
	return logSigned_( 2.0, log2Value );
}

void OptionsAdapter::setGamma( double i_value )
{
	double trueValue = powSigned_( 2.0, i_value );
	options_.SetGamma( trueValue );
}

int OptionsAdapter::numSamplesToUse() const
{
	return numSamplesToUse_;
}

void OptionsAdapter::numSamplesToUse( int _numSamplesToUse )
{
	this->numSamplesToUse_ = _numSamplesToUse;
}

double OptionsAdapter::fractionSamplesToTest()
{
	return fractionSamplesToTest_;
}
OptionsAdapter::enumSampleType OptionsAdapter::sampleType()
{
	return sampleType_;
}	

double OptionsAdapter::costLow() const
{
	return costLow_;
}

double OptionsAdapter::costHigh() const
{
	return costHigh_;
}

double OptionsAdapter::costIncrement() const
{
	return costIncrement_;
}

double OptionsAdapter::gammaLow() const
{
	return gammaLow_;
}

double OptionsAdapter::gammaHigh() const
{
	return gammaHigh_;
}

double OptionsAdapter::gammaIncrement() const
{
	return gammaIncrement_;
}

double OptionsAdapter::libraryFraction() const
{	
	return libraryFraction_;
}

//prediction
string OptionsAdapter::predicteeSeqsFileName() const
{
	return predicteeSeqsFileName_;
}

void OptionsAdapter::thesholdsLevel( string i_level )
{
	thresholdsLevel_ = i_level;
}

string OptionsAdapter::thresholdsLevel() const
{
	return thresholdsLevel_;
}

//setters needed by hivm prediction
void OptionsAdapter::drug( string i_drug )
{
	instr_.setDrug( i_drug );
}

void OptionsAdapter::dataSet( string i_dataSet_filename )
{
	instr_.setDataSet( i_dataSet_filename );
}

void OptionsAdapter::threshold( double i_threshold )
{
	instr_.resetThreshold( i_threshold );
}

void OptionsAdapter::origVirusSeq( string i_filename )
{
	instr_.setOrigVirusSeq( i_filename );
}

void OptionsAdapter::origVirusSeqFileName( string i_filename )
{
	instr_.setOrigVirusSeqFileName( i_filename );
}


string OptionsAdapter::enzyme()
{
	return enzyme_;
}

double OptionsAdapter::cmdLineCost()
{
	return cmdLineCost_;
}

double OptionsAdapter::cmdLineGamma()
{
	return cmdLineGamma_;
}