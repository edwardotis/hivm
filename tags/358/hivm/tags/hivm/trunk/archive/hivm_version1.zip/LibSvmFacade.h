#ifndef LIBSVMFACADE_H
#define LIBSVMFACADE_H

#include "svm.h"//LibSvm

#ifdef __cplusplus
	extern "C" {
#endif

/**
@purpose Define a clean, simpler interface to LibSvm functions needed by hivm
*/



//class LibSvmFacade
//{
//public:
//	
//	//default constructor
//	LibSvmFacade();
//
//	//default destructor
//	virtual ~LibSvmFacade();

	/**************************************************************
	// TRAIN
	//  This function constructs and returns an SVM model according to
    //  the given training data and parameters.
	//
	*/
	struct svm_model *svm_train( const struct svm_problem *prob, const struct svm_parameter *param );

	
	/**************************************************************
	CrossValidate
	This function conducts cross validation. Data are separated to
    nr_fold folds. Under given parameters, sequentially each fold is
    validated using the model from training the remaining. Predicted
    labels in the validation process are stored in the array called
    target.
	*/
	void svm_cross_validation(const struct svm_problem *prob, const struct svm_parameter *param, int nr_fold, double *target);

	/**
	Predict aka Classify
    This function does classification or regression on a test vector x
    given a model.

    For a classification model, the predicted class for x is returned.
    For an one-class model, +1 or -1 is
    returned.
	*/
	double svm_predict(const struct svm_model *model, const struct svm_node *x);

	/**
	//Check for valid parameter values
	//@pre  Run function before calling svm_train()
	//@post Returns NULL no problem, else returns error message

    //This function checks whether the parameters are within the feasible
    //range of the problem. This function should be called before calling
    //svm_train(). It returns NULL if the parameters are feasible, 
    //otherwise an error message is returned. 
	*/
	const char *svm_check_parameter(const struct svm_problem *prob, const struct svm_parameter *param);


	/**
    @purpose This function checks whether the model contains required
    information to do probability estimates. If so, it returns
    +1. Otherwise, 0 is returned. This function should be called
    before calling svm_get_svr_probability and svm_predict_probability.

	failing condition:
	 ( svm_type==C_SVC || svm_type==NU_SVC) && (probA!=NULL && probB!=NULL)
	*/
	//int svm_check_probability_model(const struct svm_model *model);

	/**
	This function saves a model to a file; returns 0 on success, or -1
    if an error occurs.
	*/
	int svm_save_model(const char *model_file_name, const struct svm_model *model);


	/**
	This function frees the memory used by a model.
	*/
	
	void svm_destroy_model(struct svm_model *model);
	
	/**
	This function frees the memory used by a parameter set.
	*/	
	void svm_destroy_param(struct svm_parameter *param);

//protected:
//
//
//private:
//	
//	//copy constructor
//	LibSvmFacade( const LibSvmFacade& );
//
//	//assignment operator
//	LibSvmFacade& operator= ( const LibSvmFacade& );

//};

#ifdef __cplusplus
}
#endif


#endif
