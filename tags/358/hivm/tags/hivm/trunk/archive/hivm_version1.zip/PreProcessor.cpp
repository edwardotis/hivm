#include "PreProcessor.h"


//PreProcessor::PreProcessor(  OptionsAdapter *newInstr, vector<WorkUnit*> &newWorkUnitVector ){
//	myInstr = newInstr;
//	myWuVector = newWorkUnitVector;
//}

PreProcessor::PreProcessor(  OptionsAdapter& newInstr ):
	myInstr(newInstr)
	//myWuVector(newWorkUnitVector)
{
	//intentionally left blank
	//cout << "Just ran PreProcessor constructor" << endl;
}

	//PreProcessor::PreProcessor():
	//	myInstr(),
	//	myWuVector()
	//{};

PreProcessor::~PreProcessor()
{
	WorkUnit::resetActivePositions();
}

void PreProcessor::preparePerformanceEvalSamples( vector<WorkUnit*>& m_fullSet, 
		vector<WorkUnit*>& o_trainSet, vector<WorkUnit*>& o_testSet, bool isLibrary )
{

	if( isLibrary == true )
	{
		double fraction = 1.0 - myInstr.libraryFraction();//
		makeTrainAndClassifySets_( fraction, m_fullSet, o_trainSet, o_testSet );
	}
	else
	{
		//we already randomized in the PreProcessor
		trimTotalSampleSize( myInstr.numSamplesToUse(), m_fullSet);
		makeTrainAndClassifySets_( myInstr.fractionSamplesToTest(), m_fullSet, o_trainSet, o_testSet );
	}

	//if( isLibrary == true )
	//{
	//	//we already randomized in the PreProcessor
	//	double numSamplesToUseLibrary = myInstr.libraryFraction() * m_fullSet.size();
	//	if( numSamplesToUseLibrary < 1 )
	//	{
	//		trimTotalSampleSize( 1, m_fullSet);
	//	}
	//	else
	//	{
	//		trimTotalSampleSize( numSamplesToUseLibrary, m_fullSet);
	//	}

	//	double fraction = 1.0 - myInstr.libraryFraction();//
	//	makeTrainAndClassifySets_( fraction, m_fullSet, o_trainSet, o_testSet );
	//}
	//else
	//{
	//	//we already randomized in the PreProcessor
	//	trimTotalSampleSize( myInstr.numSamplesToUse(), m_fullSet);
	//	makeTrainAndClassifySets_( myInstr.fractionSamplesToTest(), m_fullSet, o_trainSet, o_testSet );
	//}
}


void PreProcessor::trimTotalSampleSize( int numSamples, vector<WorkUnit*>& m_sampleSet )
{

#ifdef DEBUG
//	DebugHelper::debug( m_sampleSet, false );
#endif
	if( numSamples >= m_sampleSet.size() )
	{
		//nothing to do
		return;
	}

	vector<WorkUnit*>::iterator it = m_sampleSet.begin();

	//iterator is set to point to spot immediately following
	//the numSamplesth index
	it += numSamples;

	//do erase and clear call the WU destructor? nope, erase doesn't
	
	//this loop actually deletes the WorkUnits
	for( it; it != m_sampleSet.end(); it++)
	{
		delete(*it);
	}

	//int size;
	//size =	m_sampleSet.size();

	//now clear the ptr's to WorkUnit out of the vector
	//erase works BETWEEN the starting iterator and ending iterator
	if( it != m_sampleSet.begin() )
	{
		m_sampleSet.erase( it-1, m_sampleSet.end() );
	}

	//after deleting and erasing, you still have to resize the vector.
	m_sampleSet.resize( numSamples );
	
	//size =	m_sampleSet.size(  );

	//DebugHelper::debug( m_sampleSet, false );

}

void PreProcessor::makeTrainAndClassifySets_(
	double fractionToTest,
	vector<WorkUnit*>& m_fullSet,
	vector<WorkUnit*>& o_trainSet,
	vector<WorkUnit*>& o_testSet
	)
{
	//DebugHelper::debug( m_fullSet, true );

	double testSizeDbl = fractionToTest * m_fullSet.size();
	int    testSizeInt = static_cast<int>(testSizeDbl);
	//deal with rounding here
	double fraction = testSizeDbl - (double)testSizeInt;
	if( fraction >= 0.5 )
	{
		testSizeInt++;
	}

	int trainSize = m_fullSet.size() - testSizeInt;

	//resize if set sizes are off by one
	if( trainSize + testSizeInt != m_fullSet.size() )
	{
		cout << "in PreProcessor::makeTrainAndClassifySets_" << endl;
		cout << "trainSize + testSizeInt = " << trainSize + testSizeInt << endl;
		cout << "i_fullSet.size() = " << m_fullSet.size() << endl;
	}

	vector<WorkUnit*>::iterator fullSetIt = m_fullSet.begin();
	
	//DebugHelper::debug( m_fullSet, true );

	//assign the training set it's correct chunk full set
	//0th index to trainSize-1 index
	fullSetIt += trainSize;
	o_trainSet.assign( m_fullSet.begin(), fullSetIt );
	WorkUnit::initActivePositions( o_trainSet.size() );

	//DebugHelper::debug( o_trainSet, true );

	//assign the test set it's correct chunk of full set
	fullSetIt;
	o_testSet.assign( fullSetIt, m_fullSet.end() );
	//WorkUnit::initActivePositions( o_testSet.size() );

	//DebugHelper::debug( o_testSet, true );

	//clear the original vector so that it cannot damage
	//the WorkUnit pointers that have been newly 
	//assigned to the training and test vectors

	//do erase and clear call the WU destructor? nope, erase doesn't
	//I think clear is fine here b/c we just want to delete this vector's
	//set of pointers. We don't actually want to delete what the pointers point to
	m_fullSet.clear();
}

void PreProcessor::makeTrainAndClassifySets_(
	double fractionToTest,
	vector<string>& m_fullSet,
	vector<string>& o_trainSet,
	vector<string>& o_testSet
	)
{
	//DebugHelper::debug( m_fullSet, true );

	double testSizeDbl = fractionToTest * m_fullSet.size();
	int    testSizeInt = static_cast<int>(testSizeDbl);
	//deal with rounding here
	double fraction = testSizeDbl - (double)testSizeInt;
	if( fraction >= 0.5 )
	{
		testSizeInt++;
	}

	int trainSize = m_fullSet.size() - testSizeInt;

	//resize if set sizes are off by one
	if( trainSize + testSizeInt != m_fullSet.size() )
	{
		cout << "in PreProcessor::makeTrainAndClassifySets_ strings" << endl;
		cout << "trainSize + testSizeInt = " << trainSize + testSizeInt << endl;
		cout << "i_fullSet.size() = " << m_fullSet.size() << endl;
	}

	vector<string>::iterator fullSetIt = m_fullSet.begin();
	
	//DebugHelper::debug( m_fullSet, true );

	//assign the training set it's correct chunk full set
	//0th index to trainSize-1 index
	fullSetIt += trainSize;
	o_trainSet.assign( m_fullSet.begin(), fullSetIt );
	//WorkUnit::initActivePositions( o_trainSet.size() );

	//DebugHelper::debug( o_trainSet, true );

	//assign the test set it's correct chunk of full set
	fullSetIt;
	o_testSet.assign( fullSetIt, m_fullSet.end() );
	//WorkUnit::initActivePositions( o_testSet.size() );

	//DebugHelper::debug( o_testSet, true );

	//clear the original vector so that it cannot damage
	//the WorkUnit pointers that have been newly 
	//assigned to the training and test vectors

	//do erase and clear call the WU destructor? nope, erase doesn't
	//I think clear is fine here b/c we just want to delete this vector's
	//set of pointers. We don't actually want to delete what the pointers point to
	m_fullSet.clear();
}

void PreProcessor::randomize( vector<WorkUnit*>& m_wus )
{
	random_shuffle( m_wus.begin(), m_wus.end() ); /* shuffle elements */
}



void PreProcessor::parse( vector<WorkUnit*>& myWuVector, bool isLibrary  )
{
//	DebugHelper::debug( myWuVector, false );
	//WorkUnit::initActivePositions( myWuVector.size() );
}
void PreProcessor::parse(){};

void PreProcessor::printToFile( vector<WorkUnit*>& myWuVector ){};

//OptionsAdapter* PreProcessor::getOptionsAdapter(  ){
//	return &myInstr;
//}

//void PreProcessor::setOptionsAdapter( OptionsAdapter& newInstr ){
//		myInstr = newInstr;
//}

//void PreProcessor::setWuVector( vector<WorkUnit*>& newWuV ){
//		myWuVector = newWuV;
//}

//vector<WorkUnit*>& PreProcessor::getWuVector(){
//		return myWuVector;
//}

//string PreProcessor::getDrug(){
//	return myInstr->getDrug();	
//}

int PreProcessor::getCategory( double drugValue ){
	if( drugValue < 0 ){
		return -1;
	}

	//categories start at 0. ie. 2 categories means: cat0 and cat1
	int counter = 0;
	double theshHold = -1;
	vector<double> tempV = myInstr.getThresholds();

	vector<double>::iterator doubleIterator;
	doubleIterator = tempV.begin();
//	doubleIterator = (myInstr->getThresholdsVector().begin());
	//cout << "\n *(myInstr->getThresholdsVector().begin()) " << *(myInstr->getThresholdsVector().begin());
	//cout << "\n (*doubleIterator) " << (*doubleIterator);

	while( doubleIterator != tempV.end() ){
		theshHold = (*doubleIterator);
		if( drugValue < theshHold )
		{
			return counter;
		}
		counter++;
		doubleIterator++;
	}

	return counter;

}


//WorkUnit* PreProcessor::getLastWorkUnit(  ){
//	return myWuVector.back();
//}

bool PreProcessor::getFile( string str )
{

	if( inFile.is_open() ){
		inFile.close();
	}
	inFile.clear();

  inFile.open( str.c_str(), fstream::in );
  if (inFile.fail()) {
      cerr << "unable to open file " << str << " for reading" << endl;
      inFile.close();
	  ///@todo Change this to throw an exception
	  std::cout << "Press 'x' and then Enter to Exit program" << endl;
	  char c;
	  cin >> c;
      exit(1);
//	  return false;

	}else{
		
	  return true;
	}
}

void PreProcessor::loadFile( string fileName, vector<string> &myV )
{
	
	//reset tempVector
	myV.resize(0,"Bad Data");
	//myV.clear();
	
	this->getFile( fileName );
	
	string myStr;

	if( inFile.is_open() ){
		while( std::getline( inFile, myStr ) ){
			myV.push_back( myStr );
		}
		inFile.clear();
	}else{
		//cerr << "cannot open file" << endl;
	} 
	
}

/*void PreProcessor::getSeq( string& seqRef ){
	vector<string>::iterator stringIterator;
	
	seqRef.clear();
	
	for( stringIterator = seqVector.begin()+1; stringIterator != seqVector.end(); stringIterator++ ){
		seqRef.append( *stringIterator );
	}
}	*/	

vector<string>& PreProcessor::getDataSetVector(){
	return dataSetVector;
}







