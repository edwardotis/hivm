/**
@purpose Hold results of SVM tests and provide statistics based on them.
*/

#ifndef RESULT_H	
#define RESULT_H

#include "std_include.h"

class Result{

public:
	
	Result();
	Result( double gamma, double cost, double tpr, double fpr,
		double tnr, double fnr  );
	~Result();

	/**
	binary function predicate:
	@purpose returns whether a Reslt is less than another Result
	@note a Result is less than another Result if the fpr() value is less
	*/
	static bool Result::resultSortCriterion (const Result* r1, const  Result* r2);
		
	double gamma() const;
	void   gamma( double );

	double cost() const;
	void cost( double);

	double truePositiveRate() const;
	void truePositiveRate( double);

	double falsePositiveRate() const;
	void falsePositiveRate( double);

	double trueNegativeRate() const;
	void trueNegativeRate( double);

	double falseNegativeRate() const;
	void falseNegativeRate( double);

protected:

	double gamma_;
	double cost_;

	double truePositiveRate_;
	double falsePositiveRate_;

	double trueNegativeRate_;
	double falseNegativeRate_;


private:

    //copy constructor
	Result( const Result& );
	
	//assignment operator
	Result& operator= ( const Result& );

};
#endif
