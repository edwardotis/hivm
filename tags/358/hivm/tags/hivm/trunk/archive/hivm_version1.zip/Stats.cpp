#include "Stats.h"


Stats::Stats( const OptionsAdapter& oa ):
_optAdptr( oa )
{
	_cost = DBL_MAX;
	_gamma = DBL_MAX;

	_init( _optAdptr.getNumOfCategories() );
}

//Stats::Stats( )
//{
//	_cost = DBL_MAX;
//	_gamma = DBL_MAX;
//}

void Stats::_init( int _numOfClasses )
{

	//This is a 2D vector aka matrix
	
	//Give the outer predictedClass vector the correct number
	//of vectors to hold the trueClass values
	vector<int> intVector;
	_predictedClass.assign( _numOfClasses, intVector );

	//for each predicted class:
	//a. give it the correct number of true classes
	//b. set each true class value to 0
	for( int i=0; i<_numOfClasses; i++ )
	{
		_predictedClass.at(i).assign( _numOfClasses, 0 );
	}
}

Stats::~Stats()
{
	vector<Result*>::iterator it;
	for( it = dataPointSet_.begin(); it!=dataPointSet_.end(); it++)
	{
		delete *it;
	}

}

//copy constructor
//Stats::Stats( const Stats &rhs ) :
//	_gamma( rhs._gamma ),
//	_cost( rhs._cost ),
//	_classes( rhs._classes )
//{
//}

//assignment operator
//rhs = right hand side
Stats& Stats::operator= ( const Stats& rhs )
{
	if (&rhs != this )
	{
		_gamma = rhs._gamma;
		_cost =  rhs._cost;
		//_classes = rhs._classes;
		_predictedClass = rhs._predictedClass;

		//@todo - Will this have unintended side effects!?
		//dataPointSet_ = rhs.dataPointSet_;		

	}
	
	return *this;
}

//void Stats::_destroyClasses()
//{
//	//vector<result>::iterator it = _classes.begin();
//
//	//while( it != _classes.end() )
//	//{
//	//	delete (*it);
//	//	it++;
//	//}
//}



//{
	//cout << endl;
	//vector< vector<int> >::const_iterator it;
	//int i = 0;
	//for( it = _predictedClass.begin(); it != _predictedClass.end();it++)
	//{
	//	cout     <<"Predicted Class | True Class" << endl;;
	//	vector<int>::const_iterator jt;
	//	for( jt = (*it).begin(); jt != (*it).end(); jt++)
	//	{
	//		cout << "\t\t" << i << "   |    " << (*jt) << endl;
	//	}

	//	i++;
	//}
	
//}

/**
	All stats work for only 2 class values for now
	//class 0 is always the LEAST resistant class
	
	//class 0 not resistant/sensitive
	//class 1 resistant / not sensitive

We are basing everything on sensitivity to the drugs:
no resistance == positive test result for sensitivity to a drug
resistance    == negative test result for sensitivity to a drug

----
From Ljubomir
									     ACTUAL CLASS
								 sensitive          resistant
					             class 1            class 2 

PREDICTED CLASS:
class 1                            TP                 FP       
class 2                            FN                 TN  


n1 is number of samples in class 1, n2 is number of samples in class
2, N is n1+n2 (total number of samples).

TP = actual class 0, and predicted class 0 = sensitive hit
FN = actual class 0, but predicted class 1 = sensitive miss
FP = actual class 1, but predicted class 0 = resistant miss
TN = actual class 1, but predicted class 1 = resistant hit

sensitivity = TP/n1 =  TP/( TP + FN ) = True Positive rate
specificity = TN/n2 =  TN/( FP + TN ) = True negative rate

ppv = TP/(TP+FP)
npv = TN/(TN+FN)

error rate = (FP+FN)/N

*BEST*
ROC curve =  Want the area under the ROC curve to be close to 1.0
.5 is the worst it can be.
True Positive Rate over False Positive Rate ==
True Positive Rate over (1-True negative rate)

An expert should decide how great the cost an HIV drug sensitivity false positive
really is. It may go down to case by case. How many options for sensitive drugs
does a patient have? If not many, then maybe we reduce the ROC threshold.

*/

/**
  check to see if a stat has been used yet
*/
bool Stats::isInitialized()
{
	if( _gamma == DBL_MAX || _cost == DBL_MAX )
	{
		return false;
	}

	return true;
}

//ppv = TP/(TP+FP)
double Stats::positivePredictiveValue()
{
	if( !isInitialized() )
	{
		return -1.0;
	}

	//double sensitiveHits = static_cast<double>( _classes.at(0).hits );
	//double resistantMisses = static_cast<double>( _classes.at(1).misses );
	//
	//if( sensitiveHits + resistantMisses == 0 )
	//{
	//	//cout << "N/A - Positive Predictive Value is UNDEFINED for this experiment." << endl;
	//	return -1.0;
	//	//cout << "Sorry, Stats::positivePredictiveValue() had a divide by zero error" << endl;
	//	//cout << "Exiting program";
	//	//exit(1);
	//}

	//double result = sensitiveHits/( sensitiveHits + resistantMisses );

	//ppv = TP/(TP+FP)

	//predicted sensitive, and truly sensitive
	double TP = _predictedClass.at(0).at(0);

	//predicted sensitive, but truly resistant
	double FP = _predictedClass.at(0).at(1);

	if( ( TP+FP ) == 0 )
	{
		cout << "Stats::positivePredictiveValue() not defined yet. Returning -1." << endl;	
		return -1.0;
		//cout << "Sorry, Stats::positivePredictiveValue() had a divide by zero error" << endl;
		//cout << "Exiting program";
		//exit(1);
	}

	double result =  TP/(TP+FP);

	return result*100.0;

}

//npv = TN/(TN+FN)
double Stats::negativePredictiveValue()
{
	if( !isInitialized() )
	{
		return -1.0;
	}

//	double resistantHits = static_cast<double>( _classes.at(1).hits );
//	double sensitiveMisses = static_cast<double>( _classes.at(0).misses );
//		if( (TN+FN) == 0 )
//	{
//		//cout << "N/A - Negative Predictive Value is UNDEFINED for this experiment." << endl;
//		return -1.0;
///*		cout << "Sorry, Stats::negativePredictiveValue() had a divide by zero error" << endl;
//		cout << "Exiting program";
//		exit(1)*/;
//	}
//
//	double result = resistantHits/( resistantHits + sensitiveMisses );

	//npv = TN/(TN+FN)

	//predicted resistant and truly resistant
	double TN = _predictedClass.at(1).at(1);

	//predicted resistant, but truly sensitive
	double FN = _predictedClass.at(1).at(0);

	if( (TN+FN) == 0 )
	{
		//cout << "N/A - Negative Predictive Value is UNDEFINED for this experiment." << endl;
		//cout << "Stats::negativePredictiveValue() not defined yet. Returning -1." << endl;	
		return -1.0;
/*		cout << "Sorry, Stats::negativePredictiveValue() had a divide by zero error" << endl;
		cout << "Exiting program";
		exit(1)*/;
	}

	double result = TN/(TN+FN);

	return result*100.0;

}


double Stats::tprFprDifference()
{
	double result;

	if( falsePositiveRate() == -1 || 
		sensitivity() == -1 )
	{
		result = 0.0;
	}
	else
	{
		result = sensitivity() - falsePositiveRate();
	}
	
	return result;
}


double Stats::tprOverFprRatio()
{
	double result;

	if( falsePositiveRate() == -1 || 
		sensitivity() == -1 )
	{
		result = 0.0;
	}
	else if( falsePositiveRate() == 0.0 )
	{
		//cout << "tprOverFprRatio had falsePositiveRate of 0" << endl;
		result = sensitivity();
	}
	else
	{
		result = sensitivity()/falsePositiveRate();
	}
	
	return result;
}

double Stats::falsePositiveRate()
{
	if( specificity() == -1 )
	{
		return -1.0;
	}

	return 100.0 - specificity();
}	


double Stats::truePositiveRate()
{
	return this->sensitivity();
}

double Stats::trueNegativeRate()
{
	return this->specificity();
}

double Stats::falseNegativeRate()
{
	if( sensitivity() == -1 )
	{
		return -1.0;
	}

	return 100.0 - sensitivity();
}

double Stats::sensitivity()
{
	if( !isInitialized() )
	{
		return -1.0;
	}

	//**WRONG 
	//sensitivity = non-resistant hits/(non-resistant hits + resistant misses)
	//sensitivity = sensitive hits/(sensitive hits + non-sensitive misses)
	//END WRONG

	/**
	BEGIN RIGHT
	//sensitivity = non-resistant hits/(non-resistant hits + resistant misses)
	//sensitivity = sensitive hits/(sensitive hits + sensitive misses)
	  sensitivity = TP/n1 =  TP/( TP + FN )
	total samples of class 0 == class 0 hits and class 1 misses. 
	class 0 hit ==  senstive drug predicted sensitive
	class 1 miss == sensivite drug predicted resistant
	*/
	//if( !isinitialized() )
	//{
	//	return -1.0;
	//}

	//double sensitiveHits = static_cast<double>( _classes.at(0).hits );
	//double sensitiveMisses = static_cast<double>( _classes.at(0).misses );
	//
	////cout << "_classes.at(0).hits " << _classes.at(0).hits << endl;
	////cout << "_classes.at(1).misses " << _classes.at(1).misses << endl;

	//if( sensitiveHits + sensitiveMisses == 0 )
	//{
	//	cout << "Sorry, Stats::sensitivity() had a divide by zero error" << endl;
	//	cout << "Exiting program";
	//	exit(1);
	//}

	//double result = sensitiveHits/( sensitiveHits + sensitiveMisses );

	//sensitivity = TP/n1 =  TP/( TP + FN )

	//predicted sensitive and truly sensitive
	double TP = _predictedClass.at(0).at(0);

	//predicted resistant, but truly sensitive
	double FN = _predictedClass.at(1).at(0);

	if( (TP + FN) == 0 )
	{
		cout << "\nStats::sensitivity() not defined yet. Returning -1." << endl;
		return -1.0;
		//cout << "Sorry, Stats::sensitivity() had a divide by zero error" << endl;
		//cout << "Please press 'x' and Enter to exit program." << endl;
		//char c;
		//cin >> c;
		//cout << "Exiting program";
		//exit(1);
	}

	double result = TP/( TP + FN );

	return result*100.0;

}

double Stats::specificity()
{
	/**
	BEGIN RIGHT
	//specificity = resistant hits/(resistant hits + non-resistant misses)
	//specificity = non-sensitive hits/(non-sensitive hits + sensitive misses)
	total samples of class 0 == class 0 hits and class 1 misses. 
	class 0 hit ==  senstive drug predicted sensitive
	class 1 miss == sensivite drug predicted resistant
	*/

	if( !isInitialized() )
	{
		return -1.0;
	}

	//double resistantHits = static_cast<double>( _classes.at(1).hits );
	//double resistantMisses = static_cast<double>( _classes.at(1).misses );
	//
	//if( resistantHits + resistantMisses == 0 )
	//{
	//	cout << "Sorry, Stats::specificity() had a divide by zero error" << endl;
	//	cout << "Exiting program";
	//	exit(1);
	//}

	//double result = resistantHits/( resistantHits + resistantMisses );

	//specificity = TN/n2 =  TN/( FP + TN )

	//predicted resistant and truly resistant
	double TN = _predictedClass.at(1).at(1);

	//predicted sensitive, but truly resistant
	double FP = _predictedClass.at(0).at(1);

	if( (TN + FP) == 0 )
	{
		cout << "Stats::specificity() not defined yet. Returning -1." << endl;
		return -1.0;
		//cout << "Sorry, Stats::specificity() had a divide by zero error" << endl;
		//cout << "Please press 'x' and Enter to exit program." << endl;
		//char c;
		//cin >> c;
		//cout << "Exiting program";
		//exit(1);
	}

	double result = TN/( FP + TN );

	return result*100.0;
}


double Stats::errorRate()
{

	if( !isInitialized() )
	{
		return -1.0;
	}

	////FP = actual class 1, but predicted class 0 = resistant miss
	//double resistantMisses = static_cast<double>( _classes.at(1).misses );
	//
	////FN = actual class 0, but predicted class 1 = sensitive miss
	//double sensitiveMisses = static_cast<double>( _classes.at(0).misses );	
	//
	//double totalSamples = _classes.at(0).misses + _classes.at(0).hits + _classes.at(1).misses + _classes.at(1).hits;

	//if( totalSamples == 0 )
	//{
	//	cout << "Sorry, Stats::errorRate() had a divide by zero error" << endl;
	//	cout << "Exiting program";
	//	exit(1);
	//}

	//double result = ( resistantMisses + sensitiveMisses ) / totalSamples;
	//
	//error rate = (FP+FN)/N
	
	//predicted sensitive, but truly resistant
	double FP = _predictedClass.at(0).at(1);

	//predicted resistant, but truly sensitive
	double FN = _predictedClass.at(1).at(0);

	//total of samples
	double N = _predictedClass.at(0).at(0) + _predictedClass.at(0).at(1) + _predictedClass.at(1).at(0) + _predictedClass.at(1).at(1);

	if( N == 0 )
	{
		cout << "Stats::errorRate() not defined yet. Returning 200%" << endl;
		return 2.0;
		//cout << "Sorry, Stats::errorRate() had a divide by zero error" << endl;
		//cout << "Please press 'x' and Enter to exit program." << endl;
		//char c;
		//cin >> c;
		//cout << "Exiting program";
		//exit(1);
	}

	double result = ( FP + FN )/N;

	return result*100.0;
}	

void Stats::print( stringstream &m_sstream )
{
	print_( 1, m_sstream );
}


void Stats::print()
{
	stringstream _sstream;
	print_( 0, _sstream );
}

void Stats::print_( int destination, stringstream& m_sstream )
{

	//for(int i=0; i<_classes.size();i++)
	//{
	//	cout << endl;
	//	cout << "Class " << i << endl;
	//	cout << "hits: " << _classes[i].hits << endl;
	//	cout << "misses: " << _classes[i].misses << endl;
	//	cout << endl;
	//}


	m_sstream << "A positive result infers drug sensitivity, aka non-resistance." << endl;

	//tpr - fpr
	if( tprFprDifference() < 0.0 )
	{
		m_sstream << "bestTprFprDifference_: Undefined" << endl;
	}
	else
	{
		m_sstream << "TPR Less FPR: "  << tprFprDifference() << endl;
	}

	//tpr/fpr
	if( tprOverFprRatio() < 0.0 )
	{
		m_sstream << "tprOverFprRatio: Undefined" << endl;
	}
	else
	{
		m_sstream << "TPR over FPR Ratio: "  << tprOverFprRatio() << endl;
	}

	//tpr
	if( sensitivity() < 0.0 )
	{
		m_sstream << "True Positive Rate: Undefined" << endl;
	}
	else
	{
		m_sstream << "True Positive Rate: "  << sensitivity() << "%" << endl;
	}

	//fpr
	if( falsePositiveRate() < 0.0 )
	{
		m_sstream << "False Positive Rate: Undefined" << endl;
	}
	else
	{
		m_sstream << "False Positive Rate: "  << falsePositiveRate() << "%" << endl;
	}	
	
	m_sstream << "Specificity: " << specificity() << "%" << endl;

	//error rate
	if( errorRate() > 100.0 )
	{
		m_sstream << "Error Rate: Undefined" << endl;
	}
	else
	{
		m_sstream << "Error Rate: "  << errorRate() << "%" << endl;
	}

	//ppv
	if( positivePredictiveValue() == -1.0 )
	{
		m_sstream << "Positive Predictive Value: Undefined" << endl;
	}
	else
	{
		m_sstream << "Positive Predictive Value: "  << positivePredictiveValue() << "%" << endl;
	}

	//npv
	if( negativePredictiveValue() == -1.0 )
	{
		m_sstream << "Negative Predictive Value: Undefined" << endl;
	}
	else
	{
		m_sstream << "Negative Predictive Value: "  << negativePredictiveValue() << "%" << endl;
	}
	m_sstream << "Gamma: " << gamma() << endl;
	m_sstream << "Cost: " << cost() << endl;
	m_sstream << endl;

	if( destination == 0 )
	{
		cout << m_sstream.str();
	}
}


/**
	All stats work for only 2 class values for now
	//class 0 is always the LEAST resistant class
	
	//class 0 not resistant/sensitive
	//class 1 resistant / not sensitive

We are basing everything on sensitivity to the drugs:
no resistance == positive test result for sensitivity to a drug
resistance    == negative test result for sensitivity to a drug

----
From Ljubomir
									ACTUAL CLASS
					             class 1            class 2 

PREDICTED CLASS:
class 1                            TP                 FP       
class 2                            FN                 TN  


n1 is number of samples in class 1, n2 is number of samples in class
2, N is n1+n2 (total number of samples).

TP = actual class 0, and predicted class 0 = sensitive hit
FN = actual class 0, but predicted class 1 = sensitive miss
FP = actual class 1, but predicted class 0 = resistant miss
TN = actual class 1, but predicted class 1 = resistant hit

sensitivity = TP/n1 =  TP/( TP + FN )
specificity = TN/n2 =  TN/( FP + TN )

ppv = TP/(TP+FP)
npv = TN/(TN+FN)

error rate = (FP+FN)/N

*/

void Stats::printClassInfo( stringstream &m_sstream )
{
	printClassInfo_( 1, m_sstream );
}


void Stats::printClassInfo()
{
	stringstream _sstream;
	printClassInfo_( 0, _sstream );
}

void Stats::printClassInfo_( int destination, stringstream &m_sstream )
{
	m_sstream << endl;
	
	vector< vector<int> >::const_iterator it;
	
	int _predictedClassIndex = 0;
	for( it = _predictedClass.begin(); it != _predictedClass.end();it++)
	{

		m_sstream << "Predicted Class | True Class | Hits" << endl;
		
		int _trueClassIndex = 0;
		vector<int>::const_iterator jt;
		
		for( jt = (*it).begin(); jt != (*it).end(); jt++)
		{
			
			_predictedClassIndex;
			_trueClassIndex;

			m_sstream << "\t" << _predictedClassIndex << "       |      " << _trueClassIndex << "     |   " << (*jt)  << endl;
			
			_trueClassIndex++;
		}

		_predictedClassIndex++;
	}


	m_sstream << endl;

	if( destination == 0 )
	{
		cout << m_sstream.str();
	}

		//if( i_destination == 1 )
		//{
		//	//setup for saving to disk if necessary

		//	//make fileName
		//	ostringstream fileNameStream;
		//	fileNameStream << "tempName.txt";

		//	//get filestream to ready to write to disk
		//	ofstream outFile;
		//	if( outFile.is_open() )
		//	{
		//		outFile.close();
		//	}
		//	outFile.flush();
		//	outFile.clear();

		//	//@todo fix fileNameStream
		//	outFile.open( fileNameStream.str().c_str(), ofstream::out );

		//	//write to file system
		//	outFile << outStrStream.rdbuf();
		//	outFile.close();
		//}
}

void Stats::pruneResults_( vector<Result*>& o_dataPointSetPruned )
{
	vector<Result*> tempDataPointSet = dataPointSet_;
	//sort by fpr ascending
	//sort( tempDataPointSet.begin(), tempDataPointSet.end(), Result::resultSortCriterion );

	vector<Result*>::const_iterator it, fprIt;
	Result* bestLocalTpr;
	fprIt = tempDataPointSet.begin();
	bestLocalTpr = *fprIt;

	for(it=tempDataPointSet.begin(); it!=tempDataPointSet.end();it++ )
	{
		//cout << "(*it)->falsePositiveRate() " << (*it)->falsePositiveRate() << endl;
		//cout << "(*it)->truePositiveRate() " << (*it)->truePositiveRate() << endl;
		//cout << "(*fprIt)->falsePositiveRate() " << (*fprIt)->falsePositiveRate() << endl;
		//cout << "(*fprIt)->truePositiveRate() " << (*fprIt)->truePositiveRate() << endl;
		//cout << "bestLocalTpr->falsePositiveRate() " << bestLocalTpr->falsePositiveRate() << endl;
		//cout << "bestLocalTpr->truePositiveRate() " << bestLocalTpr->truePositiveRate() << endl;
		//cout << endl;

		//advance current fpr when group of identical fpr's ends
		if( (*fprIt)->falsePositiveRate() != (*it)->falsePositiveRate() )
		{
			//save Result of the group with the highest tpr
			o_dataPointSetPruned.push_back( bestLocalTpr );

			//advance fprIt to next group
			fprIt = it;

			//reset local tpr for new group
			bestLocalTpr = *fprIt;

		}

		//check for  highest tpr for a group of fpr's
//		if( (*fprIt)->truePositiveRate() > bestLocalTpr->truePositiveRate() )
		if( (*it)->truePositiveRate() > bestLocalTpr->truePositiveRate() )
		{
			bestLocalTpr = *it;
		}

		/**
		We are not catching the last group of fpr's.
		Check for the last datapoint to be a new fpr.
		If so, add it to the pruned data set. 
		*/
		if( it == ( dataPointSet_.end()-1 ) )
		{
			o_dataPointSetPruned.push_back( bestLocalTpr );
		}


	}
}

double Stats::computeAreaUnderROCCurve()
{
	//vector<Result*> tempDataPointSet = dataPointSet_;

	//sort by fpr
	//sort( tempDataPointSet.begin(), tempDataPointSet.end(), Result::resultSortCriterion );
	sort( dataPointSet_.begin(), dataPointSet_.end(), Result::resultSortCriterion );

	double total = 0.0;

	//H2+(B3-B2)*(C3+C2)/2
	vector<Result*>::iterator curIt;
	vector<Result*>::iterator prevIt;
	for(
		curIt=(dataPointSet_.begin()+1), prevIt=(dataPointSet_.begin());
		curIt!=dataPointSet_.end();
		curIt++, prevIt++
		)
	{
		//(B3-B2)
		double x2 = (*curIt)->falsePositiveRate();
		double x1 = (*prevIt)->falsePositiveRate();
		double width = x2 - x1;
		
		//(C3+C2)/2
		double y2 = (*curIt)->truePositiveRate();
		double y1 = (*prevIt)->truePositiveRate();
		double height = ( y2 + y1 ) / 2;

		//H2+(B3-B2)*(C3+C2)/2
		total = total + (width * height);
	}

	//adjust for tpr and fpr being in %, not fraction
	total = total /100;
	return total;
}

void Stats::fillDataPointStream_( vector<Result*> dps, stringstream& o_sstream )
{
	vector<Result*>::const_iterator it;

	for(it=dps.begin(); it!=dps.end();it++ )
	{
		stringstream tempStream;
	
		tempStream << "(" << (*it)->cost() << "," << (*it)->gamma() << ") ";
		tempStream << ( (*it)->falsePositiveRate() /100.0 ) << " ";
		tempStream << ( (*it)->truePositiveRate()/100.0 ) << " ";	
		tempStream << "(" << (*it)->cost() << "," << (*it)->gamma() << ") ";
		tempStream << ( (*it)->falseNegativeRate() /100.0 ) << " ";
		tempStream << ( (*it)->trueNegativeRate()/100.0 ) << " ";	
		tempStream << "\n";

		string tempStr = tempStream.str();
		o_sstream << tempStr.c_str();
	}
}

void Stats::saveDataPoints( bool isPruned )
{

	sort( dataPointSet_.begin(), dataPointSet_.end(), Result::resultSortCriterion );

	stringstream outStream;

	//write header line
	outStream << "#cost & gamma pair, FPR, TPR, cost & gamma pair,  FNR, TNR, AUC=" << computeAreaUnderROCCurve() << "%" << endl;
	
	vector<Result*> _dataPointSetPruned;
	//write all the data points out here
	if( isPruned )
	{
		
		pruneResults_( _dataPointSetPruned );
		fillDataPointStream_( _dataPointSetPruned, outStream );

	}
	else
	{
		fillDataPointStream_( dataPointSet_, outStream);
	}

	
	//prepare file name
	//ex. APV_3.5_460data_points.csv
	vector<double> _thresholds = _optAdptr.getThresholds();
	double _threshold = 0;

	if( !_thresholds.empty() )
	{
		_threshold = _thresholds.front();
	}

	stringstream fileName;
	fileName << _optAdptr.uniqueID();
	fileName << "_" << _optAdptr.getDrug();
	//fileName << "_" << _optAdptr.numSamplesToUse() << "samples";
	if( isPruned )
	{
		saveGnuPlotScript( _dataPointSetPruned );

		//finish writing pruned file name
		fileName << "_" << "dataPointsPruned.csv";
	}
	else
	{
		fileName << "_" << "dataPoints.csv";
	}

	stringstream pathName;
	pathName << _optAdptr.resultsPath();

	IO::writeFile( fileName, outStream, pathName );

}

void Stats::setGnuPlotLabels_( vector<Result*>& i_dps, stringstream& o_sstream )
{
	vector<Result*>::const_iterator it;
	//set label "c,g(-4,7)" at .5,.5
	for(it=i_dps.begin(); it!=i_dps.end();it++ )
	{
		o_sstream << "set label ";
		o_sstream << "'(" << (*it)->cost() << "," << (*it)->gamma() << ")'";
		o_sstream << " at ";
		o_sstream << ( (*it)->falsePositiveRate() /100.0 ) << ", ";
		o_sstream << ( (*it)->truePositiveRate()/100.0 );
		o_sstream << endl;
	}
}

void Stats::saveGnuPlotScript( vector<Result*>& i_dps )
{
	stringstream outStream;

	setGnuPlotLabels_( i_dps, outStream );

	outStream << "set xrange [ 0 : 1 ] noreverse nowriteback" << endl;
	outStream << "set yrange [ 0 : 1.1 ] noreverse nowriteback" << endl;
	outStream << "set xlabel 'False Positive Rate'" << endl;
	outStream << "set ylabel 'True Positive Rate'" << endl;
	outStream << "set title '" << _optAdptr.getDrug() << " ROC Curve.  Area Under the ROC Curve = ";
	outStream << computeAreaUnderROCCurve() << "%' Values are all log2" << endl;
	outStream << "set terminal png" << endl;
	outStream << "set output '" << _optAdptr.uniqueID() << "_" << _optAdptr.getDrug() << "_.png'" << endl;
	outStream << "plot '" << _optAdptr.uniqueID() << "_" << _optAdptr.getDrug() << "_dataPointsPruned.csv'using 2:3 with linespoints" << endl;
	outStream << "#    EOF " << endl;
	
	stringstream pathName;
	pathName << _optAdptr.resultsPath();

	//save gnuplot script
	stringstream fileName;
	if( pathName.str() == "library/" )
	{
		fileName << "lib";
	}
	else
	{
		fileName << _optAdptr.uniqueID();
	}

	fileName << "_" << _optAdptr.getDrug();
	fileName << "_threshold-" << _optAdptr.getThresholds().front();
	fileName << "_gnuplot_script";
	fileName << ".plt";



	IO::writeFile( fileName, outStream, pathName );
}

void Stats::update(  WorkUnit* wu, double predictedCategory )
{
	//i need the thresholds, so I can tell which category it belongs to.
	//how did libsvm do this? 
	// ok, predict returns a list of category predictions. Let's test this in the debugger

	/**
	For the current Predicted class, increment it's TrueCategory class.
	example: sample A was predicted class 0, but sample A is actually class 2
	code: _predictedClass.at( 0 ).at( 2 )++
	*/
	_predictedClass.at( (int)predictedCategory ).at( wu->getCategory() )++;

	//bool isHit;
	//int trueCategory = wu->getCategory();
	//if( trueCategory == (int)predictedCategory  )
	//{
	//	isHit = true;
	//}
	//else//trueCategory != predictedCategory
	//{
	//	isHit = false;
	//}

	//update_( trueCategory, (int)predictedCategory, isHit );
}

void Stats::updateDataPointSet( double gamma, double cost,
		double truePositiveRate, double falsePositiveRate,
		double trueNegativeRate, double falseNegativeRate)
{
	Result *_dataPoint = new Result( gamma, cost, truePositiveRate,
		falsePositiveRate, trueNegativeRate, falseNegativeRate );

	dataPointSet_.push_back( _dataPoint );
}

/**
	//class 0 is always the LEAST resistant class

TP = actual class 0, and predicted class 0 = sensitive hit
FN = actual class 0, but predicted class 1 = sensitive miss
FP = actual class 1, but predicted class 0 = resistant miss
TN = actual class 1, but predicted class 1 = resistant hit

*/
//void Stats::update_( int trueCategory, int predictedCategory, bool isHit )
//{
//	//make sure the vector is big enough to handle the classes
//	//if not automatically resize it.
//	if( trueCategory >= _classes.size()  )
//	{
//		result r;
//		int sizeDifference = (trueCategory+1) - _classes.size();
//		for(int i=0;i<sizeDifference;i++)
//		{
////			r = new result();
//			r.hits = 0;
//			r.misses = 0;
//			_classes.push_back( r );
//		}
//	}
//
//	//now update the result
//	if( isHit == true )
//	{
//		//if trueCategory == 0, TP
//		//if trueCategory == 1, TN
//		_classes.at( trueCategory ).hits++;
//	}
//
//	if( isHit == false)
//	{
//		//if trueCategory == 0, FN
//		//if trueCategory == 1, FP
//		_classes.at( trueCategory ).misses++;
//	}
//}

void Stats::setGamma( double d )
{
	_gamma = d;
}
double Stats::gamma()
{
	return _gamma;
}

void Stats::setCost( double d )
{
	_cost = d;
}
double Stats::cost()
{
	return _cost;
}