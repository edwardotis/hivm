#include "LibSvmAdapter.h"


//@todo can I make these all member objects instead of pointers?
LibSvmAdapter::LibSvmAdapter( OptionsAdapter& oa )
: optionsAdapter_(oa)
 // svm_modelPtr_( new svm_model() ),
 // svm_param_()//,
  //svm_problemPtr_( new svm_problem() )
{
	svm_modelPtr_ = NULL;
	svm_problemPtr_ = NULL;
	//svm_problemPtr_ =  new svm_problem();
	//svm_modelPtr_ = new svm_model();

	//initialize the data member svm_param from Config file
	this->svmParam();

	//init length of problem to 0 (never run a problem of zero length)
//	svm_problemPtr_->l = 0;
}

LibSvmAdapter::~LibSvmAdapter()
{

	freeMemorySvmModel_();
	//if( svm_modelPtr_ != NULL )
	//{
	//	svm_destroy_model( this->svm_modelPtr_ );
	//}

	//freeMemorySvmModel_ depends on svmProblem
	//if( svm_modelPtr_ != NULL )
	//{
	//	freeMemorySvmModel_( );
	//	delete svm_modelPtr_;
	//}

	//DOES THIS CODE CRASH WITH Client -eval or -library?
	//free all the malloc(), calloc() memory!!
	if( svm_problemPtr_ != NULL )
	{
		freeMemorySvmProblem_();
		//delete svm_problemPtr_;
	}
}


bool LibSvmAdapter::predictIsResistant( vector<WorkUnit*>& i_trainSet, WorkUnit* i_predictee )
{	//debug helper
	//DebugHelper::debug( i_trainSet, true );
	//DebugHelper::debug( i_predictee, false );

	cout << endl;
	cout << "Training model for prediction test..." << endl;
	train( i_trainSet );
	cout << "Finished training!" << endl;

	cout << "Running prediction..." << endl;
	cout << endl;

	//DebugHelper::debug( i_testSet, true );
	
	struct svm_node* predicteeNode = makeSvmNodePtr( i_predictee );
	double predValue = predict( svm_modelPtr_, predicteeNode );
	delete predicteeNode;

	const bool resistant = true;
	const bool susceptible = false;

	cout << "Finished prediction test..." << endl;

	if( predValue > optionsAdapter_.getThresholds().front() )
	{
		return resistant;
	}
	else
	{
		return susceptible;
	}
}

void LibSvmAdapter::predictionTest( vector<WorkUnit*>& i_trainSet, WorkUnit* i_testWu, Stats& o_stat, Stats& o_stat2 )
{
	//cout << endl;
	//cout << "Training model for prediction test..." << endl;
	////train the model
	train( i_trainSet );
	//cout << "Finished training!" << endl;

	//cout << "Running prediction test..." << endl;
	//cout << endl;


		struct svm_node* predictee = makeSvmNodePtr( i_testWu );
		double predValue = predict( svm_modelPtr_, predictee );
		o_stat.update( i_testWu, predValue );
		o_stat2.update( i_testWu, predValue );
		delete predictee;

	//free memory used during train()
	freeMemorySvmProblem_();

	//cout << "Finished prediction test..." << endl;
}

void LibSvmAdapter::predictionTest( vector<WorkUnit*>& i_trainSet, WorkUnit* i_testWu, Stats& o_stat )
{
	//cout << endl;
	//cout << "Training model for prediction test..." << endl;
	////train the model
	train( i_trainSet );
	//cout << "Finished training!" << endl;

	//cout << "Running prediction test..." << endl;
	//cout << endl;


		struct svm_node* predictee = makeSvmNodePtr( i_testWu );
		double predValue = predict( svm_modelPtr_, predictee );
		o_stat.update( i_testWu, predValue );
		delete predictee;

	//free memory used during train()
	freeMemorySvmProblem_();

	//cout << "Finished prediction test..." << endl;
}

void LibSvmAdapter::predictionTest( vector<WorkUnit*>& i_trainSet, vector<WorkUnit*>& i_testSet, Stats& o_stat )
{
//	cout << endl;
//	cout << "Training model for prediction test..." << endl;
	//train the model
	train( i_trainSet );
//	cout << "Finished training!" << endl;

//	cout << "Running prediction tests..." << endl;
//	cout << endl;

	//predict with set using leave-one-out against a training model
	vector<WorkUnit*>::const_iterator it;

	//DebugHelper::debug( i_testSet, true );
	
	//cout << "Isolate Name | Predicted Category" << endl;

	for( it = i_testSet.begin(); it != i_testSet.end(); it++ )
	{
		struct svm_node* predictee = makeSvmNodePtr( (*it) );
		double predValue = predict( svm_modelPtr_, predictee );

		//debug
		//cout << endl;
		//cout << (*it)->getIsolateName() << ": ";
		//cout << predValue << endl;

		o_stat.update( (*it), predValue );
		delete predictee;
	}

	//free memory used during train()
	freeMemorySvmProblem_();

	//cout << "Finished prediction test..." << endl;
}

svm_parameter* LibSvmAdapter::svmParam()
{
	
	//optionsAdapter_.getSVMParam( svm_modelPtr_->param );
	optionsAdapter_.getSVMParam( svm_param_ );
	return &svm_param_;

}

void LibSvmAdapter::train( const std::vector< WorkUnit* >&  wus )
{
	//call svm_check_parameter()



	//If svm problem not initialized, then initialize it
	//if( this->svm_problemPtr_->l == 0 )
	//{
	//	this->makeSvmProblem( wus );
	//}

	////if problem hasn't been initialized, 
	//if( this->svm_problemPtr_->l == 0 )
	//{
	//	std::cout << "Sorry, you are attempting to run the train function without any attributes." << std::endl;
	//	std::cout << "Please recheck this." << std::endl;
	//	exit(1);
	//}

	//ok, so I need to remake the problem every time a run of cross-validation occurs
	// b/c the makeup of the training vectors changes each time.
	makeSvmProblem( wus );

	//run sanity check on svm param
	if( svm_check_parameter( this->svm_problemPtr_, svmParam() ) != NULL ) 
	{
		std::cout << "Error generating SVM Parameter." << std::endl;
		std::cout << svm_check_parameter( this->svm_problemPtr_, svmParam() ) << std::endl;
		std::cout << "Type 'x' key and then Enter to exit program..." << std::endl;
		char e;
		std::cin >> e;
		exit(1);
	}

	//debug the svm_problemPtr_ here.

	//if I'm going to make the model myself, then I make sure the previous model is cleaned out
	freeMemorySvmModel_();

	//run training to create a model
	svm_modelPtr_ = svm_train( svm_problemPtr_, svmParam() );
	//svm_modelPtr_ = svm_train( svm_problemPtr_, &svm_param_ );

	//removing this b/c it will kill performance of my cross validation
	//svm_save_model( "svm_model.txt", svm_modelPtr_ );


	//run before calling svm_get_svr_probability and svm_predict_probability
	//if(	svm_check_probability_model( this->svm_modelPtr_ ) == 0 )
	//{
	//	std::cout << "this->svm_modelPtr_->param.svm_type: " << this->svm_modelPtr_->param.svm_type  << endl;
	//	std::cout << "this->svm_modelPtr_->probA: " << this->svm_modelPtr_->probA  << endl;
	//	std::cout << "this->svm_modelPtr_->probB: " << this->svm_modelPtr_->probB  << endl;
	//	std::cout << "Error generating Probability Model." << std::endl;
	//	std::cout << "Model does not contain required information to do LIBSVM probability estimates." << std::endl;
	//	std::cout << "Type 'x' key and then Enter to exit program..." << std::endl;
	//	char e;
	//	std::cin >> e;
	//	exit(1);		
	//}
}

double LibSvmAdapter::predict(const struct svm_model *model, const struct svm_node *x)
{
	if(  model == NULL )
	{
		std::cout << "Sorry, Trying to predict without a valid model." << std::endl;
	}

	if(  x == NULL )
	{
		std::cout << "Sorry, Trying to predict without a valid node." << std::endl;
	}

	//make sure param is using latest settings.
	svmParam();

	double result = svm_predict( model, x );
	return result;
}

void LibSvmAdapter::crossValidate( 
		const std::vector< WorkUnit* >&  wus,
		int nFold,
		double cost,
		double gamma,
		Stats& o_stat
		)
{
	//@todo WILL THIS HAVE UNINTENDED CONSEQUENCES??

	//backup C and gamma values from the class's svm_param member
	//double savedCost  =	optionsAdapter_.cost();
	//double savedGamma = optionsAdapter_.gamma();
	
	//store c and g into the stat instance, so we can reference
	//them later for the best Stat's
	o_stat.setCost( cost );
	o_stat.setGamma( gamma );

	//temporarily change the svm_param for cross validation
	//convert c and g to true values w/ 2^c and 2^g
	//svm_param_.C = 55;
	optionsAdapter_.setCost(  cost  );
	optionsAdapter_.setGamma( gamma );

	//std::cout << "Using gamma = " << svm_param_.gamma << endl;
	//cout <<		 "Using C     = " << svm_param_.C << endl;

	crossValidate( wus, nFold, o_stat );
//	double successRate	= this->crossValidate( wus, nFold );

	//reset the LibSvmAdapter's svm_param to previous values
	//optionsAdapter_.setCost(  savedCost  );
	//optionsAdapter_.setGamma( savedGamma );

	
//	return successRate;
}



	/**
	deferring this until train() method b/c the active wus haven't been set yet.
	*/
	//If svm problem not initialized, then initialize it
	//if( this->svm_problemPtr_->l == 0 )
	//{
	//	this->makeSvmProblem( wus );
	//}

	//if( this->svm_problemPtr_->l == 0 )
	//{
	//	std::cout << "Sorry, you are attempting to run a crossvalidation function without any attributes." << std::endl;
	//	std::cout << "Please recheck this." << std::endl;
	//	exit(1);
	//}

//	int numLabels = WorkUnit::getActivePositionsLength();

	//get some memory to hold all the predicted label values
//	double *predictedLabelsPtr_ = (double *)calloc( numLabels, sizeof( double ) );
	
	//cross validate
	/**
	NO, we can't use the libsvm cross_validation function b/c we have a special case
	*/
	//svm_cross_validation( this->svm_problemPtr_, &svm_param_, nFold, predictedLabelsPtr_ );
	
	//I will default to full x-fold cross validation. this means no need for randomization

	/**
	for each vector:
	1. separation 1 vector from the rest
	 1a. remove it's identity value
	2. Remove LA value reference to the 'prediction' vector from the la matrix.

	-1, 1a, and 2 can be achieved by calling updateActivePositions
	*/
void LibSvmAdapter::crossValidate( const std::vector< WorkUnit* > &wus, int nFold, Stats& o_result )
{
	//turn on static cross-validation switch
	WorkUnit::isCrossValidation = true;
	vector<int> inactivePositions;

		//ok, I only support leave one out and 10fold crossvalidation.
		//anything other than 0, will be treated as 10 fold cv. (unless, it's really small set of workunits)
		if( nFold != 0 && wus.size() > 10 )
		{
			//cout << "Performing 10-fold cross validation..." << endl;
			//cout << "Cross Validation only supports 'leave one out' cross validation at the moment." << endl;
			//cout << "Each sample is predicted one at a time against a model trained from the remaining samples." << endl;

			//remainder is value 0 - 9
			//ideally, spread this remainder as equally as possible among the groups
			int remainder = wus.size() % 10;
			int foldSize =  wus.size() / 10;
			int wuFoldPosition = 0;

			//inactive = predict
			//active   = train

			//save to file
			stringstream outstream;

			//perform 10 cross validations
			for( unsigned int i=0; i<10; i++ )
			{
				//inactivePositions.clear();//reset as long as we do one at a time
				inactivePositions.resize(0);

				//DebugHelper::debug( inactivePositions, true );

				//ok, this vector needs to have the next 10% of workunits from set each time through the loop

				//make the correct group of size, foldsize, inactive first
				for( int j=0; j<foldSize; j++, wuFoldPosition++ )
				{
					inactivePositions.push_back( wuFoldPosition );//add the vector to be predicted, i.e. inactive
				}

				//now add a position based on the remainder
				if( i < remainder )
				{
					inactivePositions.push_back( wuFoldPosition );
					wuFoldPosition++;
				}

				//DebugHelper::debug( inactivePositions, true );

				//now actually update the active positions
				WorkUnit::updateActivePositions( inactivePositions );
				
				//ok, we need to choose the correct partition/chunk of Wus to train on for the
				//iteration of cross validation right here.
				//the updateActivePositions() function setup the backgroup to make the split correct
				vector<WorkUnit*> wusTrain;
				getTrainerOrPredicteeWus( wus, wusTrain, true );

				//train model
				//libsvmadapter train always trains only the Active Positions vectors
				train( wusTrain );//side effect. this will update the class's svm_modelPtr_ member
				
				//now pick the correct prediction wus here.
				vector<WorkUnit*> wusTest;
				getTrainerOrPredicteeWus( wus, wusTest, false );
				
				//Unit test: Get Stat for each 1/10th and save it to file
				//#ifdef _CPPUNIT	
				//{
				//	Stats _s( optionsAdapter_ );
				//	_s.setCost( optionsAdapter_.cost() );
				//	_s.setGamma( optionsAdapter_.gamma() );
				//	_predict( wusTest, _s );
				//	//_s.update( wusTest, 


				//	_s.print( outstream );
				//	outstream << endl;
				//	_s.printClassInfo( outstream );
				//	//cout << outstream.str() << endl
	
				//}
				//#endif
				
				//ok, get the results from one iteration of cv
				_predict( wusTest, o_result );

				//I think we are good to this point.
				// is there a problem with freeing the svm problem only once for 10 fold?
				//i don't think so.
				freeMemorySvmProblem_();
				//freeMemorySvmModel_();	
			}	

			stringstream filename;
			filename << optionsAdapter_.cost() << "_" << optionsAdapter_.gamma() << "_CV_10fold_detailed_Stats" << ".txt";
		//	IO::writeFile( filename, outstream, optionsAdapter_.resultsPath() );

			stringstream str;
			str << "whatever";

			stringstream s;
			s << "myfilename.txt";

		//	IO::writeFile ( s, str, "library/" );

			if( wuFoldPosition !=  wus.size() )
			{
				cout << "wuFoldPosition did not equal  wus.size() after 10 fold cross validation" << endl;
				cout << "wuFoldPosition = " << wuFoldPosition << ", wus.size() = " << wus.size() << endl;
				cout << "hit 'x' and Enter to continue" << endl;
				char c;
				cin >> c;
			}

		}
		else//run prediction on each vector one at a time i.e. Leave one out Cross Validation
		{
			for( unsigned int i=0; i<wus.size(); i++ )
			{
				
				//need to separate vectors to be used for training and those to be predicted - done
				//inactivePositions.clear();//reset as long as we do one at a time
				inactivePositions.resize(0);
				inactivePositions.push_back( i );//add the vector to be predicted, i.e. inactive
				WorkUnit::updateActivePositions( inactivePositions );

				//clear out the old model structure before setting up new model by
				//training -- or should I be calling new and delete each time?
				//freeMemorySvmModel_();
				
				//ok, we need to choose the correct partition/chunk of Wus to train on for the
				//iteration of cross validation right here.

		//if( WorkUnit::isCrossValidation == true )
		//{
		//	//used for crossvalidation only
		//	
		//}
		//else
		//{
		//	wusActive = wus;
		//}
				vector<WorkUnit*> wusTrain;
				getTrainerOrPredicteeWus( wus, wusTrain, true );

				//train model
				//libsvmadapter train always trains only the Active Positions vectors
				train( wusTrain );//side effect. this will update the class's svm_modelPtr_ member
				
				//now pick the correct prediction wus here.
				vector<WorkUnit*> wusTest;
				getTrainerOrPredicteeWus( wus, wusTest, false );
				
				//ok, get the results from one iteration of cv
				_predict( wusTest, o_result );

				freeMemorySvmProblem_();
				//freeMemorySvmModel_();	
			}	
		}
		
		//reset all positions to active before leaving cross validation
		inactivePositions.resize(0);
		WorkUnit::updateActivePositions( inactivePositions );
		
	
	//turn on static cross-validation switch
	WorkUnit::isCrossValidation = false;

	return;

}


//ok, what do to with these results?
			/**
			these are results of 1 or more currently 'inactive' wus.
			I need to look up these wu's scores to see if they were
			correctly classififed.

			then store into some result mechanism.
			results for cv iteration vs best iteration vs total sums


			*/

			//NEXT. how to make this predict work for me in cv. maybe a private version of
			//predict?

//			ok, private predict( WorkUnit* )
//			{
//				//i'll look at make node first..ok, that looks good.
//				//as long as the new activePositions changes in it work.
//				//hmmm, my FASTA output files are empty. something didn't work in
//				//the normal train test. this must be fixed first. ok, that's fixed.
//				//my guess is problems w/ local/temp var's
//				makeSvmNode
//
////				I'm most concerned about the model. let's check that out.
//				//doh, that's a result from training. so it should be fine.
//			}


	/**
	3. train model
	4. predict
	5. record: (we can use this to calculate accuracy rate of cv)
	
 	 class 0 tp fp
     class 1 tp fp
	(class 2 tp fp)
	*/


	//BEGIN LIBSVM PREDICTED LABELS SECTION

//    int i;
    //store results of cross validation to vector
//	for(i=0; i<numLabels; i++)
//	{
//		predictedLabels_.push_back( predictedLabelsPtr_[i] );
//	}
//
//	//print results of cross validation to screen
//	double totalCorrect = 0;
//	std::vector< WorkUnit* >::const_iterator m = wus.begin();
//	for(i=0; i<numLabels; i++)
//	{
//		if( static_cast<double>((*m)->getCategory()) == predictedLabelsPtr_[i] ){
//			totalCorrect++;
//		}
//		//std::cout << "known=     " << (*m)->getCategory()  << std::endl;
//		//std::cout << "predicted= " << predictedLabelsPtr_[i]  << std::endl;
//		//std::cout << std::endl;
//		m++;		
//	}
//
//
////	@todo make a function
//	double accuracy = (totalCorrect / WorkUnit::getActivePositionsLength() ) * 100.0;
//	//std::cout << "Cross Validation Accuracy = " << accuracy << "%" << std::endl;
//
//	//free memory used by Label value Pointer
//	if( predictedLabelsPtr_ != NULL )
//	{
//		free(predictedLabelsPtr_);
//	}

	//END LIBSVM PREDICTED LABELS SECTION

	//Stats& s = new Stats();
	//return s;
	//return accuracy;


void LibSvmAdapter::_predict( const std::vector< WorkUnit* >& wus, Stats& m_stat )
{
	
	vector<WorkUnit*> predictees;
	vector<WorkUnit*>::const_iterator it;

	//if( WorkUnit::isCrossValidation == true )
	//{
	//	//used for crossvalidation only
	//	getTrainerOrPredicteeWus( wus, predictees, true );
	//}
	//else
	//{
	//	predictees = wus;
	//}

	//get a result for each individual vector that needs predicting
	//and store it to result vector
	//and store it in the Stats instance, this will compute 
	//hit or miss
	for( it=wus.begin(); it!=wus.end(); it++ )
	{
		struct svm_node* predictee = makeSvmNodePtr( (*it) );
		double predValue = predict( svm_modelPtr_, predictee );
		m_stat.update( (*it), predValue );
		delete predictee;
		//o_result.push_back( predict( svm_modelPtr_, predictee ) );
	}

}


void LibSvmAdapter::makeSvmProblem( const std::vector< WorkUnit* >& wus )
{
	//make sure old problem doesn't get in the way
	//freeMemorySvmProblem_();

	//now allocate svm_problemptr some memory
	this->svm_problemPtr_ = new svm_problem();

	//assert WorkUnit vector size = number Sequence size
	//if( wu.size() != (*i)->getNumSeqScaled().size() )
	//{
	//	cerr << "WorkUnit vector size mismatch with WorkUnit NumSeqScaled size" << endl;
	//	cerr << "Fatal error in LibSvmAdapter class. Exiting";
	//	exit(1);
	//}

	//1. set the length of svm problem's training data
	
	int length = wus.front()->size();
	//if( WorkUnit::isCrossValidation == true )
	//{	
	//	length =  WorkUnit::getActivePositionsLength();
	//}
	//else
	//{
	//	length =  wus.front()->getNumSeqScaled().size();
	//}

	svm_problemPtr_->l = length ;

	//2. make array of doubles containing category value for each WorkUnit
	(svm_problemPtr_->y) = makeSvmProblemCategories( wus );

	//3. make a 2-dimensional array of svm_node*'s containing contents of
	//wu's numseqSacled's
	//aka, setup svm_problem->x
	makeSvmNodePtr2Ptr( wus );

}

//WATCH OUT! TEST THIS CODE FOR SIDE EFFECTS!
void LibSvmAdapter::getTrainerOrPredicteeWus( const vector<WorkUnit*>& i_input, vector<WorkUnit*>& o_output, bool isTrainer )
{

	const vector<bool> boolVtor = WorkUnit::getActivePositions();

	//DebugHelper::debug( i_input, false );
	//DebugHelper::debug( boolVtor, false );

	//check/assert that input.length == activepositions.length
	//std::cout << "i_input.size(): " << i_input.size() << std::endl;
	//std::cout << "boolVtor.size(): " << boolVtor.size() << std::endl;

	vector<WorkUnit*>::const_iterator wuIt = i_input.begin();
	std::vector<bool>::const_iterator  boolIt;

	//push active WorkUnit's onto the return vector of WorkUnits
	//while( boolIt != boolVtor.end() )
	for( boolIt = boolVtor.begin(); boolIt != boolVtor.end(); boolIt++)
	{
		if( (*boolIt) == true && isTrainer == true )
		{
			o_output.push_back( (*wuIt) );
		}

		if( (*boolIt) == false && isTrainer == false )
		{
			o_output.push_back( (*wuIt) );
		}

		wuIt++;
	}	
}

void LibSvmAdapter::makeSvmNodePtr2Ptr( const std::vector<WorkUnit*>& wus )
{

	//get some memory to hold all the pointers to svm_nodes
	//this should be 1 more than number of work units because Libsvm
	//@todo should this be sizeof struct svm_node* or svm_node**? or does it matter?
	
	int length = wus.front()->size();
	//if( WorkUnit::isCrossValidation == true )
	//{	
	//	length =  WorkUnit::getActivePositionsLength();
	//}
	//else
	//{
	//	length =  wus.front()->getNumSeqScaled().size();
	//}

	svm_problemPtr_->x = (svm_node **) calloc( length, sizeof( struct svm_node* ));

	//now walk down and attach a svm_node* for each
	//work unit that will be part of the training data
	svm_node **walker = svm_problemPtr_->x;

	//@TODO FIX THIS TO MATCH ACTIVE -- done inside function def of crossvalidation
	
	//vector<WorkUnit*> wusActive;

	//if( WorkUnit::isCrossValidation == true )
	//{
	//	//used for crossvalidation only
	//	getTrainerOrPredicteeWus( wus, wusActive, true );
	//}
	//else
	//{
	//	wusActive = wus;
	//}


	//need a new function to return only the subset of wus to put in the training session
	std::vector< WorkUnit* >::const_iterator i = wus.begin();
	int j = 0;
	while( i != wus.end() )
	{
		walker[j] = makeSvmNodePtr( *i );
		i++;
		j++;
		//walker++;
	}
}



//don't forget to destroy doubles* !
void LibSvmAdapter::freeMemorySvmProblem_()
{

	if( svm_problemPtr_ != NULL)
	{
		
		struct svm_node** walker = svm_problemPtr_->x;//points a walker to head

		//destroySvmNodePtr( walker[0] );//free first SvmNodePtr
		
		//now free the SvmNodePtrs
		for( int i = 0; i < svm_problemPtr_->l; i++ )
		{	
/*			for( int j=0; j <= svm_problemPtr_->l; j++
			{*/			
				if( walker != NULL )
				{
					free( walker[i] );
					//cout << "walker[i]->index " << walker[i]->index;
					//destroySvmNodePtr( walker[i] );
				}
			//}
		}

		//now free the double array y of Labels/Categories
		free( svm_problemPtr_->y );

		//struct double* dWalker = svm_problemPtr_->y;
		//
		//for( int i = 0; i < svm_problemPtr_->l; i++ )
		//{	
		//	free( dWalker[i] );
		//}
	}

	free( svm_problemPtr_->x );

	//delete or set to NULL?
	//i think set to null b/c it's a class member, and we never
	//called 'new' on it.
	delete this->svm_problemPtr_;
	svm_problemPtr_ = NULL;
}

//this doesn't destroy a single node.
//this should free a pointer to a list of nodes that was created
// by a call to calloc()
//void LibSvmAdapter::freeSvmNodePtr_( svm_node* s )
//{
//	if( s != NULL)
//	{
//		//ok, this is numseqscaledlength+1 svm_node's.
//		//does free 1 or all of them?
//		free(s);
//	}
//}

//the number of values in numSeqScaled is greater (usually) than 
//number of WorkUnits in the vector

double* LibSvmAdapter::makeSvmProblemCategories( const vector<WorkUnit*>& wus )
{
	
	//int length = static_cast<int>( (*wu)->getActivePositionsLength() );
	
	
	//if( WorkUnit::isCrossValidation == true )
	//{	
	//	length =  WorkUnit::getActivePositionsLength();
	//}
	//else
	//{
	//	length =  wus.front()->getNumSeqScaled().size();
	//}
	int length = wus.front()->size();

	double *head;
	head = (double *) calloc( length, sizeof( double ) );
	
	double *walker = head;

	vector< WorkUnit* >::const_iterator i = wus.begin();

	//fill up double array with Category/Label values of WorkUnits
	while( i != wus.end() )
	{
		(*walker) = (*i)->getCategory();
		i++;
		walker++;
	}

	return head;
}

//GREAT CHANCE FOR CRASHING HERE. SHOULD THROW EXCEPTION
//ADD MORE MEMORY ERROR CHECKING
struct svm_node* LibSvmAdapter::makeSvmNodePtr( WorkUnit* w )
{
	//so, just like a char*, just need to do that with these\
	//structs to make a string of them
	
//	int numSeqLengthScaledActive = WorkUnit::getActivePositionsLength();
	
	
	//give me a chunk of memory big enough to hold an svm_node for each
	//number in my work unit's numseqScaled, plus one more terminating svm_node
	//which just holds an index of -1 as its terminating symbol
	//HEY, you put an extra node here! don't forget to destruct it!
	//Where do I free this memory? in the destructor of course
	
	int length = w->size();
	//if( WorkUnit::isCrossValidation == true )
	//{	
	//	length =  WorkUnit::getActivePositionsLength();
	//}
	//else
	//{
	//	length =  w->getNumSeqScaled().size();
	//}

	struct svm_node* head;
	head = (svm_node *) calloc( ( length+1 ), sizeof( struct svm_node ));
	
	if( head == NULL )
	{
		cout << "Sorry, the system appears tohave run out of memory. Exiting..." << endl;
		exit(1);
		//cout << "Wow. (svm_node *) calloc( ( length+1 ), sizeof( struct svm_node )) just returned a NULL pointer." << endl;
		//cout << "If we're not out of memory on the system, then is the memory space of hivm corrupted another way?" << endl;
		//cout << "length+1 = " << length+1 << endl;
		//cout << "sizeof( struct svm_node ) = " << sizeof( struct svm_node ) << endl;
		//cout << "calloc return value = " << head << endl;
		//cout << endl;
		//cout << "Let's try the same calloc call again..." << endl;
		//svm_node* testHead;
		//testHead = (svm_node *) calloc( ( length+1 ), sizeof( struct svm_node ));
		//
		//cout << "length+1 = " << length+1 << endl;
		//cout << "sizeof( struct svm_node ) = " << sizeof( struct svm_node ) << endl;
		//cout << "calloc return value = " << testHead << endl;
	}

	struct svm_node* walker = head;//now point a walker to that head

	//ok, if you put a temp variable vector here, everything seems ok
	//if you try to chain functions instead w->getNumSeqScaledActive().begin and
	//w->getNumSeqScaledActive().end(), you run into crashes
	//research the memory details of chaining vs making temp local var's to do the same thing
	//vector<double> v = w->getNumSeqScaledActive();

	//this actually returns numSeqScaled or numSeqScaledActive as needed
	vector<double> dblVtr = w->getNumSeqScaledActive();						
	std::vector< double >::iterator it;

	//ok, got the memory. now, put the structs into the allocated memory
	//while( j < numSeqLengthScaled )
	int j = 0;
	//while( it != dblVtr.end() )
	for( it = dblVtr.begin(); it != dblVtr.end(); it++ )
	{
		//struct svm_node s;
		walker->index = j;
		walker->value = (*it);

		j++;
		walker++;
	}

	//now add special termination symbol: index = -1
	walker->index = -1;
	walker->value = -1;
	//cout << "terminating walker--" << endl;
	//cout << "walker: " << walker << endl;
	//cout << "\n";

	return head;

}


void LibSvmAdapter::freeMemorySvmModel_( )
{
	if( svm_modelPtr_ != NULL )
	{
		svm_destroy_model( this->svm_modelPtr_ );
		svm_modelPtr_ = NULL;
	}
	//if(svm_modelPtr_->free_sv && svm_modelPtr_->l > 0)
	//{
	//	free((void *)(svm_modelPtr_->SV[0]));
	//}

	//for(int i=0;i<svm_modelPtr_->nr_class-1;i++)
	//{
	//	free(svm_modelPtr_->sv_coef[i]);
	//}
	//
	//free(svm_modelPtr_->SV);
	//free(svm_modelPtr_->sv_coef);
	//free(svm_modelPtr_->rho);
	//free(svm_modelPtr_->probA);
	//free(svm_modelPtr_->probB);
	//free(svm_modelPtr_->label);
	//free(svm_modelPtr_->nSV);
	////free(svm_modelPtr_);

}