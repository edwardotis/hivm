#include "Result.h"

Result::Result() :
gamma_(DBL_MAX),
cost_(DBL_MAX),
truePositiveRate_(DBL_MAX),
falsePositiveRate_(DBL_MAX),
trueNegativeRate_(DBL_MAX),
falseNegativeRate_(DBL_MAX)
{}

Result::Result( double gamma, double cost, double tpr, double fpr,
			   double tnr, double fnr ) :
gamma_(gamma),
cost_(cost),
truePositiveRate_(tpr),
falsePositiveRate_(fpr),
trueNegativeRate_(tnr),
falseNegativeRate_(fnr)
{}

Result::~Result(){}


/*binary function predicate:    */
bool Result::resultSortCriterion (const Result* r1, const Result* r2)
{
	return (r1->falsePositiveRate() < r2->falsePositiveRate() );
}

double Result::gamma() const
{
	return gamma_;		
}

void   Result::gamma( double gamma )
{
	gamma_ = gamma;
}

double Result::cost() const
{
	return cost_;		
}

void Result::cost( double cost )
{
	cost_ = cost;
}

double Result::truePositiveRate() const
{
	return truePositiveRate_;		
}

void Result::truePositiveRate( double truePositiveRate )
{
	truePositiveRate_ = truePositiveRate;
}

double Result::falsePositiveRate() const
{
	return falsePositiveRate_;		
}

void Result::falsePositiveRate( double falsePositiveRate )
{
	falsePositiveRate_ = falsePositiveRate;
}

double Result::trueNegativeRate() const
{
	return trueNegativeRate_;		
}

void Result::trueNegativeRate( double trueNegativeRate )
{
	trueNegativeRate_ = trueNegativeRate;
}

double Result::falseNegativeRate() const
{
	return falseNegativeRate_;		
}

void Result::falseNegativeRate( double falseNegativeRate )
{
	falseNegativeRate_ = falseNegativeRate;
}
