#ifndef IO_H	
#define IO_H

#include "std_include.h"

class IO
{

public:


/**
@purpose save and read files in one in the program
@returns true for success, false for failure
@todo make writes more robust. add error checking for '/', etc
*/
static bool writeFile( const stringstream& fileName,  const stringstream& i_sstream );
static bool writeFile( const stringstream& fileName,  const stringstream& i_sstream,  const stringstream& pathName );
static bool writeFile( const stringstream& fileName,  const stringstream& i_sstream,  const string pathName );

static bool readFile( const stringstream&  fileName, stringstream& o_sstream );
static bool readFile( const stringstream&  fileName, stringstream& o_sstream, const stringstream&  pathName ); 
static bool readFile( const stringstream&  fileName, stringstream& o_sstream, const string  pathName ); 

private:

/**
@purpose helper function to handle main saving of file
*/
static bool writeFile_( const stringstream& fileName,  const stringstream& i_sstream );
	
/**
@purpose helper function to handle main saving of file
*/
static bool readFile_( const stringstream& fileName,  stringstream& o_sstream );


	//constructor
	IO();

	//destructor
	~IO();

	//copy constructor
	IO( const IO& );

	//assignment operator
	IO& operator= ( const IO & );
};

#endif

