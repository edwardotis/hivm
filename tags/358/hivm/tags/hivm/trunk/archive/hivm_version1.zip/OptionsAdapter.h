/**
 * @purpose: OptionsAdapter class is responsible for 
 * gathering the necessary program options from the options text file,
 * and providing that data to the rest of the app
 * 
 * It provides clean interface to the original PhaseMachine
   Options class and the hivm Instruction class which were already created to
   hold different sets of options. 
 * 
 */

#ifndef OptionsAdapter_H
#define OptionsAdapter_H

#include "std_include.h"
#include "Instruction.h" //aggregates Instruction class
#include "Options.h"	 //aggregates Options class
#include "LibSvmFacade.h"
#include "StringTokenizerAdapter.h"
#include "Hash.h"
#include "IO.h"


class OptionsAdapter{

public:

	//ENUMS
	enum enumSampleType
	{
		All			= 0,
		Lab		    = 1,
		Clincial	= 2
	};

	//Default Constructor
	//@purpose - use default options file if no custom file is desired
	//@pre option file named "default_options.txt" is in same directory
	// as the executable, and file is in format specified in the User Manual
	OptionsAdapter();

	//Constructor for custom options file
	//@purpose -allow user to specify a customized options file
	//@param -takes the name of the options file from cmd line
	//@pre	file is located in same directory as the executable,
	//and  file is in format specified in the User Manual
	OptionsAdapter( string optionsFileName );

	//Default Destructor
	virtual	~OptionsAdapter();


	//enum eKernelType
	//{
	//	LINEAR	   = 0,
	//	POLY	   = 1,
	//	RBF		   = 2,	
	//	SIGMOID	   = 3
	//};

	//enum eSvmType
	//{
	//	C_CLASSIFICATION	 = 0,
	//	NU_CLASSIFICATION	 = 1,
	//	ONE_CLASS			 = 2	
	//};

//OptionsAdapter::eSvmType Options::getSvmType() const
//{
//	return svmType;
//}
//
//OptionsAdapter::eKernelType Options::getKernelType() const
//{
//	return svmType;
//}
	/**
		Setter methods:
		Options are stored and retrieved as (key,value) pairs

	*/
	//void setString( string key, string value );
	//void setInt( string key, int value );
	//void setDouble( string key, double value );

	/**
		Getter methods.
		Options are stored and retrieved as (key,value) pairs
		ALL OF THESE NEED TO THROW EXCEPTIONS IF VALUE NOT FOUND
		IN THE MAP - You know what? dtich the map.
		It's more trouble here than it is worth for me.
		Just do plain old member variables, and I would have already been done.
		Make it public. I can make getter/setter later.

	*/
	//std::string getString( string key ) const;
	//double getDouble( string key ) const;
	//int getInt( string key ) const;
	//string getOption( string key );

	/**
	@purpose print SVM parameters held in OptionsAdatper
	*/
	void printParam();

// hard coded var's from PhaseMachine Option class

	/**
	@purpose returns cache size in MB
	*/
	int getCacheSize() const;

	double getP() const;

	int getProbability() const;

	int getShrinking() const;

	int getNrWeight() const;

	std::string getWeightLabel() const;

	std::string getWeight() const;

	//set log2 of cost and gamma
	//get actual cost and gamma
	double cost();
	void setCost( double );

	double gamma();
	void setGamma( double );

	//get log2 cost and gamma
	//double costLog2();
	//double gammaLog2();

	//LIBSVM configuration
	void getSVMParam( struct svm_parameter& );

	//Instruction interface
	std::vector<double> getThresholds() const;
	std::string getDrug() const;
	int getNumOfCategories() const;
	std::string getOrigVirusSeq() const;
	std::string getSusceptibilityDataFileName() const;
	const Options& getOptionsClass();//returns internal Options class
	
	//hivm performance evaluation parameters for training samples
	int numSamplesToUse() const;
	void numSamplesToUse( int _numSamplesToUse );
	double fractionSamplesToTest();
	enumSampleType sampleType();

	double costLow() const;
	double costHigh() const;
	double costIncrement() const;

	double gammaLow() const;
	double gammaHigh() const;
	double gammaIncrement() const;



	//identifier
	unsigned long uniqueID() const;

	string resultsPath() const;
	void resultsPath( string );

	string libraryPath() const;
	void   libraryPath( string libraryPath );

	//cmd line params
	/**
	@purpose parts cmd line and overwrite config file when necessary
	@note No error checking. seriously. make sure the cmd line is formatted correctly.
	@returns Type of execution user wants to run
	*/
	string parseInput( int argc, char * argv[] );

	//library creation
	double libraryFraction() const;

	//prediction
	string predicteeSeqsFileName() const;
	string thresholdsLevel() const;
	void thesholdsLevel( string );

	//needed by hivm prediction
	void drug( string i_drug );
	void dataSet( string i_dataSet_filename );
	void threshold( double i_threshold );
	void origVirusSeq( string i_filename );//actually sets the seq.
	void origVirusSeqFileName( string i_filename );

	//returns the first threshold
	double threshold();

	//profile
	string enzyme();

	//validatelibrary helpers
	//@purpose need a special holder for cost and gamma from cmd line in this instance
	// because we read cost and gamma from the auto-params.txt file, and we may want to
	//override the auto param value, with user specific cmd line args.
	double cmdLineCost();
	double cmdLineGamma();

	//print instructions for running hivm from cmd line
	void printUsage();


protected:

	//for holding contents of cmd line as strings
	vector<string> cmdLineArgSet_;
	
	string resultsPath_;
	string libraryPath_;

	unsigned long uniqueID_;

	StringTokenizerAdapter strTok_;
	
	friend class TestOptionsAdapter;//unit test 
	
	//members
	Instruction instr_;
	Options     options_;
    string DEFAULT_OPTIONS_FILE_NAME;// "configDefault.txt"

	int cache_size;
	double p;
	int shrinking;
	int nr_weight;
	int *weight_label;
	double *weight;
	int probability;

	//hivm performance evaluation parameters
	int numSamplesToUse_;
	double fractionSamplesToTest_;
	//based on susceptibility dataset
	enumSampleType sampleType_;

	//for grid search
	double costLow_;
	double costHigh_;
	double costIncrement_;

	double gammaLow_;
	double gammaHigh_;
	double gammaIncrement_;

	//double cost_;
	//double gamma_;

	//for library creation
	//fractino of samples to put into a library
	double libraryFraction_;
	string enzyme_;//PI or RT

	//for prediction function
	
	//location user put file of sequences to be classified
	string predicteeSeqsFileName_;
	
	//level of thresholds to use for drugs when classifying
	//unknowns. This links to 3 files with thresholds for each drug
	//options: default, low, high
	string thresholdsLevel_;

	//validatelibrary
	double cmdLineCost_;
	double cmdLineGamma_;

	/**
	@purpose improved power math function that correctly computes
	negative exponents
	*/
	double powSigned_( double base, double exponent );

	double logSigned_( double base, double exponent );


	/**
	@purpose save configuration and cmd line args to file
	so experiments can be repeated in the future.
	*/
	void printConfiguration_( const stringstream& );

	/**
	@purpose initialize the Svm Parameter struct
	@pre parseInput must be called first
	*/
	virtual void initSvmParam( std::string );
	
	/**
	@purpose initialize the hivm performance eval options
	*/
	virtual void initPerformanceEvaluationOptions( string i_options );

	//typedef std::map<std::string,string> StringStringMap;
 //   StringStringMap ssMap;

	//typedef std::map<std::string,int> StringIntMap;
 //   StringIntMap siMap;

	//typedef std::map<std::string,double> StringDoubleMap;
 //   StringDoubleMap sdMap;



	
	//setup Options and Instruction with correct data,
	//from options file
	void initialize( std::string fileName );



private:

    //copy constructor
	OptionsAdapter( const OptionsAdapter& );
	
	//assignment operator
	OptionsAdapter& operator= ( const OptionsAdapter& );


};

#endif // OptionsAdapter_H
