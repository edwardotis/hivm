/**
@purpose Further process data before
use in training and prediction
*/

#ifndef SVMPREPROCESSOR_H
#define SVMPREPROCESSOR_H

#include "std_include.h"
#include "WorkUnit.h"
#include "OptionsAdapter.h"
#include "LibSvmAdapter.h"
#include "Stats.h"
#include "DebugHelper.h"
#include "IO.h"



class SvmPreProcessor
{

public:

	//SvmPreProcessor( OptionsAdapter& _oa ) ;
	
	//defaut constructor

	SvmPreProcessor( const OptionsAdapter& );
	
	//default destructor
	~SvmPreProcessor();

	//structs

	//bounds are exponents of base 2
	//struct costTestParam
	//{
	//	int startBound;
	//	int endBound;
	//	float increment;
	//};
	//

/**
@purpose print special library file
*/
	void saveLibraryStats(  );


	//struct gammaTestParam
	//{
	//	int startBound;
	//	int endBound;
	//	float increment;
	//};
	
	//deprecate
	//struct bestParameters
	//{
	//	double bestCost;
	//	double bestGamma;
	//	double successRate;
	//};
	
	/**
	@purpose scales EACH ATTRIBUTE in data set to [-1,1]
	x'' =  [ ( 2* (x-mini) )/(Maxi-mini) ] - 1
	@pre All WorkUnits passed have valid numSeq
		-Max and Min values in seq must not be the same value.
	@post Each WorkUnit numSeq has new numSeqScaled to [-1,1]
	*/
	virtual void scale( std::vector<WorkUnit*>& );

	/**
	next function is findBestParameters();
	@pre setCostTestParam and setGammaTestParam have been initialized
	@post finds bestCost and bestGamma, and sets them to global configuration
	will use grid search for C (penalty cost) and gamma (statical bandwidth)
	*/
	virtual void findBestParameters( std::vector<WorkUnit*>&, LibSvmAdapter&, int nFold,
		OptionsAdapter& m_optAdptr );

	/**
	@purpose write the best C and g values to the application's
	configuration repository

	*/
	virtual void storeBestParameters( OptionsAdapter& m_optAdptr, double cost, double gamma );

	/**
	@purpose prints details of stored classes to screen
	@param destination - 0 = std out, 1 = local disk
	*/
	virtual void printBestStats( int i_destination  );

	//bounds are exponents of base 2
	//virtual void setCostTestParam( int start, int end, float increment );
	//virtual void setGammaTestParam( int start, int end, float increment );

	struct bestParameters getBestParameters();

	//virtual double getBestCost() const;
	//virtual double getBestGamma() const;

	virtual void print() const;

	//area under ROC curve
	double areaUnderCurve_;

	//tests and sets best Statistics
	virtual void updateBestStats_( Stats& i_stat );


protected:

	//costTestParam costTestParam_;
	//gammaTestParam gammaTestParam_;
//	bestParameters bestParameters_;//deprecate

	//hold details of crossValidation results with best stats
	//it may be that different parameters cause different 'best of' results
	//let's find out...
	Stats bestSensitivity_;
	Stats bestSpecificity_;
	Stats bestErrorRate_;
	Stats bestPositivePredictiveValue;
	Stats bestNegativePredictiveValue_;
	Stats bestTprOverFprRatio_;
	Stats bestTprFprDifference_;
	

	//tests and sets local best Params based on successRate
	//virtual void setBestParams_( double successRate, double c, double gamma );

	/**
	@purpose perform grid search in broad increments of cost and gamma
	*/
	void gridSearchBroad_( std::vector<WorkUnit*>& wus, LibSvmAdapter& libSvmAdptr, int nFold , Stats& m_crossValidationStat );

	/**
	@purpose perform grid search in narrow increments of cost and gamma, based upon broad grid search best result
	@pre gridSearchBroad_() must be run first
	*/
	//void gridSearchNarrow_( std::vector<WorkUnit*>& , LibSvmAdapter& libSvmAdptr, int nFold , Stats& m_crossValidationStat );



	/**
	@purpose private function that actually computes scaled
	numSeq and inputs it into each WorkUnit

	@pre WU group's max and min has been found
	@post scaled numSeq will be filled for WorkUnit group
	*/
	void scale_( std::vector<WorkUnit*>& );

	/**
	@purpose function that actually scales data set [0-1]
	x' = (x-min)/(Max-min)
	*/
	double computeScaledNum_( double d );



	void setScaledNumSeq_( WorkUnit *w );

	/**
	@purpose checks for max or min in the numSeq
	and sets new max or min if found
	*/
	void findExtrema_( WorkUnit* );

	/**
	@purpose sets _max value of a WorkUnit
	*/
	void findMax_( WorkUnit * );

	/**
	@purpose sets _min value of a WorkUnit
	*/
	void findMin_( WorkUnit * );

	/**
	@purpose reset _max and _min to system
	extremes MAX AND MIN
	*/
	void resetExtrema_();

	/**
	@purpose assert _max and _min don't have
	absurd or default values
	*/
	void sanityCheckExtrema_();

private:

	const OptionsAdapter& _optAdptr;

	double _max;
	double _min;

	SvmPreProcessor();

	//copy constructor
	SvmPreProcessor( const SvmPreProcessor& );

	//assignment operator
	SvmPreProcessor& operator= ( const SvmPreProcessor& );

};

#endif


