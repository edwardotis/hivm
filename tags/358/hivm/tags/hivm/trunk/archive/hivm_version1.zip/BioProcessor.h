#ifndef BIOPROCESSOR_H
#define BIOPROCESSOR_H

/**
@purpose -Convert input data from aminio acids to numeric values based upon 
different biological algorithms

*/

#include "std_include.h"

#include "OptionsAdapter.h"
#include "WorkUnit.h"

class BioProcessor
{

public:

	//default constructor
	BioProcessor();

	//constructor
	//BioProcessor( std::vector<WorkUnit*>& w );

	//default destructor
	virtual ~BioProcessor();


	//@TODO Remove the old process, and just check for empty needClassifyingWUs

	/**
	@note There's no predicting going on. just going to be cross-validating
	@param iterator to container of WorkUnits*'s
	@pre Each work unit must already contain a string of aa's
	@post Each work unit will contain new string of numeric values
		corresponding to aa seq
	*/
//	virtual void process( std::vector<WorkUnit*>& crossValidateOnlyWUs );

	/**
	@note If you want to classify sequences, they must be included in process
	@param iterator to container of WorkUnits*'s
	@pre Each work unit must already contain a string of aa's
	@post Each work unit will contain new string of numeric values
		corresponding to aa seq
	*/
	virtual void process( std::vector<WorkUnit*>& trainingWUs, std::vector<WorkUnit*>& needClassifyingWUs );

	virtual void printScaled( std::vector<WorkUnit*>& wu  );

	virtual void printUnscaled( std::vector<WorkUnit*>& wu  );

	/**
	//pre  bioprocessing has occurred
	//post  file saved in LibSvm data input format
	label is the same as category
	values are numSeq values
	ex. (space delimited, not tabbed)
	<label> <index1>:<value1> <index2>:<value2> ...
	.
	.
	.
	@note useful for running data in alternate implementations of libsvm, such as python
	saveFile()
	*/
	virtual void saveFile( std::vector<WorkUnit*>& wu, std::string outputFileName );

	/**
	@purpose saves cache of the bio procesor results
	*/
	virtual void saveCache( 
		const OptionsAdapter& i_optAdptr,
		const vector<WorkUnit*>& i_wus,
		bool isLibrary,
		int cacheId
		);

	/**
	@purpose looks for cache hit and loads it into the WorkUnit set
	*/
	virtual bool checkCache( 
		const OptionsAdapter& i_optAdptr, 
		vector<WorkUnit*>& m_wus, 
		bool isLibrary,
		int cacheId
		);

protected:
	
	friend class TestLaBioProcessor;
	//vector<WorkUnit*> wu;

	//produces string from the sequence of numbers for a WorkUnit
	void printNumSeqToScreen( WorkUnit *w );

	void printNumSeqScaledToScreen( WorkUnit *w );

	//TYPEDEFS - to improve readability
	typedef std::vector<WorkUnit*>::iterator wuIterator;
	

private:

	void printToScreen( std::vector<double> );

	//copy constructor
	BioProcessor( const BioProcessor& );


	//assignment operator
	BioProcessor& operator= ( const BioProcessor& );

};


#endif
