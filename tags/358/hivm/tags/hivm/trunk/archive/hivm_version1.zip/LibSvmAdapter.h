/**
@purpose Provides an interface to the libsvm C-style functions. Provides memory management and error checking using full features of C++. 
*/

#ifndef LIBSVMADAPTER_H
#define LIBSVMADAPTER_H

#include "std_include.h"
#include "LibSvmFacade.h"
#include "OptionsAdapter.h"
#include "WorkUnit.h"
#include "Stats.h"
#include "DebugHelper.h"

class LibSvmAdapter
{

public:

	//constructor with Options
	LibSvmAdapter( OptionsAdapter& );

	//default destructor
	virtual ~LibSvmAdapter();

	//typedefs
	typedef std::vector<WorkUnit*>::const_iterator wuConstIt;

	/*******************************************************
	// @pre WorkUnit vector contains BioProcessed num seqs,
			WorkUnit vector must NOT include any sequences that 
			you are planning to have predicted using the
			model created by this call to train()
			HOWEVER, the num sequence of each work unit must
			have been generated using the sequences yet to be predicted
	*/
	virtual void train( const std::vector< WorkUnit* >&  );

	/**
	@purpose performs cross validation based upon svm_param
	data member
	@param WorkUnits to cross validate
	@param fold is undefined
	@param Stats instance to hold results
	@pre  svm problem must have been created
	@post returns rate of success of the cross validation
	*/
	virtual void crossValidate( const std::vector< WorkUnit* >&  wus, int nFold, Stats& o_result );

	/**
	@purpose perform cross validation, using special temporary values for
	C - penalty cost, and gamma - statistical bandwidth
	
	@post returns rate of success of the cross validation
	*/
	virtual void crossValidate( 
		const std::vector< WorkUnit* >&  wus,
		int nFold,
		double cost,
		double gamma,
		Stats& o_stat
		);


	/**
		@post returns predicted class for the svm_node
	*/
	virtual double predict(const struct svm_model *model, const struct svm_node *x);


	/**
	@purpose for predicting on a test of a single known sample
	@pre the test wu must already known it's true value
	@pre optimal gamma and cost was already found.
	failure	to have good c,g pair will result in bad results from the predictionTest
	@todo, should I make this function call findBestParams()?
	*/
	virtual void predictionTest( vector<WorkUnit*>& i_trainSet, WorkUnit* i_testWu, Stats& o_stat );

	virtual void predictionTest( vector<WorkUnit*>& i_trainSet, WorkUnit* i_testWu, Stats& o_stat, Stats& o_stat2 );

	/**
	@purpose for predicting on a test set of known samples
	@pre the test set must already known it's true values
	@pre findBestParameters was run, thus setting optimal gamma and cost. failure
	to run this will result in bad results from the predictionTest
	@todo, should I make this function call findBestParams()?
	*/
	virtual void predictionTest( 
		vector<WorkUnit*>& i_trainSet,
		vector<WorkUnit*>& i_testSet,
		Stats&			   o_stat
		);

	/**
	@purpose predict a single sequence as resistant or not, given the 
	parameters stored in LibSvmAdapter's OptionAdapater member variable
	@returns bool
		true:  sequence is resistance to the drug
		false: sequence is susceptible to the drug
	*/
	virtual bool predictIsResistant( vector<WorkUnit*>& i_trainSet, WorkUnit* i_predictee );


protected:

	/**
	@purpose predict a WorkUnit based on the local member model
	@param WorkUnits for use in predicting
	@param Vector to hold prediction results
	*/
	void _predict( const std::vector< WorkUnit* >& wus, Stats& m_stat  );

	/**
	@purpose provides a vector of only the WU's that have been set be:
	a. to be active in the training model, isTrainer == true
	b. vectors to be predicted, isTrainer == false
	*/
	virtual void getTrainerOrPredicteeWus( const vector<WorkUnit*>& i_input, vector<WorkUnit*>& o_output, bool isTrainer  );

	/**
	 @purpose Converts WorkUnit vector into svm_problem*
	 and places it in svm_problemPtr_
	*/
	virtual void makeSvmProblem( const std::vector< WorkUnit* >& wus );

	/**
	 @purpose Free memory used by local struct svm_problem*
	*/
	virtual void freeMemorySvmProblem_( );

	/**
	 @purpose Free memory used by local struct svm_model*
	 Using the Libsvm version of this method causes a memory leak
	 within our program. Please use this version.
	*/
	virtual void LibSvmAdapter::freeMemorySvmModel_( );

	/**
	 @purpose Converts WorkUnit into an struct svm_node*, which
	 is an array of svm_node terminated by  a dummy svm_node 
	 using index of -1 (according to LibSvm specs)
	 @post    struct svm_node*, final svm_node has index of -1
	*/
	virtual struct svm_node* makeSvmNodePtr( WorkUnit* w );

	/**
	 @purpose makes the svm_node** for the svm_problem*

	 */
	virtual void makeSvmNodePtr2Ptr( const std::vector<WorkUnit*>& );

	/**
	@purpose Makde array of Labels/Categories for the svm_problem y
	*/
	double* makeSvmProblemCategories( const  std::vector< WorkUnit* >& wus );

	/**
	 @purpose Free memory allocated to the struct svm_problem* s
	*/
	//virtual void freeSvmNodePtr_( struct svm_node* s );

	svm_parameter* svmParam();

	//members

	//typedef auto_ptr<LibSvmFacade> LibSvmFacadePtr;
	//LibSvmFacadePtr f_;

	//Use Facade auto-object to call the LibSvm functions
//	LibSvmFacade libSvmFacade_;

	//Hold options used by LibSvm
	OptionsAdapter&     optionsAdapter_;

	//holds param options
	struct svm_parameter svm_param_;

	//holds pointer to model made by train function
	//model is used by predict function
	//freeing model uses svm_problem
	struct svm_model*   svm_modelPtr_;
	
	//holds 2-dimensional array of svm_nodes
	//as well as actual values of samples and number of samples
	struct svm_problem* svm_problemPtr_;

	//holds contents of WorkUnit in LibSvm format
	//struct svm_node*    svm_nodePtr_;

	//Predicted labels in the cross-validation process are stored here
	//std::vector<double> predictedLabels_;

	//default constructor
	LibSvmAdapter();


private:

	//copy constructor
	LibSvmAdapter( const LibSvmAdapter& );

	//assignment operator
	LibSvmAdapter& operator= ( const LibSvmAdapter& );

};

#endif
