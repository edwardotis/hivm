/**
 * @purpose: Instruction class is responsible for 
 * gathering the user instructions from the cmd line,
 * and providing that data to the rest of the app
 * 
 * The threshold array code will crash the app if
 * the the number of categories, and the number of 
 * thresholds from the cmd line don't match.
 * Update: Switched a vector in place of the array.

 @todo Be better if this threw an exception instead.
 * 
 */

#ifndef INSTRUCTION_H
#define INSTRUCTION_H

#include "std_include.h"
//#include "string_tokenizer/StringTokenizer.h"
#include "StringTokenizerAdapter.h"


class Instruction{
public:

	//default construtor
	Instruction();

	/**
 	* Construtor for Input the number of categories
 	*/
	Instruction( int );

	/**
 	* 
	  and passing cmd line argc and argv
 	*/
	//Instruction( int argc, char *argv[] );


	/**
 	* @fn constructor passes a string of option file
		arguments used by Instruction class 
		-format of this string is space delimited:
	- input file name
    - virus sequence file
    - name of the drug
    - number of resistance categories (initially use 2 categories, low
      resistance and high)
    - resistance threshold(s); the number of resistance thresholds
      equals the number of categories minus 1

 	*/
	Instruction( std::string options );

	//Default destructor
	~Instruction();



	/**
   * @fn bool setInstructions(); 
   * @param should I pass it a reference
   * to the cmd line argc
   * @pre None
   * @return bool - success or not
   */	
	//bool setInstructions( int argc, char *argv[] ); 

	void initialize( std::string options ); 

	/**
	 preferred version of setInstrucions
   * @return bool - success or not
   */
	bool setInstructions( int argCount, std::vector<string>& options); 


	//getter methods
	string getDrug() const;
	string getDataSet() const;
	string getOrigVirusSeqFileName() const;
	static int getNumOfCategories();
	string getOrigVirusSeq() const;
	/**
	 * @return vector of ordered thresholds as doubles 
	 */
	vector<double> Instruction::getThresholds() const;

	//setter methods
	void setDrug( string newDrug );
	void setDataSet( string newDataSet );
	void setOrigVirusSeqFileName( string newVirusSeqFileName );
	void setNumOfCategories( int newCat );	



	//choose array position 0 through (size-1)
	//vector automatically sorted
	//@todo Remove this function, since we are auto sorting
	//void Instruction::setThreshold( double thresholdValue, int pos );
	
	/**
	@purpose function to set THE ONLY threshold. Clears out the
	other thresholds
	@param new single threshold for the problem
	*/
	void threshold( double threshold );

	/**
	@purpose set a single new threshold, and throw away
	any previous thresholds
	@param new threshold
	*/
	void resetThreshold( double the_only_threshold );

	//@fn set the original virus aa sequence of the enzyme
	// from a file
	void setOrigVirusSeq( string fileName );

protected:

	friend class TestInstruction;//unit test

	StringTokenizerAdapter strTok_;

	/**
	@purpose add a threshold to the threshold vector
	@pre	double >= 0
	@post vector is automatically sorted lowest to hightest
	*/
	virtual void setThreshold( double thresholdValue );	



private:


	//copy constructor
	Instruction( const Instruction& );

	//assignment operator
	Instruction& operator= ( const Instruction& );
	
	std::string origVirusSeq; //holds the sequence that we compare against
	std::string drug; //drug name
	std::string dataSet;// stanford dataset file name
	std::string origVirusSeqFileName; // name of unmutated virus file

	//thresholds size based on number of categories
	double *thresholds;//thresholds to divide into categories
	vector<double> thresholdsVector;//thresholds to divide into categories
	vector<double>::iterator myIterator;
	  
	// # of categories
	static int numOfCategories; 

	
	
	//set all the threshold values from the cmd line
	//vector automatically sorted
	void setThresholds( int myArgC, char* myArgV[] );
	void setThresholds( int argCount, std::vector<string>& options ); //preferred

	
	void sortThresholds();



	/**
	 * @purpose method to be run first to see if cmd line input has
	 * correct number of thresholds to match the input categories
	 * 
	 */
	bool doesNumCatsMatchNumThresholds( int myArgC, char* myArgV[]);

		/**
	 * @purpose method to be run first to see if cmd line input has
	 * correct number of thresholds to match the input categories
	 * 
	 */
	bool doesNumCatsMatchNumThresholds( int argCount, std::vector<string>& options );


	/**
	 * @purpose initialize the threshold array to bad values of
	 * -1, -2, thru -n, for testing the array
	 * thresholds[0] = -1
	 * thresholds[1] = -2; 
	 * 
	 * @pre: threshold array no instantiated yet
	 * @post: threshold array is full of dummy var's
	 */
	void initThresholds( int numOfCategories );

	void printThresholds();

};

#endif // INSTRUCTION_H
