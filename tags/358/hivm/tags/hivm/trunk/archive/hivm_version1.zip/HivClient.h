#ifndef HIVCLIENT_H
#define HIVCLIENT_H

#include "Client.h"
#include "HivPreProcessor.h" 

class HivClient : public Client{
	
public:

	HivClient();
//	HivClient( PreProcessor );
	~HivClient();

private:


};

#endif // HIVCLIENT_H
