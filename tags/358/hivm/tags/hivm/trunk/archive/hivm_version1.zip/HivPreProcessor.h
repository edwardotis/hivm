/**
 * @class HivPreProcessor
 * Concrete class to parse the Hiv input files and get them
 * ready for SVM

 	This version runs the pre November 2004 version of Stanford HIVDB input data sets.

 * 
 * 
 */ 
 
#ifndef HIVPREPROCESSOR_H
#define HIVPREPROCESSOR_H

#include "PreProcessor.h"

class HivPreProcessor : public PreProcessor{

public:

	//HivPreProcessor( OptionsAdapter*,  vector<WorkUnit*>&  );
	HivPreProcessor( OptionsAdapter& );
	~HivPreProcessor(); 

	//void HivPreProcessor::parse( string susceptibilityDataFileName );
	virtual void parse( vector<WorkUnit*>& o_myWuVector, bool isLibrary  );
	void printToFile( vector<WorkUnit*>& myWuVector );
	void printToFile();

	///**
	//* Returns true if drugName found in Header vector and sets drugNameIndex
	//* Returns false if drugName not found in Header vector, drugNameIndex = -1
	//*/
	//bool setDrugNameIndex( string drugName );
	//int getDrugNameIndex();

	///**
	//* Returns true if mutName found in Header vector and sets mutListIndex
	//* Returns false if mutName not found in Header vector, mutListIndex = -1
	//*/
	//bool setMutationListIndex( string mutName );
	//int getMutationListIndex();

	int cacheId();

protected:	

	 vector<string> headerVector;

	int cacheId_;
	//void makeLibraryDataSets_( string& );

	virtual string genMutatedSeq( string mutList );
	
	/**
	return false if the Drug Name not found
	*/
	virtual bool setDrugNameIndex( const vector<string>& myVector, string drugName );
	virtual int getDrugNameIndex();

	/**
	@purpose Workhorse function.
	Parses Susceptibility data sets, generates mutated sequences, and
	creates WorkUnits
	@param myWuVector holds output
	@param isLibrary - if true, does not create WorkUnits. Instead it creates 
	drug datasets suitable for use in library and exits the program.
	*/
	virtual void parseData( vector<WorkUnit*>& myWuVector, bool isLibrary  );


	/**Consider change to private after individual unit testing is done!
		Or not b/c it's good for encapsulation, but damages the unit testing.
	*/
	
	/**
	* Put dataset header strings in a vector. 
	*/
	virtual void setHeaders();

	/**
	* Find index of a string in a vector of strings
	* Return -1 if not found
	* @todo: This function should probably be in the abstract class
	*/
	virtual int findStringIndex( const vector<string>& myVector, string searchString );

	/**
		We need the column number of the MutationList and Isolate Name headers.
		If we use more headers in the future, add them to this function
	*/
	virtual bool setHeaderIndices( const vector<string>& myVector );
	virtual int getMutListIndex();

	virtual int getIsolateNameIndex();

	int drugNameIndex;
	int mutationListIndex;
	int isolateNameIndex;

//double _parseDrugValue( const string& i_string );

/**
@purpose take a 'x' delimited string, and break it up into a vector using the delimiter
@param input string
@param output vector
*/
virtual void _makeStringVector( const string& i_string, vector<string>& o_stringSet );

virtual void _saveLibraryFiles( const stringstream& i_drugStream, const stringstream& i_suscepStream );

virtual void _separateLibDrugs( vector<string>& m_strSet, stringstream& o_drugStream, stringstream& o_suscepStream );

/**
@purpose check if the Fold column for the particular drug has a value, or
if it has no value reported for that drug
@param a row from the dataset
*/
virtual bool _hasDrug( const string&  i_string );

/**
@purpose check if the FoldMatch column for the particular drug has an '>' and '<' "&gt;" and  "&lt;".
It should report that the match was greater than or less than normal match values
@return	false if outside normal range, true if inside range
@param a row from the dataset
*/
virtual bool _isInFoldMatchRange( const string&  i_string );


/**
@purpose validate mutation list string before processing it
@param contents of mutation list column from dataset row
@return true if string contains valid list of mutations
		false if string contains anything else
*/
virtual bool isValidMutationList_( const string&  i_string );
	/**
		noDrugValueName: holds a value that a particular dataset uses to signify
		a lack of drug value.
		ie. "na" or "n/a" or "N/A" or "not applicable"
	*/
	string noDrugValueName; 

	/**
		static Headers from HIV Susceptibility spreadsheet
		@todo MUTATIONLIST_HEADERNAME could be a vector of possible names
		With that, and just 3 lines of code different in genmutseq(), I would not need HivPreProcessor2
		I could just have the one class that handles the 2 stanford hivdb formats.
	*/
	string MUTATIONLIST_HEADERNAME;//pre Nov 4, 2004 format
	string MUTATIONLIST_HEADERNAME_2; //for post Nov 4, 2004 format
	string ISOLATE_HEADERNAME;//for all formats
	
	
private: 
	HivPreProcessor();//prevent default constructor from being called
	
	//copy constructor
	HivPreProcessor( const HivPreProcessor& );

	//assignment operator
	HivPreProcessor& operator= ( const HivPreProcessor& );


}; 

#endif // HIVPREPROCESSOR_H
