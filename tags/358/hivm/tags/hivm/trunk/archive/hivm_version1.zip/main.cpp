

//Visual Leak Detector from http://www.codeproject.com

//@todo figure out how to compile this only for MS Visual Studio
#ifdef MEMLEAKCHECK
	#include <vld.h>
#endif

	#include "std_include.h"

//#define TESTING
//#define CPPUNIT
//
//#ifdef CPPUNIT
//	#include "unit_tests/TestRun.cpp"
//#endif

//#ifdef TESTING//run tests, not release
////	#include "unit_tests/TestRunNoCppUnit.h"
//#endif
//
//#ifndef TESTING//run release, not tests
	#include "Client.h"
//#endif

// **************************************************************
// Main program
int main(int argc, char* argv[] )
{



//#ifdef TESTING
//
//#ifndef CPPUNIT
//	{
//		//TestRunNoCppUnit t;
//		//t.run();
//	}
//#endif
//
//#ifdef CPPUNIT
//	{
//		
//		TestRun t;
//		t.run();
//	}
//#endif
//	
//
// 
//#endif
//
//#ifndef TESTING
	{
		Client	c;
		c.run( argc, argv );

		//OptionsAdapter optAdptr;
		//optAdptr.parseInput( argc, argv );
	
		//ok, put this in Client.run
		//it's a if/else block to decide which way to run hivm
		//roc, eval, test or predict
//		c.evaluateHivmPerformance_();
	}
//#endif

//	_CrtDumpMemoryLeaks();

	return 0;
}
