#include "Hash.h"

//STATIC
unsigned long Hash::hshstrhash( const char *string )
{
   unsigned long h;
   h = 0;

   while (*string)
   {
      h = h * 31UL + (unsigned char) *string++;
   }

   return h; 	
}

Hash::Hash(){}

Hash::~Hash(){}