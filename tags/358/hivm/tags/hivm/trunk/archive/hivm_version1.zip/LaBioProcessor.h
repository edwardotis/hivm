#ifndef LABIOPROCESSOR_H
#define LABIOPROCESSOR_H

/**
@purpose Convert input data from aminio acids to numeric values based upon 
local alignment algorithm
*/

#include "BioProcessor.h"

#include <string.h>//for c-style char *'s in algorithm prototype
#include "dpl.h"//Butorovic's local alignment code

class LaBioProcessor : public BioProcessor
{

public:

	//default constructor
	LaBioProcessor();

	//default destructor
	~LaBioProcessor();


	/**
	@purpose saves cache of the bio procesor results
	*/
	virtual void saveCache( const OptionsAdapter& i_optAdptr, const vector<WorkUnit*>& i_wus, bool isLibrary, int cacheId );

	/**
	@purpose looks for cache hit and loads it into the WorkUnit set
	*/
	virtual bool checkCache( const OptionsAdapter& i_optAdptr, vector<WorkUnit*>& m_wus, bool isLibrary, int cacheId );

	/**
	@param iterator to container of WorkUnits*'s
	@pre iterator must point to first element of container
		Each work unit must already contain a string of aa's
	@post Each work unit will contain new string of numeric values
		corresponding to aa seq
	*/
	//virtual void process( std::vector<WorkUnit*>& wu );

	/**
	@note If you want to classify sequences, they must be included in process
	@param iterator to container of WorkUnits*'s
	@pre Each work unit must already contain a string of aa's
	@post Each work unit will contain new string of numeric values
		corresponding to aa seq
	*/
	virtual void process( std::vector<WorkUnit*>& trainingWUs,
		std::vector<WorkUnit*>& needClassifyingWUs,
		bool isCacheHit
		);
	
protected:

	virtual void LaBioProcessor::mapTrainingModelToFeatureSpace( std::vector<WorkUnit*>& m_trainingWUs );
	
	/**
	@purpose make a prediction candidate ready for use by libsvm
	@implementation computes LA score of a sequence from classify set against the training
	set's LA matrix
	*/
	virtual void LaBioProcessor::mapAPredictionCandidateToFeatureSpace( std::vector<WorkUnit*>& m_trainingWUs, WorkUnit* m_predictionCandidateWU );

	//typedef std::vector<WorkUnit*>::iterator wuIterator;

	void parseLaRow_( const string i_string, vector<double>& o_dblSet );


private:

	//copy constructor
	LaBioProcessor( const LaBioProcessor& );

	//assignment operator
	LaBioProcessor& operator= ( const LaBioProcessor& );

};

#endif
