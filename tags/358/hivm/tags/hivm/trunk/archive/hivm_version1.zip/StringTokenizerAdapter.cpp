#include "StringTokenizerAdapter.h"

StringTokenizerAdapter::StringTokenizerAdapter()
:  _strTok(  new StringTokenizer("","") )
{}

StringTokenizerAdapter::StringTokenizerAdapter( string input, string delim )
:  _strTok(  new StringTokenizer( input, delim ) )
{}

StringTokenizerAdapter::~StringTokenizerAdapter()
{
	if( _strTok != NULL )
	{
		delete _strTok;
	}
}

void StringTokenizerAdapter::setString( std::string input, std::string delim )
{	
	//remove old instance of StringTokenizer
	delete _strTok;

	//create new instance with new string and delim dataa
	_strTok = new StringTokenizer( input, delim );

}

//expose the original StringTokenizer public interface


int   StringTokenizerAdapter::countTokens()
{
	return _strTok->countTokens();
}

bool   StringTokenizerAdapter::hasMoreTokens()
{
	return _strTok->hasMoreTokens();
}

string StringTokenizerAdapter::nextToken()
{
	return _strTok->nextToken();
}

int    StringTokenizerAdapter::nextIntToken()
{
	return _strTok->nextIntToken();
}

double StringTokenizerAdapter::nextFloatToken()
{
	return _strTok->nextFloatToken();
}

string StringTokenizerAdapter::nextToken(string delim)
{
	return _strTok->nextToken( delim );
}

string StringTokenizerAdapter::remainingString()
{
	return _strTok->remainingString();
}

string StringTokenizerAdapter::filterNextToken(string filterStr)
{
	return _strTok->filterNextToken( filterStr );
}