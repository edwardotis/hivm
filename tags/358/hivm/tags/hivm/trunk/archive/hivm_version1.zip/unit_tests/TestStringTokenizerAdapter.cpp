/**
 * SHOULD I HAVE AN INTERACTIVE VERSION OF THIS TEST?
 * Maybe I allow a flag from TestRun.cpp to run interactive suites?
 *
 * Either that or bad user cmd line input will exit the program instead
 * of prompting user to correct their mistake.
 *
 */

#ifdef CPPUNIT

#include <cppunit/extensions/HelperMacros.h>


#include "../StringTokenizerAdapter.h"

#include "../std_include.h"

class TestStringTokenizerAdapter
#ifdef CPPUNIT
	: public CppUnit::TestFixture  
#endif  

{

#ifdef CPPUNIT

CPPUNIT_TEST_SUITE( TestStringTokenizerAdapter );

	CPPUNIT_TEST( testConstructors );
	CPPUNIT_TEST( setString );

CPPUNIT_TEST_SUITE_END();
CPPUNIT_TEST_SUITE_REGISTRATION( TestStringTokenizerAdapter );

#endif

private:

public:
  void setUp()
  {
  }

  void tearDown(  )
  {

  }

  //@fn open the default options text file
  // initialize internal classes
  void TestStringTokenizerAdapter::testConstructors(){

	    //test waht the default constructor does
	  {		
		  StringTokenizerAdapter a;
	  }

	  {
		StringTokenizerAdapter b( "abc,def,hij,k", "," );
		CPPUNIT_ASSERT( "abc" == b.nextToken() );
		CPPUNIT_ASSERT( "def" == b.nextToken() );
		CPPUNIT_ASSERT( "hi6j" == b.nextToken() );
		CPPUNIT_ASSERT( "k" == b.nextToken() );
	  }
  }

   void TestStringTokenizerAdapter::setString(){

		StringTokenizerAdapter a;
		//now perform some tokenizer functions to see if it worked.	
		CPPUNIT_ASSERT( "" == a.nextToken() );

		a.setString( "abc,def,hij,k", "," );

		//now perform some tokenizer functions to see if it worked.	
		CPPUNIT_ASSERT( "abc" == a.nextToken() );
		CPPUNIT_ASSERT( "def" == a.nextToken() );
		CPPUNIT_ASSERT( "hij" == a.nextToken() );
		CPPUNIT_ASSERT( "k" ==   a.nextToken() );
  }




};
#endif