#include "BioProcessor.h"

BioProcessor::BioProcessor(){}

BioProcessor::~BioProcessor(){}

//void BioProcessor::process( std::vector<WorkUnit*>& wu ){}

void BioProcessor::process( std::vector<WorkUnit*>& trainingWUs, std::vector<WorkUnit*>& needClassifyingWUs ){}


void BioProcessor::saveCache( const OptionsAdapter& i_optAdptr, const vector<WorkUnit*>& i_wus, bool isLibrary, int cacheId )
{}

bool BioProcessor::checkCache(const OptionsAdapter& i_optAdptr, vector<WorkUnit*>& m_wus, bool isLibrary, int cacheId )
{
	return false;
}

void BioProcessor::printScaled( std::vector<WorkUnit*>& wus  )
{
	std::vector<WorkUnit*>::iterator walker;//walker to traverse other WU's

	std::cout << std::endl;
	std::cout << "Printing scaled data" << std::endl;

	for( walker = wus.begin(); walker != wus.end(); walker++ )
	{
		std::cout << (*walker)->getIsolateName() << std::endl;
		printNumSeqScaledToScreen( (*walker) );//print a WU's row of the WU Set matrix
	}
}

void BioProcessor::printUnscaled( std::vector<WorkUnit*>& wus  )
{
	std::vector<WorkUnit*>::iterator walker;//walker to traverse other WU's
	
	std::cout << std::endl;
	std::cout << "Printing unscaled data" << std::endl;

	for( walker = wus.begin(); walker != wus.end(); walker++ )
	{
		std::cout << (*walker)->getIsolateName() << std::endl;
		printNumSeqToScreen( (*walker) );//print a WU's row of the WU Set matrix
	}

}

void BioProcessor::saveFile( std::vector<WorkUnit*>& wu, std::string  outputFileName )
{
	
	ofstream outFile;
	stringstream myStrStream;
	string line = "";

	if( outFile.is_open() )
	{
		outFile.close();
	}

	outFile.open( outputFileName.c_str(), ofstream::out );

	std::vector< WorkUnit* >::const_iterator i;
	std::vector< double >::const_iterator j;

	//go through each work unit's numseq and save to
	//proper libsvm data format
	for( i=wu.begin(); i!=wu.end();i++)
	{
		//now put an output string together in format
		myStrStream.str("");//clear

		//insert label/category at beginning of line
	//	assert( (*i)->getCategory() >= 0 );
		myStrStream << (*i)->getCategory();

		//int l = 77;
		//myStrStream << l;

		//now insert numseq
		//check to make sure each WU already has a numseq
		//assert( (*i)->getNumSeq().empty() != true );
		int index = 0;
		for( j=(*i)->getNumSeq().begin(); j!=(*i)->getNumSeq().end();j++)
		{
			double val = *j;
			myStrStream << " ";
			myStrStream << index;
			myStrStream << ":";
			myStrStream << val;
			index++;
		}

		myStrStream << std::endl;
		
		//write the line to outfile
		outFile << myStrStream.rdbuf();
	}

	outFile.close();



	//string currentFileName = "";
	//int currentCategory;
	//string currentDrugName = myInstr.getDrug();
	//int maxCategories = myInstr.getNumOfCategories();
	//stringstream myStream;
	//string catStr;
	//vector<WorkUnit*>::iterator wUIterator;
	//

	//	/**
	//		For each category, open a new file, when a Work Unit from that category is found, 
	//		add Isolate Name and Mutated Sequence to that file.
	//		
	//		note: This isn't the most efficient way, but it's only big0(n) = maxCategories*#WorkUnits
	//
	//		
	//	if a file is open that matches the wu category
	//		print to that file
	//	if file isn't open, then open a handle to a new file
	//		print to that file
	//*/
	//for( currentCategory = 0; currentCategory < maxCategories; currentCategory++ )
	//{
	//	//todo: the files are appending instead of overwriting. 
	//	//
	//	stringstream myStringStream;
	//	//clear old data before making next output file
	//	outFile.flush();
	//	outFile.clear();
	//	myStream.str("");//reset myStream to ""

	//	myStream << currentCategory;
	//	currentFileName = currentDrugName + "_Category" + myStream.str() + ".fasta";

	//	outFile.open( currentFileName.c_str(), ofstream::out );

	//	for( wUIterator = myWuVector.begin(); wUIterator != myWuVector.end(); wUIterator++ )
	//	{
	//		if( currentCategory == (*wUIterator)->getCategory() )
	//		{	
	//			myStringStream << "\n\n";
	//			myStringStream << ">" + (*wUIterator)->getIsolateName() + "\n";
	//			myStringStream << (*wUIterator)->getAaSeq();
	//			outFile << myStringStream.rdbuf();
	//		}
	//	}//end myWUVector loop

	//	outFile.close();
	//}//end currentCategory loop


}

void BioProcessor::printToScreen( std::vector<double> v )
{
	std::string s = "";
	std::vector<double>::iterator walker;
	for( walker = v.begin(); walker != v.end(); walker++ )
	{
		std::cout << (*walker) << ", ";
	}

	std::cout << endl;
}

void BioProcessor::printNumSeqToScreen( WorkUnit* w )
{
	printToScreen( w->getNumSeq() );
}

void BioProcessor::printNumSeqScaledToScreen( WorkUnit* w )
{
	printToScreen( w->getNumSeqScaled() );
}
