#include "IO.h"

//STATIC
bool IO::writeFile( const stringstream& fileName, const stringstream& i_sstream )
{
	return writeFile_( fileName, i_sstream );
}

bool IO::writeFile(  const stringstream& fileName,  const stringstream& i_sstream,  const stringstream& pathName )
{
	//put the path name and filename together
	stringstream fullPath;
	fullPath << pathName.str() << fileName.str();
	//pathName << fileName;

	return IO::writeFile_( fullPath, i_sstream );
}

bool IO::writeFile( const stringstream& fileName,  const stringstream& i_sstream,  const string pathName )
{
	stringstream pathStream;
	pathStream << pathName;

	return IO::writeFile( fileName, i_sstream, pathStream );
}

bool IO::writeFile_( const stringstream& fileName,  const stringstream& i_sstream )
{
		//get filestream to ready to write to disk
		ofstream outFile;
		if( outFile.is_open() )
		{
			outFile.close();
		}
		outFile.flush();
		outFile.clear();

		//@todo fix fileNameStream
		outFile.open( fileName.str().c_str(), ofstream::out );

		//write to file system
		outFile << i_sstream.rdbuf();
		outFile.close();

		return true;
}

bool IO::readFile( const stringstream&  fileName, stringstream& o_sstream, const stringstream&  pathName )
{
	//put the path name and filename together
	stringstream fullPath;
	fullPath <<	pathName.str() << fileName.str();

	return IO::readFile_( fullPath, o_sstream );
}

bool IO::readFile( const stringstream&  fileName, stringstream& o_sstream, const string  pathName )
{
	stringstream pathStream;
	pathStream << pathName;

	return IO::readFile( fileName, o_sstream, pathStream );
}

bool IO::readFile( const stringstream&  fileName, stringstream& o_sstream )
{
	return readFile_( fileName, o_sstream );

}

bool IO::readFile_( const stringstream&  fileName,  stringstream& o_sstream )
{
	ifstream inFile;
	
	if( inFile.is_open() ){	
		inFile.close();
	}
	inFile.clear();

	inFile.open( fileName.str().c_str(), fstream::in );

	if( inFile.fail() ) 
	{
		//cerr << "unable to open file " << str << " for reading" << endl;
		  inFile.close();
		  return false;
	}

	string myStr;
	while( getline( inFile, myStr ) )
	{
		o_sstream << myStr << endl;
	}

	return true;
	
}


IO::IO(){}

IO::~IO(){}