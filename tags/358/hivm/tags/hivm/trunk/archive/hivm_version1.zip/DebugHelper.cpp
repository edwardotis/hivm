#include "DebugHelper.h"


DebugHelper::DebugHelper()
{}

DebugHelper::~DebugHelper()
{}

void DebugHelper::debug( const vector<WorkUnit*>& v, bool print )
{
	vector<WorkUnit*>::const_iterator it;
	WorkUnit *wu;

	int size = (int)v.size();
	int i = 0;
	
	if(print)
	{
		std::cout << "Isolate Name | True Category " ;
	}

	for( it = v.begin(); it != v.end(); it++ )
	{
		wu = (*it);
		if( print == true )
		{
			std::cout << std::endl;

			std::cout << wu->getIsolateName() << ": ";	
			std::cout << wu->getCategory() << std::endl;
			//std::cout << "getNumSeq" << wu->getNumSeq() << std::endl;
			//std::cout << "getNumSeqActive" << wu->getNumSeqActive() << std::endl;
			//std::cout << "getNumSeqScaled" << wu->getNumSeqScaled() << std::endl;
			//std::cout << "getNumSeqScaledActive" << wu->getNumSeqScaledActive() << std::endl;
			//std::cout << "getAaSeq" << wu->getAaSeq() << std::endl;
			//std::cout << "getAaSeq" << wu->getAaSeq() << std::endl;
		}
		i++;
	}
}

void DebugHelper::debug( const vector<bool>& v, bool print )
{

	vector<bool>::const_iterator it;
	bool b;

	int size = (int)v.size();
	
	for( it = v.begin(); it != v.end(); it++ )
	{
		b = (*it);
		if( print == true )
		{	
			cout << endl;
			cout << b << endl;
		}
	}

}

void DebugHelper::debug( const vector<int>& v, bool print )
{

	vector<int>::const_iterator it;
	int b;

	int size = v.size();
	
	for( it = v.begin(); it != v.end(); it++ )
	{
		b = (*it);
		if( print == true )
		{	
			cout << endl;
			cout << b << endl;
		}
	}

}

void DebugHelper::debug( const vector<double>& v, bool print )
{

	vector<double>::const_iterator it;
	double b;

	int size = v.size();
	
	for( it = v.begin(); it != v.end(); it++ )
	{
		b = (*it);
		if( print == true )
		{	
			cout << endl;
			cout << b << endl;
		}
	}

}

void DebugHelper::debug( const vector<string>& v, bool print )
{
	vector<string>::const_iterator it;
	string b;

	int size = v.size();
	
	for( it = v.begin(); it != v.end(); it++ )
	{
		b = (*it);
		if( print == true )
		{	
			cout << endl;
			cout << b << endl;
		}
	}

}

void DebugHelper::debug( const Stats &_stat , bool print )
{
	vector< vector<int> >::const_iterator it;
	
	int _predictedClass = 0;
	for( it = _stat._predictedClass.begin(); it != _stat._predictedClass.end();it++)
	{
		if( print)
		{
			cout     <<"Predicted Class | True Class | Count" << endl;;
		}

		int _trueClass = 0;
		vector<int>::const_iterator jt;
		for( jt = (*it).begin(); jt != (*it).end(); jt++)
		{
			
			int count = (*jt);
			_predictedClass;
			_trueClass;
			
			if( print)
			{
				cout << "\t" << _predictedClass << "\t   |   " << _trueClass << "\t  |   " << (*jt)  << endl;
			}

			_trueClass++;
		}

		_predictedClass++;
	}
}
