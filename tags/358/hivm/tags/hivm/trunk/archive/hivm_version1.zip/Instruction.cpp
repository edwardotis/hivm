#include "Instruction.h"

//STATIC
int Instruction::numOfCategories; 

int Instruction::getNumOfCategories()
{
	return numOfCategories;
}

//default constructor
Instruction::Instruction()
: strTok_()
{
	origVirusSeq = "";
}

/**
 * Input the number of categories
 */
Instruction::Instruction( int numCat )
: strTok_()
{
	thresholdsVector.resize( 0, -1 );
//   thresholds = new double[ numOfCategories-1 ];
//	initThresholds( getNumOfCategories() );
	setNumOfCategories( numCat );
		
	//these variables aren't set
	drug = "";
	dataSet = "";
	origVirusSeqFileName = "";	
	//thresholdsVector.resize( (numCat-1), -1 );
	
}

/**
 * Initialize everything correctly with this constructor
 */
//Instruction::Instruction( int myArgC, char *myArgV[] )
//: strTok_()
//{	
////char* pEnd;//for strol()
//// 	  for( int pos = 5; pos <  myArgC; pos++){
////	  		cout << "\nmyArgV[pos] " << myArgV[pos] << endl;	
//// 	  }
//
//	thresholdsVector.resize( 0, -1 );
//	setInstructions( myArgC, myArgV );
//}


void Instruction::initialize( std::string options )
{
	std::vector<string> v;	

	strTok_.setString( options, " " );
	//StringTokenizer tok( options, " ");//string, delimiter is space
	int argCount = strTok_.countTokens();
	argCount++;//b/c the missing argv[0] is not in the options string

	while( strTok_.hasMoreTokens() )
	{
		v.push_back( strTok_.nextToken() );
	}

	setInstructions( argCount, v );
}

Instruction::Instruction( std::string options )
{
	std::vector<string> v;	

	//DRY
	strTok_.setString( options, " " );
//	StringTokenizer tok( options, " ");//string, delimiter is space
	int argCount = strTok_.countTokens();
	argCount++;//b/c the missing argv[0] is not in the options string

	//std::cout << "argCount = "  << argCount << endl;

	while( strTok_.hasMoreTokens() )
	{
		v.push_back( strTok_.nextToken() );
	}

	setInstructions( argCount, v );
}

Instruction::~Instruction()
{
	
}

void Instruction::setOrigVirusSeq( string fileName ){

	ifstream inFile( fileName.c_str() ); // Read
//	int i = 1; // Line counter
	string myStr;//buffer

	if( inFile.is_open() ){// Verify open
		//line 1 is Enzyme name
		std::getline( inFile, myStr );
		//line 2 begins first part of sequence
		while( std::getline( inFile, myStr ) )
		{
			origVirusSeq.append( myStr);
		}
	}
	else//can't find options file or open it for some reason
	{
		std::cerr << "Cannot open Original Virus Seq file named: " + fileName << std::endl;
		//std::cerr << "Exiting program" << std::endl;
		//exit(1);
	}

	//std::cout << "origVirusSeq = " << origVirusSeq << std::endl;

	inFile.clear();//clean out inFile

	inFile.close();

}

void Instruction::setThresholds( int argCount, std::vector<string>& options  ){
//Because argv[0] is always the name of the command, the value of argc is always
// one greater than the number of command-line arguments that the user enters. 


	if( doesNumCatsMatchNumThresholds(  argCount,  options ) == false ){
		std::cerr << "WARNING: Number of categories-1 doesn't match";
		std::cerr << " the number of thresholds" << endl;
		std::cerr << "Please correct this in Line 1 of the options file." << endl;
		std::cerr << "Exiting program" << endl;
		exit(1);
	}else{

 	  char* pEnd;//for strol()
 	  //[5] is always the starting theshold position in cmd line array
	  std::vector<string>::iterator i = options.begin();
	  i+=4;//move to 5th string in vector
 	  
	  for( int pos = 5; pos <  argCount; pos++)
	  {
	  		setThreshold( strtod( (*i).c_str(), &pEnd ) );
			i++;
 	  }
 	  
	}
	sortThresholds();
}

bool Instruction::setInstructions( int argCount, std::vector<string>& options )
{

 	vector<string>::iterator i = options.begin();
	 char* pEnd;//for strtol()
	 this->setDataSet( *i );  
	 this->setOrigVirusSeqFileName( *(++i) ); 
	 this->setOrigVirusSeq( (*i) );//yes, this is correct
	 this->setDrug( *(++i) );
	 this->setNumOfCategories(//convert string to cstring to long
	 	int( strtol( (*(++i)).c_str(), &pEnd, 10) )
	 );
	 thresholdsVector.resize( 0, -1 );//reset thesholds container
	 this->setThresholds( argCount, options );	
	return true;

}

//bool Instruction::setInstructions(int myArgC, char *myArgV[] )
//{
//
//	 char* pEnd;
//	 this->setDataSet( myArgV[1] );  
//	 this->setOrigVirusSeqFileName( myArgV[2] );       
//	 this->setDrug( myArgV[3] );
//	 this->setNumOfCategories(
//	 	int( strtol( myArgV[4], &pEnd, 10) )
//	 );
//	 thresholdsVector.resize( 0, -1 );
//	 //thresholdsVector.resize( getNumOfCategories(), -1 );
//	 this->setThresholds( myArgC, myArgV );	
//	return true;
//}


//setters
void Instruction::setDrug( string newDrug ){
	drug = newDrug;	
}
void Instruction::setDataSet( string newDataSet ){
	dataSet = newDataSet;
}

void Instruction::setOrigVirusSeqFileName( string newVirusSeqFileName ){
	origVirusSeqFileName = newVirusSeqFileName;
}



void Instruction::setNumOfCategories( int newCat ){
	if( newCat < 2 ){
		cout << "There must be at least two categories!" << endl;
		cout << "Please enter number of categories again:" << endl;
		int tempCat;
		cin >> tempCat;
		setNumOfCategories( tempCat );
		
	}else{
		numOfCategories = newCat;
	}
}

//void Instruction::setThreshold( double thresholdValue, int pos  ){
//	
//	thresholds[ pos ] = thresholdValue;
//	
//	//test the iterator positioning!
////	myIterator = thresholdsVector.begin();
////	thresholdsVector.insert( myIterator+pos, thresholdValue );
//}

void Instruction::threshold( double threshold )
{

	thresholdsVector.resize( 0 );
	thresholdsVector.push_back( threshold );
}

/**
 * adds value to end of the vector
 */
void Instruction::setThreshold( double thresholdValue  ){
	//if( thresholdValue == 0.9 ){
	//	cout << "\nsetting value: " << thresholdValue << endl;
	//}
	thresholdsVector.push_back( thresholdValue );
	sortThresholds();
}

void Instruction::sortThresholds(){
	

	//cout << "\nunsorted " << endl;
	//printThresholds();

	sort( thresholdsVector.begin(), thresholdsVector.end() );

	//cout << "\nsorted " << endl;
	//printThresholds();
}

void Instruction::printThresholds(){
	cout << "\nPrinting Instruction Thresholds." << endl;
	for( myIterator = thresholdsVector.begin(); myIterator != thresholdsVector.end(); myIterator++ ){
		cout << "\t" << *myIterator;
	}
}


void Instruction::setThresholds( int myArgC, char* myArgV[] ){
//Because argv[0] is always the name of the command, the value of argc is always
// one greater than the number of command-line arguments that the user enters. 

//	cout << "myArgC " << myArgC << endl;

	if( doesNumCatsMatchNumThresholds( myArgC, myArgV) == false ){
		cerr << "WARNING: Number of categories-1 doesn't match";
		cerr << " the number of thresholds" << endl;
		//Now, prompt user for input again!!
	}else{
 	  char* pEnd;//for strol()
 //	  int numCat = strtol( myArgV[4], &pEnd, 10);//get number of categories
 	  //[5] is always the starting theshold position in cmd line array

 	  for( int pos = 5; pos <  myArgC; pos++){
	  		//cout << "\nmyArgV[pos] " << myArgV[pos] << endl;
	  		setThreshold( strtod( myArgV[pos], &pEnd ) );
 	  }
 	  
	}
	sortThresholds();
}




/**
 * Private method to be run from constructors to see if cmd line input has
 * correct number of thresholds to match the input categories
 */
bool Instruction::doesNumCatsMatchNumThresholds( int myArgC, char* myArgV[] ){

//Because argv[0] is always the name of the command, the value of argc is always
// one greater than the number of command-line arguments that the user enters. 
  
   char * pEnd;//for strol()
   //cout << strtol( myArgV[4], &pEnd, 10) << endl;
   int numCat = strtol( myArgV[4], &pEnd, 10);//get number of categories
	if( numCat + 4 == myArgC){
		return true;
	}else{
		return false;
	}
}

bool Instruction::doesNumCatsMatchNumThresholds( int argCount, std::vector<string>& options )
{
	//Because argv[0] is always the name of the command, the value of argc is always
	// one greater than the number of command-line arguments that the user enters. 
  
   char * pEnd;//for strol()
   std::vector<string>::iterator i = options.begin();	
   i+=3;

   int numCat = strtol( (*i).c_str(), &pEnd, 10);//get number of categories
	if( numCat + 4 == argCount){
		return true;
	}else{
		return false;
	}
}

//getters
string Instruction::getDrug() const
{
	return drug;
}

string Instruction::getDataSet() const
{
	return dataSet;
}

string Instruction::getOrigVirusSeqFileName() const
{
	return origVirusSeqFileName;
}

vector<double> Instruction::getThresholds() const
{
	return thresholdsVector;	
}

string Instruction::getOrigVirusSeq( ) const
{
	return origVirusSeq;
}

void Instruction::resetThreshold( double the_only_threshold )
{
	thresholdsVector.resize(0);
	thresholdsVector.push_back( the_only_threshold );
}