#include "WorkUnit.h"

//STATIC

//allocate storage for static members
std::vector<bool> WorkUnit::_activePositions;

bool WorkUnit::isCrossValidation = false;

void WorkUnit::initActivePositions( unsigned int size )
{	
	//reset the active Positions vector
	_activePositions.clear();

	if( size == 0 )
	{
		cout << "Error: Active Positions vector set to 0 size." << endl;
	}

	for( unsigned int i=0; i < size; i++ )
	{
		_activePositions.push_back( true );
	}
}

void WorkUnit::resetActivePositions( )
{	
	//reset the active Positions vector
	_activePositions.clear();
}

void WorkUnit::updateActivePositions( const vector<int>& inactivePositions )
{
	intConstIt it;
	
	/**
	debug code
	*/
	int size = inactivePositions.size();
	
	for(it = inactivePositions.begin();it != inactivePositions.end();it++ )
	{
		int i = (*it);
	}
	//end debug

	//reset all active positions to true
	for( int j=0; j<_activePositions.size(); j++ )
	{
		_activePositions[j] = true;
	}

	//turn the correct positions to inactive
	for(it = inactivePositions.begin();it != inactivePositions.end();it++ )
	{
		_activePositions.at( (*it) ) = false;
	}
}

int WorkUnit::_getActivePositionsLength()
{
	
	int i = 0;
	boolConstIt it = _activePositions.begin();

	while( it != _activePositions.end() )
	{
		if( (*it) == true )
		{
			i++;
		}
		it++;
	}


	return i;
}

const vector<bool>& WorkUnit::getActivePositions()
{
	return WorkUnit::_activePositions;
}

//END STATIC

WorkUnit::WorkUnit(  )
//:	aaSeq( "" ),
//	category( 0 ),
//	isolateName( "" )
{
	aaSeq = "";
	category = -1;
	isolateName = "";

}

//WorkUnit::WorkUnit( OptionsAdapter *newInstr )
//{
//	myInstr = newInstr;
//	seq = "";
//	category = -1;
//	setIsolateName( "Isolate Name Not Set" );
//}


WorkUnit::~WorkUnit()
{
	//I pass in an OptionsAdapter, but I never call new
	//hence, it's wrong to delete the OptionsAdapter here
	//cout << "~WorkUnit" << endl;
	//delete myInstr;
}


int WorkUnit::size()
{
	if( isCrossValidation == true )
	{
		return WorkUnit::_getActivePositionsLength();
	}
	
	if( numSeqScaled.size() != 0 )
	{
		return numSeqScaled.size();
	}

	return numSeq.size();
}

/**
	ideally, I'd rename this print, and pass it a stream.
	Then the stream would direct the output to a file or screen, etc.
	but not today.
	hmmm, actually, I have to do something like this anyway.

*/
void WorkUnit::print( ofstream& outFile )
{
	/**
		Format is:
		newline
		>IsolateName value
		MutantSequence value
	*/
	if( outFile.is_open() )
	{
		outFile << "\n";
		outFile << this->getIsolateName() << "\n";
		outFile << this->getAaSeq();

	}
}

void WorkUnit::setIsolateName( string newIsolateName )
{
	isolateName = newIsolateName;
}

string WorkUnit::getIsolateName()
{
	return isolateName;
}

//getter/setter implementations


string WorkUnit::getAaSeq(){
	return aaSeq;
}

void WorkUnit::setAaSeq( string newSeq ){
	aaSeq = newSeq;
}

int WorkUnit::getCategory() const
{
	return category;
}

void WorkUnit::setCategory( int newCat ){
	
	if( newCat >= 0){
		category = newCat;
	}else{

		cerr << "Categories must be positive integers!" << endl;	
		//Do I throw some sort of exception?
		cerr << "System will now exit" << endl;
		exit(1);
	}

}

std::vector<double>& WorkUnit::getNumSeq()
{
	return numSeq;
}

std::vector<double>& WorkUnit::getNumSeqScaled()
{
	return numSeqScaled;
}


std::vector<double>& WorkUnit::getNumSeqActive()
{
	if( WorkUnit::isCrossValidation == false )
	{
		return numSeq;
	}
	assert( WorkUnit::_activePositions.size() == numSeq.size() );

	_selectActiveNums( numSeq, numSeqActive );

	return numSeqActive;
}

std::vector<double>& WorkUnit::getNumSeqScaledActive()
{
	if( WorkUnit::isCrossValidation == false )
	{
		return numSeqScaled;
	}

	assert( WorkUnit::_activePositions.size() == numSeq.size() );
	assert( numSeqScaled.size() != 0 );

	_selectActiveNums( numSeqScaled, numSeqScaledActive );

	return numSeqScaledActive;
}

void WorkUnit::_selectActiveNums( dblVtor& i_numGroup, dblVtor& o_output )
{
	if( _activePositions.size() != i_numGroup.size() )
	{
		//cout
	}


	//clean out the output vector b/c it should be refreshed on every call to this function
	o_output.resize(0);

	boolConstIt activePos = _activePositions.begin();
	dblConstIt	it;

	for( it = i_numGroup.begin(); it != i_numGroup.end(); it++ )
	//while( activePos != _activePositions.end() )
	{
		if( (*activePos) == true )
		{
			o_output.push_back( (*it) );
		}

		//increment active position
		activePos++;
	}
}

