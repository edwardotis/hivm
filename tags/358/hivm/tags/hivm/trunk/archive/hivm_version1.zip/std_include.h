#ifndef _STD_INCLUDE
#define _STD_INCLUDE 1


//for custom defitions
#include "definitions.h"

//for debugging and memory leak checks in native VS mem checker
//#define _CRTDBG_MAP_ALLOC
//#include <stdlib.h>
//#include <crtdbg.h>
//

#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <cstdlib>//to input integers from cmd line: strtol, strtod
#include <sstream>//for PreProcessor class
//#include <memory> //for auto_ptr
//#include <stdlib.h>//for help with calloc, malloc, realloc

// If the macro NDEBUG is defined, the assert() macros will be ignored.
#include <assert.h>//for debugging

//#ifndef DEBUGHELPER_H
//	#include "DebugHelper.h"
//#endif

//for 3rd party
#include <limits> //for numeric_limits, 
#include <cfloat>// for and double max/min values DBL_MAX,DBL_MIN
#include <cmath> 

using namespace std;


//Is there a way to use standarad typedefs in a header to improve readability of the entir application?
//typedef std::vector<WorkUnit*>::iterator wuIterator;

//#ifdef CPPUNIT
//	#include <cppunit/BriefTestProgressListener.h>
//	#include <cppunit/TestCase.h>
//	#include <cppunit/TestSuite.h>
//	#include <cppunit/TestCaller.h>
//	#include <cppunit/ui/text/TestRunner.h>
//	#include <cppunit/extensions/HelperMacros.h>
//#endif

#endif
