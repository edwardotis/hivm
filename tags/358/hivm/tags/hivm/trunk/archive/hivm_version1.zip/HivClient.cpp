#include "HivClient.h"

HivClient::HivClient(){

}

//HivClient::HivClient( PreProcessor h )
//{
//	cout << "hih" << endl; 
////	PreProcessor h;
//	h =  HivPreProcessor();
//	//myPreProc = new HivPreProcessor();
//}

HivClient::~HivClient()
{}
